<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            ['slug' => 'admin',             'nombre' => 'Administrador',      'descripcion' => 'Acceso total al sistema', 'activo' => true],
            ['slug' => 'responsable_area',  'nombre' => 'Responsable de Área','descripcion' => 'Gestiona su área o nivel', 'activo' => true],
            ['slug' => 'evaluador',         'nombre' => 'Evaluador',          'descripcion' => 'Registra evaluaciones',    'activo' => true],
            ['slug' => 'consulta',          'nombre' => 'Consulta',           'descripcion' => 'Lectura de reportes',      'activo' => true],
        ];

        foreach ($roles as $r) {
            DB::table('roles')->updateOrInsert(['slug' => $r['slug']], $r + ['created_at' => now(), 'updated_at' => now()]);
        }
    }
}
