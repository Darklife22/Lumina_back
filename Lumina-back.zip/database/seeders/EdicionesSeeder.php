<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Edicion;
use Illuminate\Support\Str;

class EdicionesSeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            ['nombre'=>'Olimpiada 2025','gestion'=>'2025','activa'=>true,'fecha_inicio'=>'2025-03-01','fecha_fin'=>'2025-11-30'],
            ['nombre'=>'Olimpiada 2026','gestion'=>'2026','activa'=>false,'fecha_inicio'=>null,'fecha_fin'=>null],
        ];
        foreach ($items as $i) {
            Edicion::firstOrCreate(
                ['slug'=>Str::slug($i['nombre'])],
                $i
            );
        }
    }
}
