<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Area;

class AreasSeeder extends Seeder
{
    public function run(): void
    {
        $base = [
            'Matemática',
            'Física',
            'Química',
            'Biología',
            'Informática',
            'Lenguaje',
            'Historia',
            'Geografía',
            'Emprendimiento',
            'Robótica',
        ];

        foreach ($base as $nombre) {
            Area::firstOrCreate(['nombre' => $nombre], ['activo' => true]);
        }
    }
}
