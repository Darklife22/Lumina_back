<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class UsuariosSeeder extends Seeder
{
    public function run(): void
    {
        // Password: SecretTemp123!
        $password = Hash::make('SecretTemp123!');

        $map = [
            'admin'            => ['nombre' => 'Helen', 'apellidos' => 'Admin',        'email' => 'admin@example.com'],
            'responsable_area' => ['nombre' => 'Eva',   'apellidos' => 'Responsable',  'email' => 'responsable@ohsansi.local'],
            'evaluador'        => ['nombre' => 'Luis',  'apellidos' => 'Evaluador',    'email' => 'evaluador@ohsansi.local'],
            'consulta'         => ['nombre' => 'Ana',   'apellidos' => 'Consulta',     'email' => 'consulta@ohsansi.local'],
        ];

        foreach ($map as $slug => $data) {
            $roleId = DB::table('roles')->where('slug', $slug)->value('id');
            if (!$roleId) continue;

            DB::table('usuarios')->updateOrInsert(
                ['email' => $data['email']],
                [
                    'nombre'     => $data['nombre'],
                    'apellidos'  => $data['apellidos'],
                    'password'   => $password,
                    'role_id'    => $roleId,
                    'activo'     => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}
