<?php
// database/migrations/2025_10_28_000300_create_listas_competidores.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('listas_competidores', function (Blueprint $table) {
            $table->id();
            $table->foreignId('responsable_id')->constrained('responsables_academicos')->cascadeOnDelete();
            $table->foreignId('area_id')->nullable()->constrained('areas')->nullOnDelete();
            $table->string('nivel', 100)->nullable();
            $table->date('fecha_competencia');
            $table->string('nombre', 200)->nullable(); // opcional: nombre de la lista
            $table->timestamps();
        });

        Schema::create('lista_competidor_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lista_id')->constrained('listas_competidores')->cascadeOnDelete();
            $table->foreignId('inscrito_id')->constrained('inscritos')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['lista_id','inscrito_id']);
        });
    }
    public function down(): void {
        Schema::dropIfExists('lista_competidor_items');
        Schema::dropIfExists('listas_competidores');
    }
};
