<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('inscritos', function (Blueprint $table) {
            $table->id();
            $table->string('externo_id', 100)->nullable();  // ID del CSV
            $table->string('nombre', 180);
            $table->string('ci', 80);
            $table->string('area', 120);
            $table->string('nivel', 120);
            $table->string('unidad_educativa', 200)->nullable();
            $table->string('profesor', 180)->nullable();
            $table->timestamp('importado_en')->nullable();  // para HU: “guardado con timestamp”
            $table->timestamps();

            $table->index(['area', 'nivel']);
            // Si tu ID de CSV es único, puedes activar:
            // $table->unique('externo_id');
        });
    }

    public function down(): void {
        Schema::dropIfExists('inscritos');
    }
};
