<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('area_evaluador', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('evaluador_id');
            $table->unsignedBigInteger('area_id');
            $table->timestamps();

            $table->unique(['evaluador_id', 'area_id']); // evita duplicados

            $table->foreign('evaluador_id')->references('id')->on('evaluadores')->onDelete('cascade');
            $table->foreign('area_id')->references('id')->on('areas')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('area_evaluador');
    }
};
