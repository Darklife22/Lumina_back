<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        $hasOld = Schema::hasTable('area_responsable');
        $hasNew = Schema::hasTable('responsable_area');

        if ($hasOld && !$hasNew) {
            // Renombrar al nombre canónico
            Schema::rename('area_responsable', 'responsable_area');

            // Opcional: asegurar índices/unique
            Schema::table('responsable_area', function (Blueprint $table) {
                // si no existen, crea foreigns/índices (ajusta nombres de FK si las necesitas)
                if (!Schema::hasColumn('responsable_area','created_at')) {
                    $table->timestamps();
                }
                // Evitar duplicados (área+responsable)
                $table->unique(['area_id','responsable_id'], 'uniq_area_responsable');
            });
        } elseif (!$hasOld && !$hasNew) {
            // Crear desde cero
            Schema::create('responsable_area', function (Blueprint $table) {
                $table->id();
                $table->foreignId('area_id')->constrained('areas')->cascadeOnUpdate()->cascadeOnDelete();
                $table->foreignId('responsable_id')->constrained('responsables_academicos')->cascadeOnUpdate()->cascadeOnDelete();
                $table->timestamps();
                $table->unique(['area_id','responsable_id'], 'uniq_area_responsable');
            });
        }
        // Si $hasNew ya es true, no hacemos nada.
    }

    public function down(): void
    {
        // Reversión conservadora: NO borremos datos productivos.
        // Si quieres, podrías renombrar de vuelta:
        // if (Schema::hasTable('responsable_area') && !Schema::hasTable('area_responsable')) {
        //     Schema::rename('responsable_area', 'area_responsable');
        // }
    }
};
