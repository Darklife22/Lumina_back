<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('evaluador_materia')) {
            Schema::create('evaluador_materia', function (Blueprint $table) {
                $table->id();

                $table->unsignedBigInteger('evaluador_id');
                $table->unsignedBigInteger('materia_edicion_id');

                $table->timestamps();

                // FK a evaluadores (esta sí existe)
                $table->foreign('evaluador_id')
                    ->references('id')->on('evaluadores')
                    ->onDelete('cascade');

                // En lugar de FK duro a materias_edicion, dejamos índice + unique
                $table->index(
                    'materia_edicion_id',
                    'evaluador_materia_materia_edicion_idx'
                );

                $table->unique(
                    ['evaluador_id', 'materia_edicion_id'],
                    'evaluador_materia_unique'
                );
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('evaluador_materia')) {
            Schema::dropIfExists('evaluador_materia');
        }
    }
};
