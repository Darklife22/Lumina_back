<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('umbrales', function (Blueprint $table) {
            $table->id();

            // Edición a la que pertenece el umbral
            $table->unsignedBigInteger('edicion_id');

            // Área / materia
            $table->unsignedBigInteger('area_id');

            // Nivel de competición (lo manejamos como string flexible)
            $table->string('nivel_id', 50);

            // Valor del umbral (ej: 70.00, 80.5, etc.)
            $table->decimal('valor', 8, 2);

            $table->timestamps();

            // FK (ajusta nombres de tablas si en tu BD son distintos)
            $table->foreign('edicion_id')->references('id')->on('ediciones')->onDelete('cascade');
            $table->foreign('area_id')->references('id')->on('areas')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('umbrales');
    }
};
