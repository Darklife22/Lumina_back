<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('niveles')) {
            Schema::create('niveles', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('edicion_id')->nullable()->index();
                
                $table->string('nombre', 100);
                $table->unsignedInteger('orden')->default(1);

                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('niveles')) {
            Schema::dropIfExists('niveles');
        }
    }
};
