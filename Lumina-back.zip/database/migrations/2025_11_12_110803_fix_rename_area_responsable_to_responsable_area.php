<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Si la tabla no existe, no hay nada que arreglar
        if (!Schema::hasTable('responsable_area')) {
            return;
        }

        // Intentar quitar / re-crear el índice de forma segura
        try {
            Schema::table('responsable_area', function (Blueprint $table) {
                // Si existe, lo quita (en tu caso no existe y por eso reventaba)
                // El try/catch global evita que el error rompa la migración
                $table->dropUnique('responsable_area_area_id_responsable_id_unique');
            });
        } catch (\Throwable $e) {
            // Ignoramos: el índice no existe y no es crítico para continuar
        }

        // Opcionalmente, podemos asegurar que exista el índice único correcto.
        // Si ya lo tienes, esto no rompe nada; si no lo tienes, lo crea.
        try {
            Schema::table('responsable_area', function (Blueprint $table) {
                $table->unique(
                    ['area_id', 'responsable_id'],
                    'responsable_area_area_id_responsable_id_unique'
                );
            });
        } catch (\Throwable $e) {
            // Si por cualquier motivo falla (ya existe con otro nombre, etc.), lo ignoramos.
        }
    }

    public function down(): void
    {
        if (!Schema::hasTable('responsable_area')) {
            return;
        }

        try {
            Schema::table('responsable_area', function (Blueprint $table) {
                $table->dropUnique('responsable_area_area_id_responsable_id_unique');
            });
        } catch (\Throwable $e) {
            // igual que en up(), no queremos que explote por índices inexistentes
        }
    }
};
