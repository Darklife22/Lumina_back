<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('areas', function (Blueprint $table) {
            if (!Schema::hasColumn('areas', 'slug')) {
                $table->string('slug', 160)->nullable()->unique()->after('nombre');
            }
            if (!Schema::hasColumn('areas', 'rango_min')) {
                $table->unsignedSmallInteger('rango_min')->default(0)->after('slug');
            }
            if (!Schema::hasColumn('areas', 'rango_max')) {
                $table->unsignedSmallInteger('rango_max')->default(100)->after('rango_min');
            }
            if (!Schema::hasColumn('areas', 'umbral_clasificacion')) {
                $table->unsignedSmallInteger('umbral_clasificacion')->default(70)->after('rango_max');
            }
            if (!Schema::hasColumn('areas', 'activo')) {
                $table->boolean('activo')->default(true)->after('umbral_clasificacion');
            }
        });
    }

    public function down(): void {
        Schema::table('areas', function (Blueprint $table) {
            if (Schema::hasColumn('areas', 'activo')) $table->dropColumn('activo');
            if (Schema::hasColumn('areas', 'umbral_clasificacion')) $table->dropColumn('umbral_clasificacion');
            if (Schema::hasColumn('areas', 'rango_max')) $table->dropColumn('rango_max');
            if (Schema::hasColumn('areas', 'rango_min')) $table->dropColumn('rango_min');
            if (Schema::hasColumn('areas', 'slug')) $table->dropColumn('slug');
        });
    }
};
