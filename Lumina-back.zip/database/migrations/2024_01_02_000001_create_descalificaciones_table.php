<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('descalificaciones', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('inscrito_id');
            $table->unsignedBigInteger('evaluador_id');
            $table->text('motivo');

            $table->timestamps();

            $table->foreign('inscrito_id')
                ->references('id')
                ->on('inscritos')
                ->onDelete('cascade');

            $table->foreign('evaluador_id')
                ->references('id')
                ->on('usuarios')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('descalificaciones');
    }
};
