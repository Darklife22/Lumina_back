<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('ediciones', function (Blueprint $table) {
            // Si la tabla ya existe pero sin 'anio', lo añadimos
            if (!Schema::hasColumn('ediciones', 'anio')) {
                $table->unsignedSmallInteger('anio')
                      ->after('id');

                // Si no tienes datos previos, puedes dejarlo así
                // y marcar unique aparte:

                $table->unique('anio');
            }
        });

        // Si hubiera datos ya existentes y necesitaras rellenar 'anio',
        // aquí podrías hacer un UPDATE usando otro campo (por ejemplo 'year'),
        // pero como esto es nuevo, asumimos tabla vacía.
    }

    public function down(): void
    {
        Schema::table('ediciones', function (Blueprint $table) {
            if (Schema::hasColumn('ediciones', 'anio')) {
                $table->dropUnique(['anio']);
                $table->dropColumn('anio');
            }
        });
    }
};
