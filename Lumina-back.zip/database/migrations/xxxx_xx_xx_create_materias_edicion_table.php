<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('materias_edicion', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('edicion_id')->index();
            $table->string('materia');
            $table->integer('rango_min')->default(0);
            $table->integer('rango_max')->default(100);
            $table->boolean('activo')->default(true);
            $table->timestamps();

            $table->foreign('edicion_id')->references('id')->on('ediciones')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('materias_edicion');
    }
};
