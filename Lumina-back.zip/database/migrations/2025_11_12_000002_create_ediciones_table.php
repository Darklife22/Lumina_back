<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ediciones', function (Blueprint $table) {
            $table->id();

            // Año de la edición (único)
            $table->unsignedSmallInteger('anio')->unique();

            // Nombre / título oficial
            $table->string('nombre_oficial', 255);

            // Identificador único legible (por HU: ID_Edicion_2026)
            $table->string('codigo', 64)->unique();

            // Rango de fechas de la edición
            $table->date('fecha_inicio');
            $table->date('fecha_fin');

            // Estado: borrador/configuracion, activa, cerrada
            $table->string('estado', 32)->default('borrador');

            // Flag para confirmar materias (para HU futura de activar la olimpiada)
            $table->boolean('materias_confirmadas')->default(false);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ediciones');
    }
};
