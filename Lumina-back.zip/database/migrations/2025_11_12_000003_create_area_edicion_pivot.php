<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Si ya existe, no hacemos nada
        if (Schema::hasTable('area_edicion')) {
            return;
        }

        Schema::create('area_edicion', function (Blueprint $t) {
            $t->id();

            $t->unsignedBigInteger('area_id');
            $t->unsignedBigInteger('edicion_id');

            $t->timestamps();

            // Opcionales: llaves foráneas si las necesitas y no existen ya
            // (si ya las creaste en otra migración, puedes comentar esto)

            $t->foreign('area_id')
              ->references('id')->on('areas')
              ->onDelete('cascade');

            $t->foreign('edicion_id')
              ->references('id')->on('ediciones')
              ->onDelete('cascade');

            // Índice único para no duplicar combinaciones
            $t->unique(['area_id', 'edicion_id']);
        });
    }

    public function down(): void
    {
        // Borra la tabla solo si existe
        if (Schema::hasTable('area_edicion')) {
            Schema::drop('area_edicion');
        }
    }
};
