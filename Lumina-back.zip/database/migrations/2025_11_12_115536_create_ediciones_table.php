<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    if (!Schema::hasTable('ediciones')) {
      Schema::create('ediciones', function (Blueprint $t) {
        $t->id();
        $t->string('nombre', 150);
        $t->string('slug', 150)->unique();
        $t->string('gestion', 20)->nullable();
        $t->date('fecha_inicio')->nullable();
        $t->date('fecha_fin')->nullable();
        $t->boolean('activa')->default(true);
        $t->timestamps();
      });
    }
  }
  public function down(): void {
    Schema::dropIfExists('ediciones');
  }
};
