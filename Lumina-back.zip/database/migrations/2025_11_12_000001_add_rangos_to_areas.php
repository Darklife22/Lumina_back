<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('areas')) {
            return;
        }

        Schema::table('areas', function (Blueprint $table) {
            // min_nota
            if (!Schema::hasColumn('areas', 'min_nota')) {
                $table->decimal('min_nota', 5, 2)->default(0);
            }

            // max_nota
            if (!Schema::hasColumn('areas', 'max_nota')) {
                $table->decimal('max_nota', 5, 2)->default(100);
            }

            // nota_aprobatoria
            if (!Schema::hasColumn('areas', 'nota_aprobatoria')) {
                $table->decimal('nota_aprobatoria', 5, 2)->default(60);
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('areas')) {
            return;
        }

        Schema::table('areas', function (Blueprint $table) {
            if (Schema::hasColumn('areas', 'nota_aprobatoria')) {
                $table->dropColumn('nota_aprobatoria');
            }
            if (Schema::hasColumn('areas', 'max_nota')) {
                $table->dropColumn('max_nota');
            }
            if (Schema::hasColumn('areas', 'min_nota')) {
                $table->dropColumn('min_nota');
            }
        });
    }
};
