<?php
// database/migrations/2025_10_28_000100_add_usuario_to_responsables_academicos.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('responsables_academicos', function (Blueprint $table) {
            $table->foreignId('usuario_id')->nullable()->after('id')
                  ->constrained('usuarios')->nullOnDelete();
        });
    }
    public function down(): void {
        Schema::table('responsables_academicos', function (Blueprint $table) {
            $table->dropConstrainedForeignId('usuario_id');
        });
    }
};
