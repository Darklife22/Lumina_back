<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('calificacion_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('inscrito_id')->constrained('inscritos')->cascadeOnDelete();
            $table->foreignId('evaluador_id')->constrained('usuarios')->cascadeOnDelete();
            $table->foreignId('calificacion_id')->nullable()->constrained('calificaciones')->nullOnDelete();

            $table->decimal('nota_anterior', 5, 2)->nullable();
            $table->decimal('nota_nueva', 5, 2)->nullable();
            $table->string('comentario_anterior', 250)->nullable();
            $table->string('comentario_nuevo', 250)->nullable();

            $table->foreignId('changed_by')->constrained('usuarios')->cascadeOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('calificacion_logs');
    }
};
