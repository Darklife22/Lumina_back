<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('area_edicion')) {
            Schema::create('area_edicion', function (Blueprint $t) {
                $t->id();
                $t->foreignId('area_id')->constrained('areas')->cascadeOnDelete();
                $t->foreignId('edicion_id')->constrained('ediciones')->cascadeOnDelete();
                $t->timestamps();
                $t->unique(['area_id','edicion_id']);
            });
        }
    }
    public function down(): void {
        Schema::dropIfExists('area_edicion');
    }
};
