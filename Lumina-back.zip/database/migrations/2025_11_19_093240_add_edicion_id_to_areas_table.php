<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('areas')) return;

        Schema::table('areas', function (Blueprint $table) {
            if (!Schema::hasColumn('areas', 'id')) {
                throw new Exception("La tabla areas no tiene columna id.");
            }

            if (!Schema::hasColumn('areas', 'edicion_id')) {
                $table->unsignedBigInteger('edicion_id')
                      ->nullable()
                      ->after('id');

                $table->index('edicion_id', 'areas_edicion_id_index');
            }
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('areas')) return;

        Schema::table('areas', function (Blueprint $table) {
            if (Schema::hasColumn('areas', 'edicion_id')) {
                $table->dropIndex('areas_edicion_id_index');
                $table->dropColumn('edicion_id');
            }
        });
    }
};
