<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 100);
            $table->string('apellidos', 150)->nullable();
            $table->string('email', 150)->unique();
            $table->string('password');
            $table->foreignId('role_id')
                ->constrained('roles')
                ->cascadeOnUpdate()
                ->restrictOnDelete();
            $table->boolean('activo')->default(true);
            $table->rememberToken();
            $table->timestamps();

            $table->index(['role_id']);
        });
    }

    public function down(): void {
        Schema::dropIfExists('usuarios');
    }
};
