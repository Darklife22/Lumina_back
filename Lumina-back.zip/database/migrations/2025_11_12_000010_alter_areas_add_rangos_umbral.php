<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
  public function up(): void {
    Schema::table('areas', function (Blueprint $t) {
      if (!Schema::hasColumn('areas','rango_min')) {
        $t->integer('rango_min')->default(0);
      }
      if (!Schema::hasColumn('areas','rango_max')) {
        $t->integer('rango_max')->default(100);
      }
      if (!Schema::hasColumn('areas','umbral_clasificacion')) {
        $t->integer('umbral_clasificacion')->default(60);
      }
      if (!Schema::hasColumn('areas','activo')) {
        $t->boolean('activo')->default(true);
      }
    });
  }
  public function down(): void {
    Schema::table('areas', function (Blueprint $t) {
      if (Schema::hasColumn('areas','rango_min')) $t->dropColumn('rango_min');
      if (Schema::hasColumn('areas','rango_max')) $t->dropColumn('rango_max');
      if (Schema::hasColumn('areas','umbral_clasificacion')) $t->dropColumn('umbral_clasificacion');
      if (Schema::hasColumn('areas','activo')) $t->dropColumn('activo');
    });
  }
};
