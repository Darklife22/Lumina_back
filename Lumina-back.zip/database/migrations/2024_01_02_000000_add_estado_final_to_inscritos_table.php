<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('inscritos', function (Blueprint $table) {
            if (!Schema::hasColumn('inscritos', 'estado_final')) {
                $table->string('estado_final', 20)
                    ->nullable()
                    ->after('profesor');
            }
        });
    }

    public function down(): void
    {
        Schema::table('inscritos', function (Blueprint $table) {
            if (Schema::hasColumn('inscritos', 'estado_final')) {
                $table->dropColumn('estado_final');
            }
        });
    }
};
