<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Historial de calificaciones</title>
  <style>
    body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; font-size: 12px; }
    h1 { font-size: 18px; margin: 0 0 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #aaa; padding: 6px; }
    th { background: #eee; }
    .meta { margin-bottom: 12px; }
  </style>
</head>
<body>
  <h1>Historial de calificaciones</h1>
  <div class="meta">
    <div><strong>Inscrito:</strong> {{ $inscrito->nombre }} (CI: {{ $inscrito->ci }})</div>
    <div><strong>Evaluador:</strong> {{ $evaluador->nombre }} {{ $evaluador->apellidos }}</div>
    <div><strong>Generado:</strong> {{ now()->format('Y-m-d H:i') }}</div>
    @if(!empty($fallback))<div><em>Nota:</em> Formato HTML (instala dompdf para PDF).</div>@endif
  </div>

  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Nota anterior</th>
        <th>Nota nueva</th>
        <th>Comentario anterior</th>
        <th>Comentario nuevo</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
      @forelse($rows as $i=>$r)
      <tr>
        <td>{{ $i+1 }}</td>
        <td>{{ $r->nota_anterior }}</td>
        <td>{{ $r->nota_nueva }}</td>
        <td>{{ $r->comentario_anterior }}</td>
        <td>{{ $r->comentario_nuevo }}</td>
        <td>{{ \Carbon\Carbon::parse($r->created_at)->format('Y-m-d H:i') }}</td>
      </tr>
      @empty
      <tr><td colspan="6">Sin cambios registrados.</td></tr>
      @endforelse
    </tbody>
  </table>
</body>
</html>
