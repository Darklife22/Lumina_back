// resources/views/pdf/responsables.blade.php
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Responsables Académicos</title>
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    h1 { font-size: 16px; margin-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 6px 8px; border: 1px solid #ccc; }
    th { background: #f1f1f1; text-align: left; }
  </style>
</head>
<body>
  <h1>Responsables Académicos</h1>
  <table>
    <thead>
      <tr>
        <th>Nombre</th><th>Email</th><th>Teléfono</th><th>Áreas</th>
      </tr>
    </thead>
    <tbody>
    @foreach ($items as $it)
      <tr>
        <td>{{ $it->nombre }}</td>
        <td>{{ $it->email }}</td>
        <td>{{ $it->telefono }}</td>
        <td>{{ $it->areas->pluck('nombre')->join(', ') }}</td>
      </tr>
    @endforeach
    </tbody>
  </table>
</body>
</html>
