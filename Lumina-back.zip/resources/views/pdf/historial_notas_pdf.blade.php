<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Historial de calificaciones</title>
<style>
  body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #ddd; padding: 6px; }
  th { background: #f3f3f3; }
  h1 { font-size: 16px; margin-bottom: 8px; }
  .muted { color: #666; font-size: 11px; }
</style>
</head>
<body>
  <h1>Historial de calificaciones</h1>
  <div class="muted">Generado: {{ $generado }}</div>
  <table>
    <thead>
      <tr>
        <th>Fecha</th><th>Participante</th><th>CI</th><th>Área</th><th>Nivel</th><th>Nota</th><th>Comentario</th><th>Evaluador</th>
      </tr>
    </thead>
    <tbody>
      @foreach($rows as $r)
        @php
          $r = (object) $r;
        @endphp
        <tr>
          <td>{{ $r->fecha_nota }}</td>
          <td>{{ $r->participante }}</td>
          <td>{{ $r->participante_ci }}</td>
          <td>{{ $r->area }}</td>
          <td>{{ $r->nivel }}</td>
          <td>{{ $r->nota }}</td>
          <td>{{ $r->comentario }}</td>
          <td>{{ trim(($r->evaluador_nombre ?? '').' '.($r->evaluador_apellidos ?? '')) }}</td>
        </tr>
      @endforeach
    </tbody>
  </table>
</body>
</html>
