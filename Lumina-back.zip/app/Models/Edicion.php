<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Edicion extends Model
{
    protected $table = 'ediciones';

    protected $fillable = [
        'anio',
        'nombre',
        'slug',
        'gestion',
        'fecha_inicio',
        'fecha_fin',
        'activa',
    ];

    protected $casts = [
        'anio'         => 'integer',
        'fecha_inicio' => 'date',
        'fecha_fin'    => 'date',
        'activa'       => 'boolean',
    ];

    protected $appends = [
        'nombre_oficial',
        'estado',
    ];

    /* ======================================================
     * RELACIONES
     * ====================================================== */

    public function areas(): BelongsToMany
    {
        return $this->belongsToMany(Area::class, 'area_edicion', 'edicion_id', 'area_id')
            ->withTimestamps();
    }

    public function niveles(): HasMany
    {
        return $this->hasMany(Nivel::class, 'edicion_id');
    }

    public function inscritos(): HasMany
    {
        return $this->hasMany(Inscrito::class, 'edicion_id');
    }

    /* ======================================================
     * ACCESSORS (front-friendly)
     * ====================================================== */

    public function getNombreOficialAttribute(): string
    {
        return (string) ($this->attributes['nombre'] ?? '');
    }

    public function getEstadoAttribute(): string
    {
        // Tu BD hoy distingue con activa=1 vs borrador=0.
        // Si más adelante metes "cerrada" como columna, lo actualizamos aquí sin tocar front.
        return $this->activa ? 'activa' : 'borrador';
    }

    /* ======================================================
     * SCOPES (operación)
     * ====================================================== */

    public function scopeActivas($query)
    {
        return $query->where('activa', 1);
    }

    public function scopeBorrador($query)
    {
        return $query->where('activa', 0);
    }

    public function scopeDelAnio($query, int $anio)
    {
        return $query->where('anio', $anio);
    }

    /* ======================================================
     * REGLAS DE NEGOCIO (locks)
     * ====================================================== */

    /**
     * Determina si la edición tiene datos operativos que bloquean cambios críticos
     * (áreas, estructura, tiempos, etc.).
     */
    public function tieneDatosOperativos(): bool
    {
        // Hoy ya tienes FK inscritos.edicion_id -> ediciones.id
        return $this->inscritos()->exists();
    }

    public function puedeEditarMetadatos(): bool
    {
        // Política: solo si está en borrador y no tiene datos
        return !$this->activa && !$this->tieneDatosOperativos();
    }

    public function puedeEditarEstructura(): bool
    {
        // Estructura = áreas/niveles/etapas/reglas base
        return !$this->activa && !$this->tieneDatosOperativos();
    }

    /* ======================================================
     * BOOT: slug/gestion consistentes
     * ====================================================== */

    protected static function booted()
    {
        static::creating(function (Edicion $ed) {
            // Si no viene gestion, usar año como string
            if (empty($ed->gestion) && !empty($ed->anio)) {
                $ed->gestion = (string) $ed->anio;
            }

            // Si no viene slug, generarlo de nombre + año
            if (empty($ed->slug)) {
                $base = trim(($ed->nombre ?? '') . ' ' . ($ed->anio ?? ''));
                $ed->slug = Str::slug($base);
            }
        });

        static::updating(function (Edicion $ed) {
            // Si cambian nombre o año, refrescar slug si quieres mantenerlo consistente.
            // En sistemas productivos, a veces NO se cambia el slug para no romper URLs.
            // Aquí lo dejamos “conservador”: solo si el slug está vacío.
            if (empty($ed->slug)) {
                $base = trim(($ed->nombre ?? '') . ' ' . ($ed->anio ?? ''));
                $ed->slug = Str::slug($base);
            }

            if (empty($ed->gestion) && !empty($ed->anio)) {
                $ed->gestion = (string) $ed->anio;
            }
        });
    }
}
