<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Nivel extends Model
{
    protected $table = 'niveles';

    protected $fillable = [
        'edicion_id',
        'nombre',
        'orden',
    ];

    protected $casts = [
        'edicion_id' => 'integer',
        'orden'      => 'integer',
    ];

    /* ======================================================
     * RELACIONES
     * ====================================================== */

    public function edicion(): BelongsTo
    {
        return $this->belongsTo(Edicion::class, 'edicion_id');
    }
}
