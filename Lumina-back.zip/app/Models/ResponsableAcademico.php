<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ResponsableAcademico extends Model
{
    use HasFactory;

    protected $table = 'responsables_academicos';

    /**
     * Campos asignables masivamente.
     * ✅ Incluye usuario_id para que se guarde el vínculo.
     * ✅ Incluye nivel porque existe en tu tabla.
     */
    protected $fillable = [
        'usuario_id',
        'nombre',
        'email',
        'telefono',
        'activo',
        'nivel',
    ];

    /**
     * Casts para tipos consistentes.
     */
    protected $casts = [
        'activo' => 'boolean',
    ];

    /**
     * Relación con Usuario (si existe vínculo).
     */
    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    /**
     * Áreas asignadas al responsable.
     * Pivot: area_responsable (responsable_id, area_id)
     */
    public function areas()
    {
        return $this->belongsToMany(
            Area::class,
            'area_responsable',
            'responsable_id',
            'area_id'
        );
    }

    // ==========================
    // Scopes (filtros reutilizables)
    // ==========================

    /**
     * Solo responsables activos.
     */
    public function scopeActivos($query)
    {
        return $query->where('activo', 1);
    }

    /**
     * Filtra por texto en nombre/email/telefono (para listados).
     */
    public function scopeSearch($query, string $q)
    {
        $q = trim($q);
        if ($q === '') return $query;

        $like = "%{$q}%";

        return $query->where(function ($w) use ($like) {
            $w->where('nombre', 'like', $like)
              ->orWhere('email', 'like', $like)
              ->orWhere('telefono', 'like', $like);
        });
    }

    // ==========================
    // Helpers (opcional)
    // ==========================

    /**
     * Vincula el responsable a un usuario.
     */
    public function vincularUsuario(Usuario $usuario): self
    {
        $this->usuario_id = $usuario->id;
        return $this;
    }

    /**
     * Si no hay usuario_id, intenta resolverlo por email.
     * Útil para migraciones/normalización.
     */
    public function resolverUsuarioIdPorEmail(): ?int
    {
        if ($this->usuario_id) return (int) $this->usuario_id;

        $email = trim((string) $this->email);
        if ($email === '') return null;

        $u = Usuario::query()->select('id')->where('email', $email)->first();
        return $u ? (int) $u->id : null;
    }
}
