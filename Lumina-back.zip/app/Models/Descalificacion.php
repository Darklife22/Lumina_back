<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Descalificacion extends Model
{
    protected $table = 'descalificaciones';

    protected $fillable = [
        'inscrito_id',
        'evaluador_id',
        'motivo',
    ];

    public function inscrito()
    {
        return $this->belongsTo(Inscrito::class);
    }

    public function evaluador()
    {
        return $this->belongsTo(Usuario::class, 'evaluador_id');
    }
}
