<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CalificacionLog extends Model
{
    protected $table = 'calificacion_logs';
    protected $fillable = [
        'inscrito_id','evaluador_id','calificacion_id',
        'nota_anterior','nota_nueva','comentario_anterior','comentario_nuevo',
        'changed_by'
    ];

    public function calificacion() { return $this->belongsTo(Calificacion::class); }
    public function inscrito() { return $this->belongsTo(Inscrito::class); }
    public function evaluador() { return $this->belongsTo(Usuario::class, 'evaluador_id'); }
    public function autor() { return $this->belongsTo(Usuario::class, 'changed_by'); }
}
