<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class Usuario extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'usuarios';

    /**
     * Campos asignables en masa
     */
    protected $fillable = [
        'nombre',
        'apellidos',
        'email',
        'password',
        'role_id',   // rol legacy (principal)
        'activo',
    ];

    /**
     * Campos ocultos al serializar
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Casts
     */
    protected $casts = [
        'activo' => 'boolean',
    ];

    // ============================================================
    // 🔹 RELACIONES
    // ============================================================

    /**
     * Rol LEGACY (1 a 1)
     * Se mantiene por compatibilidad
     */
    public function rol()
    {
        return $this->belongsTo(Rol::class, 'role_id');
    }

    /**
     * Roles REALES (Muchos a Muchos)
     * Tabla pivote: usuario_rol
     */
    public function roles()
    {
        return $this->belongsToMany(
            Rol::class,
            'usuario_rol',
            'usuario_id',
            'rol_id'
        )->withTimestamps();
    }

    /**
     * Relación con Evaluador (si existe)
     */
    public function evaluador()
    {
        return $this->hasOne(Evaluador::class, 'usuario_id');
    }

    /**
     * Relación con Responsable Académico (si existe)
     */
    public function responsableAcademico()
    {
        return $this->hasOne(ResponsableAcademico::class, 'usuario_id');
    }

    // ============================================================
    // 🔹 HELPERS DE NEGOCIO (CLAVE)
    // ============================================================

    /**
     * Verifica si el usuario tiene un rol (pivot o legacy)
     */
    public function hasRole(string $slug): bool
    {
        // 1️⃣ roles por pivot
        if ($this->relationLoaded('roles')) {
            if ($this->roles->contains('slug', $slug)) {
                return true;
            }
        } else {
            if ($this->roles()->where('slug', $slug)->exists()) {
                return true;
            }
        }

        // 2️⃣ rol legacy
        if ($this->rol && $this->rol->slug === $slug) {
            return true;
        }

        return false;
    }

    /**
     * Devuelve TODOS los roles del usuario (sin duplicados)
     */
    public function allRoleSlugs(): array
    {
        $roles = [];

        // roles pivot
        foreach ($this->roles()->pluck('slug')->all() as $r) {
            $roles[] = $r;
        }

        // rol legacy
        if ($this->rol?->slug && !in_array($this->rol->slug, $roles, true)) {
            $roles[] = $this->rol->slug;
        }

        return array_values(array_unique($roles));
    }

    /**
     * Atajo semántico (opcional)
     */
    public function isAdmin(): bool
    {
        return $this->hasRole('admin');
    }

    public function isEvaluador(): bool
    {
        return $this->hasRole('evaluador');
    }

    public function isResponsableArea(): bool
    {
        return $this->hasRole('responsable_area');
    }
}
