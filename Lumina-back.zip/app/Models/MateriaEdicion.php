<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MateriaEdicion extends Model
{
    use HasFactory;

    protected $table = 'materias_edicion';

    protected $fillable = [
        'edicion_id',
        'materia',
        'rango_min',
        'rango_max',
        'activo'
    ];

    protected $casts = [
        'activo' => 'boolean',
        'rango_min' => 'integer',
        'rango_max' => 'integer',
    ];

    /**
     * Edición padre
     */
    public function edicion()
    {
        return $this->belongsTo(Edicion::class, 'edicion_id');
    }

    /**
     * Evaluadores asignados
     */
    public function evaluadores()
    {
        return $this->belongsToMany(
            Evaluador::class,
            'evaluador_materia',
            'materia_edicion_id',
            'evaluador_id'
        )->withTimestamps();
    }
}
