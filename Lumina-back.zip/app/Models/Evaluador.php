<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evaluador extends Model
{
    use HasFactory;

    protected $table = 'evaluadores';

    protected $fillable = [
        'usuario_id',
        'nombre',
        'email',
        'telefono',
        'activo',
    ];

    protected $casts = [
        'activo' => 'boolean',
    ];

    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id');
    }

    // Compatibilidad con HUs que usen materias
    public function materias()
    {
        return $this->belongsToMany(
            MateriaEdicion::class,
            'evaluador_materia',
            'evaluador_id',
            'materia_edicion_id'
        )->withTimestamps();
    }

    // Áreas del evaluador
    public function areas()
    {
        return $this->belongsToMany(
            Area::class,
            'area_evaluador',   // asegúrate que tu pivote se llame así
            'evaluador_id',
            'area_id'
        )->withTimestamps();
    }
}
