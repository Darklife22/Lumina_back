<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    protected $table = 'areas';

    protected $fillable = [
        'nombre',
        'rango_min',
        'rango_max',
        'umbral_clasificacion',
        'activo',
    ];

    protected $casts = [
        'rango_min' => 'integer',
        'rango_max' => 'integer',
        'umbral_clasificacion' => 'integer',
        'activo' => 'boolean',
    ];

    public function ediciones()
    {
        return $this->belongsToMany(Edicion::class, 'area_edicion', 'area_id', 'edicion_id')
            ->withTimestamps();
    }
}
