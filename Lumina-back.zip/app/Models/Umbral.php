<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Umbral extends Model
{
    protected $table = 'umbrales';

    protected $fillable = [
        'edicion_id',
        'area_id',
        'nivel_id',
        'valor',
    ];

    public function edicion()
    {
        return $this->belongsTo(Edicion::class, 'edicion_id');
    }

    public function area()
    {
        return $this->belongsTo(Area::class, 'area_id');
    }
}
