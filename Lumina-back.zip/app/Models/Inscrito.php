<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inscrito extends Model
{
    protected $table = 'inscritos';

    protected $fillable = [
        'externo_id','nombre','ci','area','nivel','unidad_educativa','profesor','importado_en'
    ];

    protected $casts = [
        'importado_en' => 'datetime',
    ];
}
