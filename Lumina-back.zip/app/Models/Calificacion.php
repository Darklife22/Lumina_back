<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Calificacion extends Model
{
    protected $table = 'calificaciones';
    protected $fillable = ['inscrito_id','evaluador_id','nota','comentario'];

    public function inscrito() { return $this->belongsTo(Inscrito::class); }
    public function evaluador() { return $this->belongsTo(Usuario::class, 'evaluador_id'); }
    public function logs() { return $this->hasMany(CalificacionLog::class); }
}
