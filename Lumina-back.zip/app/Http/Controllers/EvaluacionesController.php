<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class EvaluacionesController extends Controller
{
    /**
     * GET /evaluador/historial
     * Lista calificaciones del evaluador autenticado.
     */
    public function historial(Request $request)
    {
        try {
            $user = $request->user();

            // Diagnóstico (no rompe la respuesta)
            $has = fn($t) => Schema::hasTable($t);
            $col = fn($t,$c) => Schema::hasColumn($t,$c);

            $diag = [
                'tables' => [
                    'calificaciones' => $has('calificaciones'),
                    'inscritos'      => $has('inscritos'),
                    'usuarios'       => $has('usuarios'),
                ],
                'columns' => [
                    'calificaciones' => [
                        'id'          => $col('calificaciones','id'),
                        'inscrito_id' => $col('calificaciones','inscrito_id'),
                        'evaluador_id'=> $col('calificaciones','evaluador_id'),
                        'nota'        => $col('calificaciones','nota'),
                        'comentario'  => $col('calificaciones','comentario'),
                        'created_at'  => $col('calificaciones','created_at'),
                    ],
                    'inscritos' => [
                        'id'      => $col('inscritos','id'),
                        'nombre'  => $col('inscritos','nombre'),
                        'ci'      => $col('inscritos','ci'),
                        'area'    => $col('inscritos','area'),
                        'nivel'   => $col('inscritos','nivel'),
                    ],
                    'usuarios' => [
                        'id'        => $col('usuarios','id'),
                        'nombre'    => $col('usuarios','nombre'),
                        'apellidos' => $col('usuarios','apellidos'),
                    ],
                ],
            ];

            // Si faltan tablas, no devuelvas 422: devuelve vacío y el diag
            if (!($diag['tables']['calificaciones'] && $diag['tables']['inscritos'])) {
                return response()->json([
                    'data' => [],
                    'meta' => ['page'=>1,'per_page'=>20,'total'=>0,'total_pages'=>0],
                    'diag' => $diag,
                    'ok'   => false,
                    'message' => 'BD incompleta: ejecuta migraciones o verifica la conexión.',
                ], 200);
            }

            // ==== Filtros ====
            $q       = trim((string) $request->query('q', ''));
            $from    = $request->query('from'); // YYYY-MM-DD recomendado
            $to      = $request->query('to');
            $area    = $request->query('area');
            $nivel   = $request->query('nivel');
            $page    = max(1, (int) $request->query('page', 1));
            $perPage = max(1, min(100, (int) $request->query('per_page', 20)));

            // ==== Base query ====
            $base = DB::table('calificaciones as c')
                ->join('inscritos as i', 'i.id', '=', 'c.inscrito_id')
                ->leftJoin('usuarios as u', 'u.id', '=', 'c.evaluador_id')
                ->selectRaw('
                    c.id,
                    c.nota,
                    c.comentario,
                    c.created_at as fecha_nota,
                    i.nombre as participante,
                    i.ci as participante_ci,
                    i.area,
                    i.nivel,
                    u.nombre as evaluador_nombre,
                    u.apellidos as evaluador_apellidos
                ')
                ->where('c.evaluador_id', $user->id);

            if ($q !== '') {
                $like = "%$q%";
                $base->where(function ($qq) use ($like) {
                    $qq->where('i.nombre', 'like', $like)
                       ->orWhere('i.ci', 'like', $like)
                       ->orWhere('i.area', 'like', $like)
                       ->orWhere('i.nivel', 'like', $like)
                       ->orWhere('c.comentario', 'like', $like);
                });
            }
            if ($area)  $base->where('i.area', $area);
            if ($nivel) $base->where('i.nivel', $nivel);
            if ($from)  $base->whereDate('c.created_at', '>=', $from);
            if ($to)    $base->whereDate('c.created_at', '<=', $to);

            $total = (clone $base)->count();
            $rows  = $base->orderByDesc('c.created_at')
                          ->forPage($page, $perPage)
                          ->get();

            return response()->json([
                'data' => $rows,
                'meta' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total'       => $total,
                    'total_pages' => (int) ceil($total / max(1, $perPage)),
                ],
                'diag' => $diag,
                'ok'   => true,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al consultar calificaciones.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * GET /evaluador/historial/export?format=csv|pdf
     * Exporta historial con los mismos filtros del listado.
     */
    public function exportHistorial(Request $request)
    {
        try {
            $user = $request->user();
            $format = strtolower((string)$request->query('format', 'csv'));

            $q     = trim((string) $request->query('q', ''));
            $from  = $request->query('from');
            $to    = $request->query('to');
            $area  = $request->query('area');
            $nivel = $request->query('nivel');

            $base = DB::table('calificaciones as c')
                ->join('inscritos as i', 'i.id', '=', 'c.inscrito_id')
                ->leftJoin('usuarios as u', 'u.id', '=', 'c.evaluador_id')
                ->selectRaw('
                    c.created_at as fecha,
                    i.nombre as participante,
                    i.ci,
                    i.area,
                    i.nivel,
                    c.nota,
                    c.comentario,
                    CONCAT(u.nombre, " ", u.apellidos) as evaluador
                ')
                ->where('c.evaluador_id', $user->id);

            if ($q !== '') {
                $like = "%$q%";
                $base->where(function ($qq) use ($like) {
                    $qq->where('i.nombre', 'like', $like)
                       ->orWhere('i.ci', 'like', $like)
                       ->orWhere('i.area', 'like', $like)
                       ->orWhere('i.nivel', 'like', $like)
                       ->orWhere('c.comentario', 'like', $like);
                });
            }
            if ($area)  $base->where('i.area', $area);
            if ($nivel) $base->where('i.nivel', $nivel);
            if ($from)  $base->whereDate('c.created_at', '>=', $from);
            if ($to)    $base->whereDate('c.created_at', '<=', $to);

            $rows = $base->orderByDesc('c.created_at')->get();

            if ($format === 'pdf') {
                // CSV por ahora (PDF requiere lib tipo barryvdh/laravel-dompdf)
                // Puedes cambiar a PDF cuando instales esa dependencia.
                $format = 'csv';
            }

            // CSV
            $headers = [
                'Content-Type' => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="historial_calificaciones.csv"',
            ];

            $callback = function () use ($rows) {
                $out = fopen('php://output', 'w');
                fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8
                fputcsv($out, ['Fecha', 'Participante', 'CI', 'Área', 'Nivel', 'Nota', 'Comentario', 'Evaluador']);
                foreach ($rows as $r) {
                    fputcsv($out, [
                        $r->fecha,
                        $r->participante,
                        $r->ci,
                        $r->area,
                        $r->nivel,
                        $r->nota,
                        $r->comentario,
                        $r->evaluador,
                    ]);
                }
                fclose($out);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al exportar historial.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
