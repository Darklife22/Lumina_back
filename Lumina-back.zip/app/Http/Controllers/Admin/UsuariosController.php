<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Usuario;
use App\Models\Rol;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;

class UsuariosController extends Controller
{
    /**
     * GET /admin/usuarios
     *
     * Filtros:
     *  - q: busca en nombre, apellidos, email, ci, telefono
     *  - activo: 1|0
     *
     * Paginación:
     *  - page, per_page
     */
    public function index(Request $request)
    {
        if (!Schema::hasTable('usuarios')) {
            return response()->json([
                'data' => [],
                'meta' => [
                    'page' => 1,
                    'per_page' => 15,
                    'total' => 0,
                    'total_pages' => 0,
                ],
            ]);
        }

        $q       = trim((string) $request->query('q', ''));
        $activo  = $request->query('activo', null); // '1' | '0' | null
        $page    = max(1, (int) $request->query('page', 1));
        $perPage = max(1, min(100, (int) $request->query('per_page', 15)));

        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');
        $hasActivo    = Schema::hasColumn('usuarios', 'activo');
        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');
        $hasCi        = Schema::hasColumn('usuarios', 'ci');

        $hasEvaluadores = Schema::hasTable('evaluadores');
        $hasRespAcad    = Schema::hasTable('responsables_academicos');

        // Subqueries "one-row-per-user" para no duplicar filas
        $evSub = null;
        if ($hasEvaluadores) {
            $evSub = DB::table('evaluadores')
                ->select('usuario_id', DB::raw('MAX(CASE WHEN activo = 1 THEN 1 ELSE 0 END) as es_evaluador'))
                ->groupBy('usuario_id');
        }

        $raSub = null;
        if ($hasRespAcad) {
            $raSub = DB::table('responsables_academicos')
                ->select('usuario_id', DB::raw('MAX(CASE WHEN activo = 1 THEN 1 ELSE 0 END) as es_responsable_area'))
                ->groupBy('usuario_id');
        }

        $baseSelect = [
            'usuarios.id',
            'usuarios.nombre',
            'usuarios.email',
            'usuarios.role_id',
        ];

        $query = Usuario::query()
            ->select($baseSelect)
            ->when($hasCi, fn($qq) => $qq->addSelect('usuarios.ci'))
            ->when($hasTelefono, fn($qq) => $qq->addSelect('usuarios.telefono'))
            ->when($hasActivo, fn($qq) => $qq->addSelect('usuarios.activo'))
            ->with(['rol:id,slug,nombre'])
            ->when($evSub !== null, function ($qq) use ($evSub) {
                $qq->leftJoinSub($evSub, 'ev', function ($j) {
                    $j->on('ev.usuario_id', '=', 'usuarios.id');
                });
                $qq->addSelect(DB::raw('COALESCE(ev.es_evaluador, 0) as es_evaluador'));
            })
            ->when($raSub !== null, function ($qq) use ($raSub) {
                $qq->leftJoinSub($raSub, 'ra', function ($j) {
                    $j->on('ra.usuario_id', '=', 'usuarios.id');
                });
                $qq->addSelect(DB::raw('COALESCE(ra.es_responsable_area, 0) as es_responsable_area'));
            })
            ->when($q !== '', function ($qq) use ($q, $hasApellidos, $hasTelefono, $hasCi) {
                $like = "%{$q}%";
                $qq->where(function ($w) use ($like, $hasApellidos, $hasTelefono, $hasCi) {
                    $w->where('usuarios.nombre', 'like', $like)
                      ->orWhere('usuarios.email', 'like', $like);

                    if ($hasApellidos) $w->orWhere('usuarios.apellidos', 'like', $like);
                    if ($hasCi)        $w->orWhere('usuarios.ci', 'like', $like);
                    if ($hasTelefono)  $w->orWhere('usuarios.telefono', 'like', $like);
                });
            })
            ->when($hasActivo && ($activo === '1' || $activo === '0'), function ($qq) use ($activo) {
                $qq->where('usuarios.activo', ((int) $activo) === 1);
            })
            ->orderBy('usuarios.id', 'desc');

        // Count sin duplicación (leftJoinSub no duplica, así que count directo sirve)
        $total = (clone $query)->count('usuarios.id');

        $rows = $query->forPage($page, $perPage)->get();

        $data = $rows->map(function ($u) use ($hasActivo, $hasTelefono, $hasCi, $hasEvaluadores, $hasRespAcad) {
            $roles = [];

            // Roles "reales"
            if ($hasEvaluadores && (int)($u->es_evaluador ?? 0) === 1) {
                $roles[] = 'evaluador';
            }
            if ($hasRespAcad && (int)($u->es_responsable_area ?? 0) === 1) {
                $roles[] = 'responsable_area';
            }

            // Rol legacy (role_id) => roles.slug (admin/consulta/etc.)
            $rolLegacy = $u->rol?->slug ?? null;
            if ($rolLegacy && !in_array($rolLegacy, $roles, true)) {
                $roles[] = $rolLegacy;
            }

            // Default si no hay nada
            if (empty($roles)) {
                $roles = ['usuario'];
            }

            return [
                'id'       => (int) $u->id,
                'nombre'   => (string) ($u->nombre ?? ''),
                'email'    => (string) ($u->email ?? ''),
                'ci'       => $hasCi ? ($u->ci ?? null) : null,
                'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,

                // legacy + roles reales
                'rol'      => $rolLegacy,
                'roles'    => $roles,

                'activo'   => $hasActivo ? (bool) $u->activo : true,
            ];
        });

        return response()->json([
            'data' => $data->values(),
            'meta' => [
                'page'        => $page,
                'per_page'    => $perPage,
                'total'       => $total,
                'total_pages' => (int) ceil($total / max(1, $perPage)),
            ],
        ]);
    }

    /**
     * POST /admin/usuarios
     */
    public function store(Request $request)
    {
        $hasActivo    = Schema::hasColumn('usuarios', 'activo');
        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');
        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');
        $hasCi        = Schema::hasColumn('usuarios', 'ci');

        $rules = [
            'nombre'    => ['required', 'string', 'max:100'],
            'email'     => ['required', 'email', 'max:150', 'unique:usuarios,email'],
            'password'  => ['required', 'string', 'min:6', 'confirmed'],
            'rol'       => ['nullable', 'string', 'max:50'], // slug legacy
            'activo'    => ['nullable', 'boolean'],
        ];
        if ($hasCi) $rules['ci'] = ['nullable', 'string', 'max:30'];
        if ($hasTelefono) $rules['telefono'] = ['nullable', 'string', 'max:30'];

        $data = $request->validate($rules);

        DB::beginTransaction();
        try {
            $roleId = null;
            if (!empty($data['rol'])) {
                $rol = Rol::firstOrCreate(
                    ['slug' => $data['rol']],
                    [
                        'nombre' => ucfirst($data['rol']),
                        'descripcion' => 'Rol auto-creado desde administración de usuarios',
                        'activo' => 1,
                    ]
                );
                $roleId = $rol->id;
            }

            $u = new Usuario();
            $u->nombre = $data['nombre'];
            $u->email  = $data['email'];
            $u->password = Hash::make($data['password']);

            if ($hasApellidos) {
                $u->apellidos = $u->apellidos ?? '';
            }
            if ($hasCi) {
                $u->ci = isset($data['ci']) && trim((string)$data['ci']) !== '' ? trim((string)$data['ci']) : null;
            }
            if ($hasTelefono) {
                $u->telefono = isset($data['telefono']) && trim((string)$data['telefono']) !== '' ? trim((string)$data['telefono']) : null;
            }

            if ($roleId !== null) {
                $u->role_id = $roleId;
            }

            if ($hasActivo) {
                $u->activo = array_key_exists('activo', $data) ? (bool) $data['activo'] : true;
            }

            $u->save();
            $u->load('rol:id,slug,nombre');

            // roles devueltos (recién creado normalmente no es evaluador/responsable todavía)
            $rolLegacy = $u->rol?->slug ?? null;
            $roles = $rolLegacy ? [$rolLegacy] : ['usuario'];

            DB::commit();

            return response()->json([
                'ok' => true,
                'message' => 'Usuario creado correctamente.',
                'data' => [
                    'id'       => (int) $u->id,
                    'nombre'   => $u->nombre,
                    'email'    => $u->email,
                    'ci'       => $hasCi ? ($u->ci ?? null) : null,
                    'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,
                    'rol'      => $rolLegacy,
                    'roles'    => $roles,
                    'activo'   => $hasActivo ? (bool) $u->activo : true,
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * PUT /admin/usuarios/{id}
     */
    public function update($id, Request $request)
    {
        $u = Usuario::findOrFail($id);

        $hasActivo    = Schema::hasColumn('usuarios', 'activo');
        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');
        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');
        $hasCi        = Schema::hasColumn('usuarios', 'ci');

        $rules = [
            'nombre' => ['required', 'string', 'max:100'],
            'email'  => [
                'required',
                'email',
                'max:150',
                Rule::unique('usuarios', 'email')->ignore($u->id),
            ],
            'rol'    => ['nullable', 'string', 'max:50'],
            'activo' => ['nullable', 'boolean'],
        ];
        if ($hasCi) $rules['ci'] = ['nullable', 'string', 'max:30'];
        if ($hasTelefono) $rules['telefono'] = ['nullable', 'string', 'max:30'];

        $data = $request->validate($rules);

        DB::beginTransaction();
        try {
            $u->nombre = $data['nombre'];
            $u->email  = $data['email'];

            if ($hasApellidos && $u->apellidos === null) {
                $u->apellidos = '';
            }
            if ($hasCi && array_key_exists('ci', $data)) {
                $u->ci = isset($data['ci']) && trim((string)$data['ci']) !== '' ? trim((string)$data['ci']) : null;
            }
            if ($hasTelefono && array_key_exists('telefono', $data)) {
                $u->telefono = isset($data['telefono']) && trim((string)$data['telefono']) !== '' ? trim((string)$data['telefono']) : null;
            }

            if (array_key_exists('rol', $data)) {
                if (!empty($data['rol'])) {
                    $rol = Rol::firstOrCreate(
                        ['slug' => $data['rol']],
                        [
                            'nombre' => ucfirst($data['rol']),
                            'descripcion' => 'Rol auto-creado desde administración de usuarios',
                            'activo' => 1,
                        ]
                    );
                    $u->role_id = $rol->id;
                } else {
                    $u->role_id = null;
                }
            }

            if ($hasActivo && array_key_exists('activo', $data)) {
                $u->activo = (bool) $data['activo'];
            }

            $u->save();
            $u->load('rol:id,slug,nombre');

            DB::commit();

            return response()->json([
                'ok' => true,
                'message' => 'Usuario actualizado correctamente.',
                'data' => [
                    'id'       => (int) $u->id,
                    'nombre'   => $u->nombre,
                    'email'    => $u->email,
                    'ci'       => $hasCi ? ($u->ci ?? null) : null,
                    'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,
                    'rol'      => $u->rol?->slug ?? null,
                    'activo'   => $hasActivo ? (bool) $u->activo : true,
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/usuarios/{id}/toggle-activo
     */
    public function toggleActivo($id)
    {
        $u = Usuario::findOrFail($id);

        if (!Schema::hasColumn('usuarios', 'activo')) {
            return response()->json([
                'ok' => false,
                'message' => 'La tabla usuarios no tiene columna "activo".',
            ], 422);
        }

        DB::beginTransaction();
        try {
            $u->activo = !$u->activo;
            $u->save();

            DB::commit();

            return response()->json([
                'ok' => true,
                'message' => $u->activo ? 'Usuario activado.' : 'Usuario desactivado.',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * DELETE /admin/usuarios/{id}
     */
    public function destroy($id)
    {
        $u = Usuario::findOrFail($id);

        DB::beginTransaction();
        try {
            if (Schema::hasTable('evaluadores')) {
                $existsEv = DB::table('evaluadores')->where('usuario_id', $u->id)->exists();
                if ($existsEv) {
                    DB::rollBack();
                    return response()->json([
                        'ok' => false,
                        'message' => 'No se puede eliminar: el usuario tiene rol de evaluador asociado. Primero quita el rol.',
                    ], 422);
                }
            }

            if (Schema::hasTable('responsables_academicos')) {
                $existsResp = DB::table('responsables_academicos')->where('usuario_id', $u->id)->exists();
                if ($existsResp) {
                    DB::rollBack();
                    return response()->json([
                        'ok' => false,
                        'message' => 'No se puede eliminar: el usuario tiene rol de responsable asociado. Primero quita el rol.',
                    ], 422);
                }
            }

            $u->delete();

            DB::commit();

            return response()->json([
                'ok' => true,
                'message' => 'Usuario eliminado correctamente.',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok' => false,
                'message' => $e->getMessage(),
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
