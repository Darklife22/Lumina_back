<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class NivelesAdminController extends Controller
{
    /**
     * GET /admin/niveles
     * Catálogo global de niveles (para configuración de ediciones)
     */
    public function index()
    {
        try {
            if (!Schema::hasTable('niveles')) {
                return response()->json([
                    'ok' => true,
                    'data' => [],
                ], 200);
            }

            $query = DB::table('niveles')
                ->select('id', 'nombre', 'orden');

            // Opcionales si existen
            if (Schema::hasColumn('niveles', 'codigo')) {
                $query->addSelect('codigo');
            }
            if (Schema::hasColumn('niveles', 'activo')) {
                $query->where('activo', 1);
            }

            $niveles = $query
                ->orderBy('orden')
                ->orderBy('nombre')
                ->get();

            return response()->json([
                'ok' => true,
                'data' => $niveles,
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo cargar el catálogo de niveles.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
