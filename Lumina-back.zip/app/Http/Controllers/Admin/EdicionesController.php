<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class EdicionesController extends Controller
{
    /* ======================================================
     * GET /admin/ediciones
     * Lista + KPIs (safe con Schema)
     * ====================================================== */
    public function index()
    {
        try {
            $this->assertEdicionesTable();

            $rows = DB::table('ediciones')
                ->select(
                    'ediciones.id',
                    'ediciones.anio',
                    DB::raw('ediciones.nombre AS nombre_oficial'),
                    'ediciones.fecha_inicio',
                    'ediciones.fecha_fin',
                    DB::raw("
                        CASE
                            WHEN ediciones.activa = 1 THEN 'activa'
                            ELSE 'borrador'
                        END AS estado
                    "),
                    'ediciones.created_at'
                )
                ->orderByDesc('ediciones.anio')
                ->orderByDesc('ediciones.created_at')
                ->get();

            $hasPivotAreas  = Schema::hasTable('area_edicion');
            $hasNivelesScop = Schema::hasTable('niveles') && Schema::hasColumn('niveles', 'edicion_id');
            $hasInscritos   = Schema::hasTable('inscritos') && Schema::hasColumn('inscritos', 'edicion_id');
            $hasResponsables = Schema::hasTable('responsables_academicos') && Schema::hasColumn('responsables_academicos', 'edicion_id');
            $hasEvaluadores  = Schema::hasTable('evaluadores') && Schema::hasColumn('evaluadores', 'edicion_id');

            $rows = $rows->map(function ($e) use ($hasPivotAreas, $hasNivelesScop, $hasInscritos, $hasResponsables, $hasEvaluadores) {
                $stats = [];

                if ($hasPivotAreas)   $stats['areas'] = (int) DB::table('area_edicion')->where('edicion_id', $e->id)->count();
                if ($hasNivelesScop)  $stats['niveles'] = (int) DB::table('niveles')->where('edicion_id', $e->id)->count();
                if ($hasInscritos)    $stats['inscritos'] = (int) DB::table('inscritos')->where('edicion_id', $e->id)->count();
                if ($hasResponsables) $stats['responsables'] = (int) DB::table('responsables_academicos')->where('edicion_id', $e->id)->count();
                if ($hasEvaluadores)  $stats['evaluadores'] = (int) DB::table('evaluadores')->where('edicion_id', $e->id)->count();

                $e->stats = (object) $stats;
                return $e;
            });

            return response()->json(['ok' => true, 'data' => $rows], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al listar ediciones.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * GET /admin/ediciones/{id}
     * ====================================================== */
    public function show(int $id)
    {
        try {
            $this->assertEdicionesTable();

            $edicion = DB::table('ediciones')
                ->select(
                    'id',
                    'anio',
                    DB::raw('nombre AS nombre_oficial'),
                    'fecha_inicio',
                    'fecha_fin',
                    DB::raw("CASE WHEN activa = 1 THEN 'activa' ELSE 'borrador' END AS estado"),
                    'created_at',
                    'updated_at'
                )
                ->where('id', $id)
                ->first();

            if (!$edicion) {
                return response()->json(['ok' => false, 'message' => 'Edición no encontrada.'], 404);
            }

            $stats = $this->kpisEdicion($id);
            $locks = $this->locksEdicion($id);

            return response()->json([
                'ok' => true,
                'data' => [
                    'id' => $edicion->id,
                    'anio' => $edicion->anio,
                    'nombre_oficial' => $edicion->nombre_oficial,
                    'fecha_inicio' => $edicion->fecha_inicio,
                    'fecha_fin' => $edicion->fecha_fin,
                    'estado' => $edicion->estado,
                    'created_at' => $edicion->created_at,
                    'updated_at' => $edicion->updated_at,
                    'stats' => $stats,
                    'locks' => $locks,
                ],
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo cargar la competencia.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * GET /admin/ediciones/{id}/configuracion
     * ====================================================== */
    public function getConfiguracion(int $id)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            $deps = [
                'inscritos' => (Schema::hasTable('inscritos') && Schema::hasColumn('inscritos', 'edicion_id'))
                    ? (int) DB::table('inscritos')->where('edicion_id', $id)->count()
                    : 0,
                'evaluaciones' => 0,
                'resultados' => 0,
            ];

            if (Schema::hasTable('evaluaciones') && Schema::hasColumn('evaluaciones', 'edicion_id')) {
                $deps['evaluaciones'] = (int) DB::table('evaluaciones')->where('edicion_id', $id)->count();
            }
            if (Schema::hasTable('resultados') && Schema::hasColumn('resultados', 'edicion_id')) {
                $deps['resultados'] = (int) DB::table('resultados')->where('edicion_id', $id)->count();
            }

            $areaIds = [];
            if (Schema::hasTable('area_edicion')) {
                $areaIds = DB::table('area_edicion')
                    ->where('edicion_id', $id)
                    ->pluck('area_id')
                    ->map(fn($v) => (int)$v)
                    ->toArray();
            }

            // nivel_ids: mantenemos compat con tu pantalla de configuración (global)
            $nivelIds = [];
            if (Schema::hasTable('nivel_edicion')) {
                $nivelIds = DB::table('nivel_edicion')
                    ->where('edicion_id', $id)
                    ->pluck('nivel_id')
                    ->map(fn($v) => (int)$v)
                    ->toArray();
            } elseif (Schema::hasTable('niveles') && Schema::hasColumn('niveles', 'edicion_id')) {
                $nivelIds = DB::table('niveles')
                    ->where('edicion_id', $id)
                    ->pluck('id')
                    ->map(fn($v) => (int)$v)
                    ->toArray();
            } elseif (Schema::hasTable('area_nivel_edicion')) {
                // si existe pivot por área, podemos devolver el set global sin romper el front
                $nivelIds = DB::table('area_nivel_edicion')
                    ->where('edicion_id', $id)
                    ->pluck('nivel_id')
                    ->unique()
                    ->map(fn($v)=>(int)$v)
                    ->values()
                    ->toArray();
            }

            $etapas = $this->defaultEtapas();
            if (Schema::hasTable('edicion_etapas') && Schema::hasColumn('edicion_etapas', 'edicion_id')) {
                $etapas = DB::table('edicion_etapas')
                    ->where('edicion_id', $id)
                    ->orderBy('orden')
                    ->get(['key', 'nombre', 'orden', 'inicio', 'fin', 'habilitada'])
                    ->map(function ($e) {
                        return [
                            'key' => $e->key,
                            'nombre' => $e->nombre,
                            'orden' => (int) $e->orden,
                            'inicio' => $e->inicio,
                            'fin' => $e->fin,
                            'habilitada' => (bool) $e->habilitada,
                        ];
                    })
                    ->toArray();
            }

            $reglasBase = [
                'tipo' => 'mixta',
                'umbral_min' => 60,
                'top_n' => 10,
                'nota_min_aprob' => 51,
            ];

            if (Schema::hasTable('edicion_reglas') && Schema::hasColumn('edicion_reglas', 'edicion_id')) {
                $r = DB::table('edicion_reglas')->where('edicion_id', $id)->first();
                if ($r) {
                    $reglasBase = [
                        'tipo' => $r->tipo ?? 'mixta',
                        'umbral_min' => isset($r->umbral_min) ? (float) $r->umbral_min : null,
                        'top_n' => isset($r->top_n) ? (int) $r->top_n : null,
                        'nota_min_aprob' => isset($r->nota_min_aprob) ? (float) $r->nota_min_aprob : null,
                    ];
                }
            }

            $locks = $this->locksConfigByDeps($deps);

            return response()->json([
                'ok' => true,
                'data' => [
                    'area_ids' => $areaIds,
                    'nivel_ids' => $nivelIds,
                    'etapas' => $etapas,
                    'reglas_base' => $reglasBase,
                    'locks' => $locks,
                    'deps' => $deps,
                ],
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo cargar la configuración.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * PUT /admin/ediciones/{id}/configuracion
     * ====================================================== */
    public function updateConfiguracion(int $id, Request $request)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            $deps = [
                'inscritos' => (Schema::hasTable('inscritos') && Schema::hasColumn('inscritos', 'edicion_id'))
                    ? (int) DB::table('inscritos')->where('edicion_id', $id)->count()
                    : 0,
                'evaluaciones' => (Schema::hasTable('evaluaciones') && Schema::hasColumn('evaluaciones', 'edicion_id'))
                    ? (int) DB::table('evaluaciones')->where('edicion_id', $id)->count()
                    : 0,
                'resultados' => (Schema::hasTable('resultados') && Schema::hasColumn('resultados', 'edicion_id'))
                    ? (int) DB::table('resultados')->where('edicion_id', $id)->count()
                    : 0,
            ];

            $locks = $this->locksConfigByDeps($deps);

            $data = $request->validate([
                'area_ids' => ['nullable', 'array'],
                'area_ids.*' => ['integer'],
                'nivel_ids' => ['nullable', 'array'],
                'nivel_ids.*' => ['integer'],
                'etapas' => ['nullable', 'array'],
                'reglas_base' => ['nullable', 'array'],
            ]);

            return DB::transaction(function () use ($id, $data, $locks) {

                // -------------------------
                // ESTRUCTURA: ÁREAS
                // -------------------------
                if (!$locks['estructura']) {
                    if (Schema::hasTable('area_edicion')) {
                        $ids = array_values(array_unique(array_map('intval', $data['area_ids'] ?? [])));

                        if (Schema::hasTable('areas')) {
                            $ids = DB::table('areas')->whereIn('id', $ids)->pluck('id')->map(fn($v)=>(int)$v)->toArray();
                        }

                        DB::table('area_edicion')->where('edicion_id', $id)->delete();

                        foreach ($ids as $areaId) {
                            DB::table('area_edicion')->insert([
                                'edicion_id' => $id,
                                'area_id' => $areaId,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    }
                }

                // -------------------------
                // ESTRUCTURA: NIVELES (legacy/global)
                // -------------------------
                if (!$locks['estructura']) {
                    $nivelIds = array_values(array_unique(array_map('intval', $data['nivel_ids'] ?? [])));

                    if (Schema::hasTable('nivel_edicion')) {
                        if (Schema::hasTable('niveles')) {
                            $nivelIds = DB::table('niveles')->whereIn('id', $nivelIds)->pluck('id')->map(fn($v)=>(int)$v)->toArray();
                        }
                        DB::table('nivel_edicion')->where('edicion_id', $id)->delete();
                        foreach ($nivelIds as $nid) {
                            DB::table('nivel_edicion')->insert([
                                'edicion_id' => $id,
                                'nivel_id' => $nid,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ]);
                        }
                    } elseif (Schema::hasTable('niveles') && Schema::hasColumn('niveles', 'edicion_id')) {
                        // Modelo scoped: aquí NO tocamos catálogo por seguridad
                    }
                }

                // -------------------------
                // ETAPAS
                // -------------------------
                if (!$locks['etapas'] && Schema::hasTable('edicion_etapas') && Schema::hasColumn('edicion_etapas', 'edicion_id')) {
                    $etapas = $data['etapas'] ?? [];
                    foreach ($etapas as $et) {
                        if (!isset($et['key'])) continue;

                        DB::table('edicion_etapas')->updateOrInsert(
                            ['edicion_id' => $id, 'key' => $et['key']],
                            [
                                'nombre' => $et['nombre'] ?? $et['key'],
                                'orden' => isset($et['orden']) ? (int)$et['orden'] : 1,
                                'inicio' => $et['inicio'] ?? null,
                                'fin' => $et['fin'] ?? null,
                                'habilitada' => isset($et['habilitada']) ? (int)!!$et['habilitada'] : 1,
                                'updated_at' => now(),
                                'created_at' => now(),
                            ]
                        );
                    }
                }

                // -------------------------
                // REGLAS BASE
                // -------------------------
                if (!$locks['reglas'] && Schema::hasTable('edicion_reglas') && Schema::hasColumn('edicion_reglas', 'edicion_id')) {
                    $rb = $data['reglas_base'] ?? [];
                    DB::table('edicion_reglas')->updateOrInsert(
                        ['edicion_id' => $id],
                        [
                            'tipo' => $rb['tipo'] ?? 'mixta',
                            'umbral_min' => $rb['umbral_min'] ?? null,
                            'top_n' => $rb['top_n'] ?? null,
                            'nota_min_aprob' => $rb['nota_min_aprob'] ?? null,
                            'updated_at' => now(),
                            'created_at' => now(),
                        ]
                    );
                }

                return response()->json(['ok' => true], 200);
            });

        } catch (\Illuminate\Validation\ValidationException $ve) {
            return response()->json([
                'ok' => false,
                'message' => 'Datos inválidos.',
                'errors' => $ve->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo guardar la configuración.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * GET /admin/ediciones/{id}/roles
     * ====================================================== */
    public function roles(int $id)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            $data = [
                'responsables' => [],
                'evaluadores' => [],
            ];

            if (Schema::hasTable('responsables_academicos')) {
                $q = DB::table('responsables_academicos');

                if (Schema::hasColumn('responsables_academicos', 'edicion_id')) {
                    $q->where('responsables_academicos.edicion_id', $id);
                }

                if (Schema::hasColumn('responsables_academicos', 'user_id') && Schema::hasTable('users')) {
                    $q->leftJoin('users', 'users.id', '=', 'responsables_academicos.user_id')
                      ->addSelect([
                          'responsables_academicos.id',
                          'responsables_academicos.user_id',
                          DB::raw("COALESCE(users.name, '') AS usuario_nombre"),
                          DB::raw("COALESCE(users.email, '') AS usuario_email"),
                      ]);
                } else {
                    $q->addSelect('responsables_academicos.*');
                }

                if (Schema::hasColumn('responsables_academicos', 'area_id') && Schema::hasTable('areas')) {
                    $q->leftJoin('areas', 'areas.id', '=', 'responsables_academicos.area_id')
                      ->addSelect(DB::raw("COALESCE(areas.nombre, '') AS area_nombre"));
                }

                $data['responsables'] = $q->orderByDesc('responsables_academicos.id')->get()->toArray();
            }

            if (Schema::hasTable('evaluadores')) {
                $q = DB::table('evaluadores');

                if (Schema::hasColumn('evaluadores', 'edicion_id')) {
                    $q->where('evaluadores.edicion_id', $id);
                }

                if (Schema::hasColumn('evaluadores', 'user_id') && Schema::hasTable('users')) {
                    $q->leftJoin('users', 'users.id', '=', 'evaluadores.user_id')
                      ->addSelect([
                          'evaluadores.id',
                          'evaluadores.user_id',
                          DB::raw("COALESCE(users.name, '') AS usuario_nombre"),
                          DB::raw("COALESCE(users.email, '') AS usuario_email"),
                      ]);
                } else {
                    $q->addSelect('evaluadores.*');
                }

                $data['evaluadores'] = $q->orderByDesc('evaluadores.id')->get()->toArray();
            }

            return response()->json(['ok' => true, 'data' => $data], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo cargar roles de la competencia.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * GET /admin/ediciones/{id}/inscritos?q=&page=1&page_size=20
     * ====================================================== */
    public function inscritos(int $id, Request $request)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            if (!Schema::hasTable('inscritos') || !Schema::hasColumn('inscritos', 'edicion_id')) {
                return response()->json([
                    'ok' => true,
                    'data' => [],
                    'meta' => [
                        'page' => 1,
                        'page_size' => 20,
                        'total' => 0,
                        'total_pages' => 0,
                    ],
                ], 200);
            }

            $q = trim((string) $request->query('q', ''));
            $page = max(1, (int) $request->query('page', 1));
            $pageSize = (int) $request->query('page_size', 20);
            $pageSize = min(max($pageSize, 1), 200);

            $select = ['id', 'edicion_id', 'created_at'];
            foreach (['nombre', 'apellido', 'ci', 'colegio', 'nivel_id', 'area_id', 'estado'] as $c) {
                if (Schema::hasColumn('inscritos', $c)) $select[] = $c;
            }

            $base = DB::table('inscritos')->where('edicion_id', $id);

            if ($q !== '') {
                $base->where(function ($w) use ($q) {
                    $like = '%' . $q . '%';
                    if (Schema::hasColumn('inscritos', 'nombre')) $w->orWhere('nombre', 'like', $like);
                    if (Schema::hasColumn('inscritos', 'apellido')) $w->orWhere('apellido', 'like', $like);
                    if (Schema::hasColumn('inscritos', 'ci')) $w->orWhere('ci', 'like', $like);
                    if (Schema::hasColumn('inscritos', 'colegio')) $w->orWhere('colegio', 'like', $like);
                    $w->orWhere('id', is_numeric($q) ? (int)$q : -1);
                });
            }

            $total = (int) (clone $base)->count();
            $rows = $base
                ->orderByDesc('id')
                ->offset(($page - 1) * $pageSize)
                ->limit($pageSize)
                ->get($select);

            $totalPages = (int) ceil($total / $pageSize);

            return response()->json([
                'ok' => true,
                'data' => $rows,
                'meta' => [
                    'page' => $page,
                    'page_size' => $pageSize,
                    'total' => $total,
                    'total_pages' => $totalPages,
                ],
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'No se pudo cargar inscritos.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * POST /admin/ediciones
     * Crear edición + (heredar) + estructura_base (areas + niveles por area)
     * + etapas + reglas base
     * ====================================================== */
    public function store(Request $request)
    {
        try {
            $this->assertEdicionesTable();

            $data = $request->validate([
                'anio'           => ['required', 'integer', 'min:2000', 'max:2100'],
                'nombre_oficial' => ['required', 'string', 'max:150'],
                'fecha_inicio'   => ['required', 'date'],
                'fecha_fin'      => ['required', 'date', 'after_or_equal:fecha_inicio'],

                'estado'         => ['nullable', 'in:borrador,activa,cerrada'],

                'heredar_de'     => ['nullable', 'integer', 'exists:ediciones,id'],

                // estructura nueva (si no hereda)
                'estructura_base' => ['nullable', 'array'],
                'estructura_base.areas_ids' => ['nullable', 'array'],
                'estructura_base.areas_ids.*' => ['integer'],
                // mapa: { "4": [1,2], "8": [2] }
                'estructura_base.area_nivel_ids' => ['nullable', 'array'],

                // etapas y reglas para inicialización
                'etapas' => ['nullable', 'array'],
                'reglas_base' => ['nullable', 'array'],
            ]);

            if (DB::table('ediciones')->where('anio', $data['anio'])->exists()) {
                return response()->json([
                    'ok' => false,
                    'message' => "Ya existe una edición para el año {$data['anio']}.",
                ], 422);
            }

            return DB::transaction(function () use ($data) {

                $estado = $data['estado'] ?? 'borrador';
                $activa = ($estado === 'activa') ? 1 : 0;

                $id = DB::table('ediciones')->insertGetId([
                    'anio'         => (int) $data['anio'],
                    'nombre'       => $data['nombre_oficial'],
                    'slug'         => Str::slug($data['nombre_oficial'] . '-' . $data['anio']),
                    'gestion'      => (string) $data['anio'],
                    'fecha_inicio' => $data['fecha_inicio'],
                    'fecha_fin'    => $data['fecha_fin'],
                    'activa'       => $activa,
                    'created_at'   => now(),
                    'updated_at'   => now(),
                ]);

                // 1) HEREDAR
                if (!empty($data['heredar_de'])) {
                    $this->clonarConfiguracionBase($id, (int) $data['heredar_de']);
                } else {
                    // 2) NUEVA ESTRUCTURA (ÁREAS + NIVELES POR ÁREA)
                    $estructura = $data['estructura_base'] ?? null;

                    if (is_array($estructura)) {
                        $areasIds = array_values(array_unique(array_map('intval', $estructura['areas_ids'] ?? [])));
                        $areaNivelIds = $estructura['area_nivel_ids'] ?? [];

                        // normalización y guardado de áreas
                        $this->persistAreasForEdicion($id, $areasIds);

                        // niveles por área: solo si existe pivot recomendado
                        $this->persistAreaNivelesForEdicion($id, $areasIds, $areaNivelIds);
                    }
                }

                // 3) ETAPAS (si existe tabla)
                if (!empty($data['etapas'])) {
                    $this->persistEtapasIniciales($id, $data['etapas']);
                } else {
                    // opcional: sembrar etapas default si existe tabla
                    $this->persistEtapasIniciales($id, $this->defaultEtapas());
                }

                // 4) REGLAS BASE (si existe tabla)
                if (!empty($data['reglas_base'])) {
                    $this->persistReglasBase($id, $data['reglas_base']);
                } else {
                    $this->persistReglasBase($id, [
                        'tipo' => 'mixta',
                        'umbral_min' => 60,
                        'top_n' => 10,
                        'nota_min_aprob' => 51,
                    ]);
                }

                $edicion = DB::table('ediciones')
                    ->select(
                        'id',
                        'anio',
                        DB::raw('nombre AS nombre_oficial'),
                        'fecha_inicio',
                        'fecha_fin',
                        DB::raw("
                            CASE
                                WHEN activa = 1 THEN 'activa'
                                ELSE 'borrador'
                            END AS estado
                        "),
                        'created_at'
                    )
                    ->where('id', $id)
                    ->first();

                // KPIs de salida (para que el front actualice rápido)
                $edicion->stats = (object) $this->kpisEdicion($id);

                return response()->json(['ok' => true, 'data' => $edicion], 201);
            });

        } catch (\Illuminate\Validation\ValidationException $ve) {
            return response()->json([
                'ok' => false,
                'message' => 'Datos inválidos para crear la edición.',
                'errors' => $ve->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al crear la nueva edición.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * PUT /admin/ediciones/{id}
     * ====================================================== */
    public function update(int $id, Request $request)
    {
        try {
            $this->assertEdicionesTable();

            $edicion = DB::table('ediciones')->where('id', $id)->first();
            if (!$edicion) {
                return response()->json(['ok' => false, 'message' => 'Edición no encontrada.'], 404);
            }

            if ((int) $edicion->activa === 1) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No se puede editar una edición activa.',
                ], 422);
            }

            if ($this->edicionTieneDatos($id)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No se puede editar: la edición ya tiene inscritos o datos asociados.',
                ], 422);
            }

            $data = $request->validate([
                'nombre_oficial' => ['required', 'string', 'max:150'],
                'fecha_inicio'   => ['required', 'date'],
                'fecha_fin'      => ['required', 'date', 'after_or_equal:fecha_inicio'],
            ]);

            DB::table('ediciones')->where('id', $id)->update([
                'nombre'       => $data['nombre_oficial'],
                'slug'         => Str::slug($data['nombre_oficial'] . '-' . ($edicion->anio ?? '')),
                'fecha_inicio' => $data['fecha_inicio'],
                'fecha_fin'    => $data['fecha_fin'],
                'updated_at'   => now(),
            ]);

            return response()->json(['ok' => true], 200);

        } catch (\Illuminate\Validation\ValidationException $ve) {
            return response()->json([
                'ok' => false,
                'message' => 'Datos inválidos.',
                'errors' => $ve->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al actualizar edición.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * PATCH /admin/ediciones/{id}/estado
     * ====================================================== */
    public function cambiarEstado(int $id, Request $request)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            $data = $request->validate([
                'estado' => ['required', 'in:borrador,activa,cerrada'],
            ]);

            // Aquí tu BD solo maneja "activa". "cerrada" se maneja a nivel app/flag adicional si luego lo agregas.
            $activa = $data['estado'] === 'activa' ? 1 : 0;

            DB::table('ediciones')->where('id', $id)->update([
                'activa' => $activa,
                'updated_at' => now(),
            ]);

            return response()->json(['ok' => true], 200);

        } catch (\Illuminate\Validation\ValidationException $ve) {
            return response()->json([
                'ok' => false,
                'message' => 'Datos inválidos.',
                'errors' => $ve->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al cambiar estado.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * GET /admin/ediciones/{id}/areas
     * ====================================================== */
    public function areas(int $id)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            return response()->json([
                'ok' => true,
                'data' => $this->getAreasByEdicion($id),
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al obtener áreas de la edición.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * POST /admin/ediciones/{id}/areas
     * ====================================================== */
    public function attachAreas(int $id, Request $request)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            if ($this->edicionTieneDatos($id)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No se pueden modificar áreas: la edición ya tiene datos.',
                ], 422);
            }

            if (!Schema::hasTable('area_edicion') || !Schema::hasTable('areas')) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No existe la relación (areas / area_edicion).',
                ], 500);
            }

            $data = $request->validate([
                'areas_ids'   => ['required', 'array', 'min:1'],
                'areas_ids.*' => ['integer', 'exists:areas,id'],
            ]);

            foreach (array_values(array_unique($data['areas_ids'])) as $areaId) {
                DB::table('area_edicion')->updateOrInsert(
                    ['edicion_id' => $id, 'area_id' => $areaId],
                    ['updated_at' => now(), 'created_at' => now()]
                );
            }

            return response()->json([
                'ok' => true,
                'data' => $this->getAreasByEdicion($id),
            ], 200);

        } catch (\Illuminate\Validation\ValidationException $ve) {
            return response()->json([
                'ok' => false,
                'message' => 'Datos inválidos.',
                'errors' => $ve->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al asociar áreas.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * DELETE /admin/ediciones/{id}/areas/{areaId}
     * ====================================================== */
    public function detachArea(int $id, int $areaId)
    {
        try {
            $this->assertEdicionesTable();
            $this->assertEdicionExists($id);

            if ($this->edicionTieneDatos($id)) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No se pueden quitar áreas: la edición ya tiene datos.',
                ], 422);
            }

            if (!Schema::hasTable('area_edicion')) {
                return response()->json([
                    'ok' => false,
                    'message' => 'No existe la tabla pivote area_edicion.',
                ], 500);
            }

            DB::table('area_edicion')
                ->where('edicion_id', $id)
                ->where('area_id', $areaId)
                ->delete();

            return response()->json([
                'ok' => true,
                'data' => $this->getAreasByEdicion($id),
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok' => false,
                'message' => 'Error al desvincular área.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /* ======================================================
     * HELPERS (enterprise-safe)
     * ====================================================== */

    private function assertEdicionesTable(): void
    {
        if (!Schema::hasTable('ediciones')) {
            throw new \RuntimeException('La tabla ediciones no existe.');
        }
    }

    private function assertEdicionExists(int $id): void
    {
        if (!DB::table('ediciones')->where('id', $id)->exists()) {
            throw new \RuntimeException('Edición no encontrada.');
        }
    }

    private function edicionTieneDatos(int $id): bool
    {
        if (!Schema::hasTable('inscritos') || !Schema::hasColumn('inscritos', 'edicion_id')) {
            return false;
        }
        return DB::table('inscritos')->where('edicion_id', $id)->exists();
    }

    private function locksEdicion(int $id): array
    {
        $tieneDatos = $this->edicionTieneDatos($id);
        return [
            'estructura' => $tieneDatos,
            'tiempos' => $tieneDatos,
            'etapas' => $tieneDatos,
            'reglas' => $tieneDatos,
        ];
    }

    private function locksConfigByDeps(array $deps): array
    {
        $ins = (int) ($deps['inscritos'] ?? 0);
        $eva = (int) ($deps['evaluaciones'] ?? 0);
        $res = (int) ($deps['resultados'] ?? 0);

        return [
            'estructura' => ($ins > 0 || $eva > 0 || $res > 0),
            'tiempos'    => ($eva > 0 || $res > 0),
            'etapas'     => ($eva > 0 || $res > 0),
            'reglas'     => ($eva > 0 || $res > 0),
        ];
    }

    private function kpisEdicion(int $id): array
    {
        $stats = [
            'areas' => 0,
            'niveles' => 0,
            'inscritos' => 0,
            'responsables' => 0,
            'evaluadores' => 0,
        ];

        if (Schema::hasTable('area_edicion')) {
            $stats['areas'] = (int) DB::table('area_edicion')->where('edicion_id', $id)->count();
        }

        // si manejas niveles por edicion_id (legacy)
        if (Schema::hasTable('niveles') && Schema::hasColumn('niveles', 'edicion_id')) {
            $stats['niveles'] = (int) DB::table('niveles')->where('edicion_id', $id)->count();
        }
        // si manejas niveles por pivot por área (enterprise)
        elseif (Schema::hasTable('area_nivel_edicion')) {
            $stats['niveles'] = (int) DB::table('area_nivel_edicion')->where('edicion_id', $id)->distinct('nivel_id')->count('nivel_id');
        }
        // si manejas niveles por pivot global
        elseif (Schema::hasTable('nivel_edicion')) {
            $stats['niveles'] = (int) DB::table('nivel_edicion')->where('edicion_id', $id)->count();
        }

        if (Schema::hasTable('inscritos') && Schema::hasColumn('inscritos', 'edicion_id')) {
            $stats['inscritos'] = (int) DB::table('inscritos')->where('edicion_id', $id)->count();
        }

        if (Schema::hasTable('responsables_academicos') && Schema::hasColumn('responsables_academicos', 'edicion_id')) {
            $stats['responsables'] = (int) DB::table('responsables_academicos')->where('edicion_id', $id)->count();
        }

        if (Schema::hasTable('evaluadores') && Schema::hasColumn('evaluadores', 'edicion_id')) {
            $stats['evaluadores'] = (int) DB::table('evaluadores')->where('edicion_id', $id)->count();
        }

        return $stats;
    }

    private function getAreasByEdicion(int $id): array
    {
        if (!Schema::hasTable('areas') || !Schema::hasTable('area_edicion')) {
            return [];
        }

        return DB::table('areas')
            ->join('area_edicion', 'areas.id', '=', 'area_edicion.area_id')
            ->where('area_edicion.edicion_id', $id)
            ->orderBy('areas.nombre')
            ->get(['areas.id', 'areas.nombre'])
            ->toArray();
    }

    private function clonarConfiguracionBase(int $nueva, int $origen): void
    {
        // Áreas
        if (Schema::hasTable('area_edicion')) {
            $areas = DB::table('area_edicion')->where('edicion_id', $origen)->pluck('area_id')->all();
            foreach ($areas as $areaId) {
                DB::table('area_edicion')->updateOrInsert(
                    ['edicion_id' => $nueva, 'area_id' => $areaId],
                    ['updated_at' => now(), 'created_at' => now()]
                );
            }
        }

        // Pivot niveles por área (enterprise)
        if (Schema::hasTable('area_nivel_edicion')) {
            $rows = DB::table('area_nivel_edicion')->where('edicion_id', $origen)->get(['area_id', 'nivel_id']);
            foreach ($rows as $r) {
                DB::table('area_nivel_edicion')->updateOrInsert(
                    ['edicion_id' => $nueva, 'area_id' => (int)$r->area_id, 'nivel_id' => (int)$r->nivel_id],
                    ['updated_at' => now(), 'created_at' => now()]
                );
            }
        }

        // Niveles (legacy scoped por edición)
        if (Schema::hasTable('niveles') && Schema::hasColumn('niveles', 'edicion_id')) {
            $niveles = DB::table('niveles')->where('edicion_id', $origen)->get();
            foreach ($niveles as $n) {
                $exists = DB::table('niveles')
                    ->where('edicion_id', $nueva)
                    ->where('nombre', $n->nombre)
                    ->exists();

                if ($exists) continue;

                DB::table('niveles')->insert([
                    'edicion_id' => $nueva,
                    'nombre'     => $n->nombre,
                    'orden'      => $n->orden ?? 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        // Etapas / reglas si existen (clonación opcional)
        if (Schema::hasTable('edicion_etapas') && Schema::hasColumn('edicion_etapas', 'edicion_id')) {
            $etapas = DB::table('edicion_etapas')->where('edicion_id', $origen)->get();
            foreach ($etapas as $e) {
                DB::table('edicion_etapas')->updateOrInsert(
                    ['edicion_id' => $nueva, 'key' => $e->key],
                    [
                        'nombre' => $e->nombre,
                        'orden' => (int)($e->orden ?? 1),
                        'inicio' => $e->inicio ?? null,
                        'fin' => $e->fin ?? null,
                        'habilitada' => (int)!!($e->habilitada ?? 1),
                        'updated_at' => now(),
                        'created_at' => now(),
                    ]
                );
            }
        }

        if (Schema::hasTable('edicion_reglas') && Schema::hasColumn('edicion_reglas', 'edicion_id')) {
            $r = DB::table('edicion_reglas')->where('edicion_id', $origen)->first();
            if ($r) {
                DB::table('edicion_reglas')->updateOrInsert(
                    ['edicion_id' => $nueva],
                    [
                        'tipo' => $r->tipo ?? 'mixta',
                        'umbral_min' => $r->umbral_min ?? null,
                        'top_n' => $r->top_n ?? null,
                        'nota_min_aprob' => $r->nota_min_aprob ?? null,
                        'updated_at' => now(),
                        'created_at' => now(),
                    ]
                );
            }
        }
    }

    private function defaultEtapas(): array
    {
        return [
            ['key' => 'fase1', 'nombre' => 'Fase 1', 'orden' => 1, 'inicio' => null, 'fin' => null, 'habilitada' => true],
            ['key' => 'clasificados', 'nombre' => 'Clasificados', 'orden' => 2, 'inicio' => null, 'fin' => null, 'habilitada' => true],
            ['key' => 'final', 'nombre' => 'Final', 'orden' => 3, 'inicio' => null, 'fin' => null, 'habilitada' => true],
            ['key' => 'medalleria', 'nombre' => 'Medallería', 'orden' => 4, 'inicio' => null, 'fin' => null, 'habilitada' => true],
        ];
    }

    /* ======================================================
     * Persistencia: ÁREAS + NIVELES POR ÁREA (enterprise)
     * ====================================================== */

    private function persistAreasForEdicion(int $edicionId, array $areasIds): void
    {
        if (!Schema::hasTable('area_edicion')) return;

        $ids = array_values(array_unique(array_map('intval', $areasIds)));

        // filtrar solo ids válidos si existe catálogo
        if (Schema::hasTable('areas')) {
            $ids = DB::table('areas')
                ->whereIn('id', $ids)
                ->pluck('id')
                ->map(fn($v)=>(int)$v)
                ->toArray();
        }

        // estrategia: reset y reinsert para estado consistente
        DB::table('area_edicion')->where('edicion_id', $edicionId)->delete();

        foreach ($ids as $aid) {
            DB::table('area_edicion')->insert([
                'edicion_id' => $edicionId,
                'area_id' => (int)$aid,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    /**
     * Persiste niveles por área.
     * Pivot recomendado: area_nivel_edicion(edicion_id, area_id, nivel_id)
     * Si no existe, hace fallback a nivel_edicion (global), sin reventar el store.
     */
    private function persistAreaNivelesForEdicion(int $edicionId, array $areasIds, $areaNivelIdsRaw): void
    {
        $areasIds = array_values(array_unique(array_map('intval', $areasIds)));
        $areaNivelIds = is_array($areaNivelIdsRaw) ? $areaNivelIdsRaw : [];

        // Si existe pivot enterprise
        if (Schema::hasTable('area_nivel_edicion')) {
            // limpiamos todo por edición para consistencia
            DB::table('area_nivel_edicion')->where('edicion_id', $edicionId)->delete();

            foreach ($areasIds as $aid) {
                $niveles = $areaNivelIds[(string)$aid] ?? $areaNivelIds[$aid] ?? [];
                if (!is_array($niveles)) $niveles = [];

                $niveles = array_values(array_unique(array_map('intval', $niveles)));
                if (Schema::hasTable('niveles')) {
                    $niveles = DB::table('niveles')
                        ->whereIn('id', $niveles)
                        ->pluck('id')
                        ->map(fn($v)=>(int)$v)
                        ->toArray();
                }

                foreach ($niveles as $nid) {
                    DB::table('area_nivel_edicion')->insert([
                        'edicion_id' => $edicionId,
                        'area_id' => (int)$aid,
                        'nivel_id' => (int)$nid,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }

            return;
        }

        // Fallback: si no tienes pivot por área, al menos guardamos set global en nivel_edicion
        if (Schema::hasTable('nivel_edicion')) {
            $global = [];
            foreach ($areasIds as $aid) {
                $niveles = $areaNivelIds[(string)$aid] ?? $areaNivelIds[$aid] ?? [];
                if (!is_array($niveles)) $niveles = [];
                foreach ($niveles as $nid) $global[] = (int)$nid;
            }

            $global = array_values(array_unique(array_map('intval', $global)));
            if (Schema::hasTable('niveles')) {
                $global = DB::table('niveles')
                    ->whereIn('id', $global)
                    ->pluck('id')
                    ->map(fn($v)=>(int)$v)
                    ->toArray();
            }

            DB::table('nivel_edicion')->where('edicion_id', $edicionId)->delete();
            foreach ($global as $nid) {
                DB::table('nivel_edicion')->insert([
                    'edicion_id' => $edicionId,
                    'nivel_id' => (int)$nid,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        // Si tu modelo es niveles scoped (niveles.edicion_id), aquí NO hacemos nada (por seguridad de catálogo)
    }

    private function persistEtapasIniciales(int $edicionId, array $etapas): void
    {
        if (!Schema::hasTable('edicion_etapas') || !Schema::hasColumn('edicion_etapas', 'edicion_id')) return;

        foreach ($etapas as $et) {
            if (is_array($et)) {
                $key = $et['key'] ?? null;
                if (!$key) continue;

                DB::table('edicion_etapas')->updateOrInsert(
                    ['edicion_id' => $edicionId, 'key' => $key],
                    [
                        'nombre' => $et['nombre'] ?? $key,
                        'orden' => (int)($et['orden'] ?? 1),
                        'inicio' => $et['inicio'] ?? null,
                        'fin' => $et['fin'] ?? null,
                        'habilitada' => isset($et['habilitada']) ? (int)!!$et['habilitada'] : 1,
                        'updated_at' => now(),
                        'created_at' => now(),
                    ]
                );
            } else {
                // viene del defaultEtapas() como array
            }
        }
    }

    private function persistReglasBase(int $edicionId, array $rb): void
    {
        if (!Schema::hasTable('edicion_reglas') || !Schema::hasColumn('edicion_reglas', 'edicion_id')) return;

        DB::table('edicion_reglas')->updateOrInsert(
            ['edicion_id' => $edicionId],
            [
                'tipo' => $rb['tipo'] ?? 'mixta',
                'umbral_min' => $rb['umbral_min'] ?? null,
                'top_n' => $rb['top_n'] ?? null,
                'nota_min_aprob' => $rb['nota_min_aprob'] ?? null,
                'updated_at' => now(),
                'created_at' => now(),
            ]
        );
    }
}
