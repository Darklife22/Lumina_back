<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\Edicion;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AreasController extends Controller
{
    /**
     * GET /admin/areas?page=&per_page=
     */
    public function index(Request $r)
    {
        $page = max(1, (int) $r->query('page', 1));
        $per  = max(1, min(100, (int) $r->query('per_page', 20)));

        $q = Area::query()
            ->with(['ediciones:id,nombre,slug,gestion,activa'])
            ->orderBy('nombre');

        $total = (clone $q)->count();
        $rows  = $q->forPage($page, $per)->get();

        return response()->json([
            'data' => $rows->map(function($a){
                return [
                    'id' => $a->id,
                    'nombre' => $a->nombre,
                    'rango_min' => (int)$a->rango_min,
                    'rango_max' => (int)$a->rango_max,
                    'umbral_clasificacion' => (int)$a->umbral_clasificacion,
                    'activo' => (bool)$a->activo,
                    'ediciones' => $a->ediciones->map(fn($e)=>[
                        'id'=>$e->id,'nombre'=>$e->nombre,'slug'=>$e->slug,'gestion'=>$e->gestion,'activa'=>$e->activa
                    ])->values(),
                ];
            }),
            'meta' => [
                'page'=>$page, 'per_page'=>$per, 'total'=>$total,
                'total_pages'=>(int)ceil($total/$per)
            ]
        ]);
    }

    /**
     * GET /admin/ediciones (para multiselect del front)
     */
    public function ediciones()
    {
        $rows = Edicion::orderBy('fecha_inicio','desc')->orderBy('id','desc')->get([
            'id','nombre','slug','gestion','fecha_inicio','fecha_fin','activa'
        ]);
        return response()->json(['data'=>$rows]);
    }

    /**
     * POST /admin/areas
     * Body:
     * {
     *   "nombre":"Matemática",
     *   "rango_min":0, "rango_max":100, "umbral":60,
     *   "ediciones_ids":[1,2], "activo":true
     * }
     */
    public function store(Request $r)
    {
        $data = $r->validate([
            'nombre' => ['required','string','max:150',
                Rule::unique('areas','nombre')
            ],
            'rango_min' => ['required','integer','lte:rango_max'],
            'rango_max' => ['required','integer','gte:rango_min'],
            'umbral'    => ['required','integer','between:0,100'],
            'ediciones_ids' => ['nullable','array'],
            'ediciones_ids.*' => ['integer','exists:ediciones,id'],
            'activo' => ['boolean'],
        ], [
            'nombre.unique' => 'Ya existe un área con ese nombre.',
        ]);

        $area = Area::create([
            'nombre' => $data['nombre'],
            'rango_min' => $data['rango_min'],
            'rango_max' => $data['rango_max'],
            'umbral_clasificacion' => $data['umbral'],
            'activo' => $r->boolean('activo', true),
        ]);

        if (!empty($data['ediciones_ids'])) {
            $area->ediciones()->sync($data['ediciones_ids']);
        }

        return response()->json([
            'ok'=>true,
            'message'=>"Área '{$area->nombre}' creada exitosamente",
            'data'=>$area->load('ediciones:id,nombre,slug,gestion,activa')
        ], 201);
    }
}
