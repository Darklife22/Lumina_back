<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\Edicion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class AreasAdminController extends Controller
{
    /**
     * GET /admin/areas?page=&per_page=&q=&activo=
     *
     * Filtros:
     *  - q      : búsqueda por nombre
     *  - activo : '1' activos, '0' inactivos, vacío = todos
     */
    public function index(Request $r)
    {
        $page = max(1, (int) $r->query('page', 1));
        $per  = max(1, min(100, (int) $r->query('per_page', 20)));

        $q      = trim((string) $r->query('q', ''));
        $activo = $r->query('activo', null); // '1' | '0' | null

        $query = Area::query()
            ->with(['ediciones:id,nombre,slug,gestion,activa']);

        // Filtro por texto
        if ($q !== '') {
            $query->where('nombre', 'like', "%{$q}%");
        }

        // Filtro por estado activo
        if ($activo !== null && $activo !== '') {
            $query->where('activo', $activo === '1' ? 1 : 0);
        }

        $total = (clone $query)->count();

        $rows = $query
            ->orderBy('nombre')
            ->forPage($page, $per)
            ->get();

        return response()->json([
            'ok'   => true,
            'data' => $rows->map(function (Area $a) {
                return [
                    'id'                   => $a->id,
                    'nombre'               => $a->nombre,
                    'rango_min'            => (float) $a->rango_min,
                    'rango_max'            => (float) $a->rango_max,
                    'umbral_clasificacion' => (float) $a->umbral_clasificacion,
                    'activo'               => (bool) $a->activo,
                    'ediciones'            => $a->ediciones->map(fn (Edicion $e) => [
                        'id'      => $e->id,
                        'nombre'  => $e->nombre,
                        'slug'    => $e->slug,
                        'gestion' => $e->gestion,
                        'activa'  => (bool) $e->activa,
                    ])->values(),
                ];
            }),
            'meta' => [
                'page'        => $page,
                'per_page'    => $per,
                'total'       => $total,
                'total_pages' => (int) ceil($total / $per),
            ],
        ]);
    }

    /**
     * Helper para extraer el primer mensaje de error de una ValidationException.
     */
    protected function firstErrorMessage(ValidationException $e): string
    {
        $errors = $e->errors(); // ['campo' => ['msg1','msg2'], ...]
        foreach ($errors as $field => $msgs) {
            if (is_array($msgs) && count($msgs) > 0) {
                return $msgs[0];
            }
        }
        return 'Error de validación.';
    }

    /**
     * Validación y normalizado de payload para crear/editar.
     *
     * Se asegura:
     *  - nombre requerido
     *  - rango_min <= rango_max
     *  - umbral_clasificacion dentro del rango
     *  - ediciones_ids[] válidas
     *  - NO duplicar nombre dentro de la misma edición
     */
    protected function validatePayload(Request $r, ?Area $existing = null): array
    {
        $validator = Validator::make($r->all(), [
            'nombre'               => ['required', 'string', 'max:150'],
            'rango_min'            => ['required', 'numeric'],
            'rango_max'            => ['required', 'numeric', 'gte:rango_min'],
            'umbral_clasificacion' => ['required', 'numeric'],
            'ediciones_ids'        => ['nullable', 'array'],
            'ediciones_ids.*'      => ['integer', 'exists:ediciones,id'],
            'activo'               => ['sometimes', 'boolean'],
        ], [
            'nombre.required'    => 'El nombre del área es obligatorio.',
            'rango_min.required' => 'El rango mínimo es obligatorio.',
            'rango_max.required' => 'El rango máximo es obligatorio.',
        ]);

        $data = $validator->validate();

        // Validar que el umbral esté dentro del rango
        $min    = (float) $data['rango_min'];
        $max    = (float) $data['rango_max'];
        $umbral = (float) $data['umbral_clasificacion'];

        if ($umbral < $min || $umbral > $max) {
            throw ValidationException::withMessages([
                'umbral_clasificacion' => 'El umbral de clasificación debe estar dentro del rango definido.',
            ]);
        }

        // Normalizar lista de ediciones
        $edicionesIds = array_values(array_unique(array_map('intval', $data['ediciones_ids'] ?? [])));

        // Validar duplicado de nombre dentro de la misma edición
        if (!empty($edicionesIds)) {
            $nombre   = $data['nombre'];
            $queryDup = Area::query()
                ->where('nombre', $nombre)
                ->whereHas('ediciones', function ($q) use ($edicionesIds) {
                    $q->whereIn('ediciones.id', $edicionesIds);
                });

            // En edición excluir el propio ID
            if ($existing) {
                $queryDup->where('id', '!=', $existing->id);
            }

            $existsDup = $queryDup->exists();
            if ($existsDup) {
                throw ValidationException::withMessages([
                    'nombre' => "El área '{$nombre}' ya existe en alguna de las ediciones seleccionadas.",
                ]);
            }
        }

        $data['ediciones_ids'] = $edicionesIds;
        $data['activo']        = isset($data['activo'])
            ? (bool) $data['activo']
            : true;

        return $data;
    }

    /**
     * POST /admin/areas
     */
    public function store(Request $r)
    {
        try {
            $data = $this->validatePayload($r, null);

            $area = null;

            DB::transaction(function () use (&$area, $data, $r) {
                $area = Area::create([
                    'nombre'               => $data['nombre'],
                    'rango_min'            => $data['rango_min'],
                    'rango_max'            => $data['rango_max'],
                    'umbral_clasificacion' => $data['umbral_clasificacion'],
                    'activo'               => $data['activo'],
                ]);

                if (!empty($data['ediciones_ids'])) {
                    $area->ediciones()->sync($data['ediciones_ids']);
                }

                // Auditoría simple en log
                $user = $r->user();
                Log::info('Área creada', [
                    'area_id'   => $area->id,
                    'area_name' => $area->nombre,
                    'by_user'   => $user?->email ?? $user?->id,
                    'at'        => now()->toDateTimeString(),
                ]);
            });

            $area->load('ediciones:id,nombre,slug,gestion,activa');

            return response()->json([
                'ok'      => true,
                'message' => "Área '{$area->nombre}' creada exitosamente.",
                'data'    => [
                    'id'                   => $area->id,
                    'nombre'               => $area->nombre,
                    'rango_min'            => (float) $area->rango_min,
                    'rango_max'            => (float) $area->rango_max,
                    'umbral_clasificacion' => (float) $area->umbral_clasificacion,
                    'activo'               => (bool) $area->activo,
                    'ediciones'            => $area->ediciones->map(fn (Edicion $e) => [
                        'id'      => $e->id,
                        'nombre'  => $e->nombre,
                        'slug'    => $e->slug,
                        'gestion' => $e->gestion,
                        'activa'  => (bool) $e->activa,
                    ])->values(),
                ],
            ], 201);

        } catch (ValidationException $e) {
            return response()->json([
                'ok'      => false,
                'message' => $this->firstErrorMessage($e),
                'errors'  => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al crear el área.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * PUT /admin/areas/{id}
     *
     * Body igual que store().
     * Si se cambia activo → false, se considera "Archivar/Inactivar" el área.
     */
    public function update(Request $r, int $id)
    {
        /** @var Area|null $area */
        $area = Area::find($id);
        if (!$area) {
            return response()->json([
                'ok'      => false,
                'message' => 'Área no encontrada.',
            ], 404);
        }

        $wasActive = (bool) $area->activo;

        try {
            $data = $this->validatePayload($r, $area);

            DB::transaction(function () use ($area, $data, $r, $wasActive) {
                $area->update([
                    'nombre'               => $data['nombre'],
                    'rango_min'            => $data['rango_min'],
                    'rango_max'            => $data['rango_max'],
                    'umbral_clasificacion' => $data['umbral_clasificacion'],
                    'activo'               => $data['activo'],
                ]);

                if (!empty($data['ediciones_ids'])) {
                    $area->ediciones()->sync($data['ediciones_ids']);
                } else {
                    $area->ediciones()->detach();
                }

                // Si se está inactivando el área, se entiende como "Archivada"
                if ($wasActive && !$data['activo']) {
                    // Desvincular responsables y evaluadores de esta área
                    if (method_exists($area, 'responsables')) {
                        $area->responsables()->detach();
                    }
                    if (method_exists($area, 'evaluadores')) {
                        $area->evaluadores()->detach();
                    }

                    $user = $r->user();
                    Log::info('Área inactivada/archivada', [
                        'area_id'   => $area->id,
                        'area_name' => $area->nombre,
                        'by_user'   => $user?->email ?? $user?->id,
                        'at'        => now()->toDateTimeString(),
                    ]);
                }
            });

            $area->load('ediciones:id,nombre,slug,gestion,activa');

            return response()->json([
                'ok'      => true,
                'message' => "Área '{$area->nombre}' actualizada correctamente.",
                'data'    => [
                    'id'                   => $area->id,
                    'nombre'               => $area->nombre,
                    'rango_min'            => (float) $area->rango_min,
                    'rango_max'            => (float) $area->rango_max,
                    'umbral_clasificacion' => (float) $area->umbral_clasificacion,
                    'activo'               => (bool) $area->activo,
                    'ediciones'            => $area->ediciones->map(fn (Edicion $e) => [
                        'id'      => $e->id,
                        'nombre'  => $e->nombre,
                        'slug'    => $e->slug,
                        'gestion' => $e->gestion,
                        'activa'  => (bool) $e->activa,
                    ])->values(),
                ],
            ]);

        } catch (ValidationException $e) {
            return response()->json([
                'ok'      => false,
                'message' => $this->firstErrorMessage($e),
                'errors'  => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al actualizar el área.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * DELETE /admin/areas/{id}
     *
     * Reglas HU-45:
     *  - Bloquear si hay participantes inscritos asociados al área
     *  - Bloquear si hay notas cargadas
     *  - Si no hay datos, se puede eliminar físicamente
     *  - Al eliminar, se desvinculan responsables/evaluadores y se registra en log
     */
    public function destroy(Request $r, int $id)
    {
        /** @var Area|null $area */
        $area = Area::find($id);
        if (!$area) {
            return response()->json([
                'ok'      => false,
                'message' => 'Área no encontrada.',
            ], 404);
        }

        // ==============================
        // Verificar participantes / notas
        // ==============================
        $inscritosCount = 0;
        $notasCount     = 0;

        if (Schema::hasTable('inscritos')) {
            // Asumimos columna area_id; si no existe, no se bloquea por este criterio
            if (Schema::hasColumn('inscritos', 'area_id')) {
                $inscritosCount = DB::table('inscritos')
                    ->where('area_id', $area->id)
                    ->count();
            }
        }

        if (Schema::hasTable('calificaciones')) {
            // Caso 1: calificaciones tiene area_id
            if (Schema::hasColumn('calificaciones', 'area_id')) {
                $notasCount = DB::table('calificaciones')
                    ->where('area_id', $area->id)
                    ->count();
            }
            // Caso 2: join por inscrito_id + inscritos.area_id
            elseif (
                Schema::hasColumn('calificaciones', 'inscrito_id') &&
                Schema::hasTable('inscritos') &&
                Schema::hasColumn('inscritos', 'area_id')
            ) {
                $notasCount = DB::table('calificaciones')
                    ->join('inscritos', 'inscritos.id', '=', 'calificaciones.inscrito_id')
                    ->where('inscritos.area_id', $area->id)
                    ->count();
            }
        }

        if ($notasCount > 0) {
            return response()->json([
                'ok'      => false,
                'message' => "No se puede eliminar: ya hay {$notasCount} notas cargadas para esta área.",
            ], 422);
        }

        if ($inscritosCount > 0) {
            return response()->json([
                'ok'      => false,
                'message' => "No se puede eliminar: ya hay {$inscritosCount} participantes inscritos en esta área.",
            ], 422);
        }

        try {
            DB::transaction(function () use ($area, $r) {
                // Limpia asociaciones con ediciones
                $area->ediciones()->detach();

                // Desvincular responsables / evaluadores si existen relaciones
                if (method_exists($area, 'responsables')) {
                    $area->responsables()->detach();
                }
                if (method_exists($area, 'evaluadores')) {
                    $area->evaluadores()->detach();
                }

                $areaName = $area->nombre;
                $areaId   = $area->id;

                $area->delete();

                $user = $r->user();
                Log::info('Área eliminada', [
                    'area_id'   => $areaId,
                    'area_name' => $areaName,
                    'by_user'   => $user?->email ?? $user?->id,
                    'at'        => now()->toDateTimeString(),
                ]);
            });

            return response()->json([
                'ok'      => true,
                'message' => 'Área eliminada correctamente.',
            ]);

        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al eliminar el área.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
