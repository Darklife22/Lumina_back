<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\ResponsableAcademico;
use App\Models\Usuario;
use App\Models\Rol;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Schema;

class ResponsablesAcademicosController extends Controller
{
    /**
     * GET /admin/responsables/areas
     * Devuelve todas las áreas activas (para el checklist).
     */
    public function areas()
    {
        $query = Area::query();
        if (Schema::hasColumn('areas', 'activo')) {
            $query->where('activo', true);
        }

        $areas = $query
            ->orderBy('nombre')
            ->get(['id', 'nombre']);

        return response()->json(['data' => $areas]);
    }

    /**
     * GET /admin/responsables
     * Listado paginado + filtros: q, area_id, page, per_page
     */
    public function index(Request $request)
    {
        $q       = trim((string) $request->query('q', ''));
        $areaId  = (int) $request->query('area_id', 0);
        $page    = max(1, (int) $request->query('page', 1));
        $perPage = max(1, min(100, (int) $request->query('per_page', 20)));

        $query = ResponsableAcademico::query()
            ->with(['areas:id,nombre'])
            ->when($q !== '', function ($qq) use ($q) {
                $like = "%$q%";
                $qq->where(function ($w) use ($like) {
                    $w->where('nombre', 'like', $like)
                      ->orWhere('email', 'like', $like)
                      ->orWhere('telefono', 'like', $like);
                });
            })
            ->when($areaId > 0, function ($qq) use ($areaId) {
                $qq->whereHas('areas', fn($a) => $a->where('areas.id', $areaId));
            })
            ->orderBy('nombre');

        $total = (clone $query)->count();
        $rows  = $query->forPage($page, $perPage)->get();

        return response()->json([
            'data' => $rows->map(function (ResponsableAcademico $r) {
                return [
                    'id'         => $r->id,
                    'usuario_id' => $r->usuario_id,
                    'nombre'     => $r->nombre,
                    'email'      => $r->email,
                    'telefono'   => $r->telefono,
                    'activo'     => (bool) $r->activo,
                    'areas'      => $r->areas
                        ->map(fn($a) => ['id' => $a->id, 'nombre' => $a->nombre])
                        ->values(),
                ];
            }),
            'meta' => [
                'page'        => $page,
                'per_page'    => $perPage,
                'total'       => $total,
                'total_pages' => (int) ceil($total / max(1, $perPage)),
            ],
        ]);
    }

    /**
     * GET /admin/responsables/usuarios-buscar?q=
     * Búsqueda de usuarios por nombre / apellido / email.
     * Si el usuario YA ES responsable, lo devuelve en 'responsable' y con sus áreas.
     * Se detecta tanto por usuario_id como por email.
     */
    public function buscarUsuarios(Request $request)
    {
        $q = trim((string) $request->query('q', ''));

        if ($q === '') {
            return response()->json(['data' => []]);
        }

        $like = "%{$q}%";

        $select = ['id', 'nombre', 'email'];
        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');
        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');

        if ($hasApellidos) $select[] = 'apellidos';
        if ($hasTelefono)  $select[] = 'telefono';
        if (Schema::hasColumn('usuarios', 'activo')) {
            $select[] = 'activo';
        }

        $usuarios = Usuario::query()
            ->select($select)
            ->when(
                Schema::hasColumn('usuarios', 'activo'),
                fn($qq) => $qq->where('activo', true)
            )
            ->where(function ($w) use ($like, $hasApellidos, $hasTelefono) {
                $w->where('nombre', 'like', $like)
                  ->orWhere('email', 'like', $like);

                if ($hasApellidos) {
                    $w->orWhere('apellidos', 'like', $like);
                }
                if ($hasTelefono) {
                    $w->orWhere('telefono', 'like', $like);
                }
            })
            ->orderBy('nombre')
            ->limit(30)
            ->get();

        if ($usuarios->isEmpty()) {
            return response()->json(['data' => []]);
        }

        $ids    = $usuarios->pluck('id')->all();
        $emails = $usuarios->pluck('email')->filter()->unique()->all();

        // Detectar responsables por usuario_id o por email (caso legacy sin usuario vinculado)
        $responsables = ResponsableAcademico::with('areas:id,nombre')
            ->where(function ($q2) use ($ids, $emails) {
                if (!empty($ids)) {
                    $q2->whereIn('usuario_id', $ids);
                }
                if (!empty($emails)) {
                    $q2->orWhereIn('email', $emails);
                }
            })
            ->get();

        $data = $usuarios->map(function (Usuario $u) use ($hasApellidos, $hasTelefono, $responsables) {
            $fullName = $u->nombre;
            if ($hasApellidos && $u->apellidos) {
                $fullName .= ' ' . $u->apellidos;
            }

            // Buscar responsable por usuario_id o por email
            $resp = $responsables->firstWhere('usuario_id', $u->id)
                 ?: $responsables->firstWhere('email', $u->email);

            return [
                'id'       => $u->id,
                'nombre'   => $fullName,
                'email'    => $u->email,
                'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,
                'responsable' => $resp ? [
                    'id'       => $resp->id,
                    'nombre'   => $resp->nombre,
                    'email'    => $resp->email,
                    'telefono' => $resp->telefono,
                    'activo'   => (bool) $resp->activo,
                    'areas'    => $resp->areas
                        ->map(fn($a) => ['id' => $a->id, 'nombre' => $a->nombre])
                        ->values(),
                ] : null,
            ];
        });

        return response()->json(['data' => $data->values()]);
    }

    /**
     * POST /admin/responsables
     * Crea responsable, crea/vincula Usuario con rol 'responsable_area' y asigna áreas.
     *
     * Body:
     *  - usuario_id (opcional): id de Usuario ya registrado
     *  - nombre, email, telefono, areas[], activo?
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'usuario_id' => ['nullable', 'integer', 'exists:usuarios,id'],
            'nombre'     => ['required', 'string', 'max:200'],
            'email'      => [
                'required', 'email', 'max:200',
                Rule::unique('responsables_academicos', 'email'),
                Rule::unique('usuarios', 'email'),
            ],
            'telefono'   => ['required', 'regex:/^[0-9]+$/', 'max:30'],
            'areas'      => ['required', 'array', 'min:1'],
            'areas.*'    => ['integer', 'exists:areas,id'],
            'activo'     => ['nullable', 'boolean'],
        ], [
            'telefono.regex' => 'El teléfono debe contener sólo números.',
            'areas.min'      => 'Debe asignar al menos un área.',
        ]);

        DB::beginTransaction();
        try {
            $roleId = Rol::where('slug', 'responsable_area')->value('id');
            if (!$roleId) {
                throw new \RuntimeException("No existe el rol 'responsable_area'. Crea el rol primero.");
            }

            // Safety: si ya hay responsable con este email, no crear duplicado
            $existingResp = ResponsableAcademico::where('email', $data['email'])->first();
            if ($existingResp) {
                DB::rollBack();
                return response()->json([
                    'ok'      => false,
                    'message' => 'Ya existe un responsable con ese correo electrónico. Búscalo en el buscador y edítalo en lugar de crear uno nuevo.',
                ], 422);
            }

            $tempPassToShow = null;
            $user = null;

            // 1) Resolver usuario
            if (!empty($data['usuario_id'])) {
                // Usuario seleccionado desde buscador
                $user = Usuario::find($data['usuario_id']);
                if (!$user) {
                    throw new \RuntimeException("El usuario seleccionado ya no existe.");
                }

                $dirty = false;
                if ($user->email !== $data['email']) { $user->email = $data['email']; $dirty = true; }
                if ($user->nombre !== $data['nombre']) { $user->nombre = $data['nombre']; $dirty = true; }
                if ($user->role_id !== $roleId) { $user->role_id = $roleId; $dirty = true; }
                if (Schema::hasColumn('usuarios', 'activo') && $user->activo === false) {
                    $user->activo = true;
                    $dirty = true;
                }
                if ($dirty) {
                    $user->save();
                }
            } else {
                // Sin usuario_id: buscar por email o crear nuevo
                $user = Usuario::where('email', $data['email'])->first();

                if (!$user) {
                    $tempPass = Str::random(10);
                    $userData = [
                        'nombre'    => $data['nombre'],
                        'apellidos' => '',
                        'email'     => $data['email'],
                        'password'  => Hash::make($tempPass),
                        'role_id'   => $roleId,
                        'activo'    => true,
                    ];
                    if (Schema::hasColumn('usuarios', 'must_change_password')) {
                        $userData['must_change_password'] = true;
                    }
                    $user = Usuario::create($userData);
                    $tempPassToShow = $tempPass;
                } else {
                    $dirty = false;
                    if ($user->role_id !== $roleId) { $user->role_id = $roleId; $dirty = true; }
                    if (Schema::hasColumn('usuarios', 'activo') && $user->activo === false) {
                        $user->activo = true;
                        $dirty = true;
                    }
                    if ($dirty) $user->save();
                }
            }

            if (!$user) {
                throw new \RuntimeException("No fue posible resolver el usuario para el responsable.");
            }

            $areasIds = $data['areas'];

            // 2) Validar que ese usuario no tenga ya responsable en esas áreas
            $yaAsignado = ResponsableAcademico::where(function ($q) use ($user) {
                    $q->where('usuario_id', $user->id)
                      ->orWhere('email', $user->email);
                })
                ->whereHas('areas', function ($q) use ($areasIds) {
                    $q->whereIn('areas.id', $areasIds);
                })
                ->exists();

            if ($yaAsignado) {
                DB::rollBack();
                return response()->json([
                    'ok'      => false,
                    'message' => 'El usuario ya está asignado como responsable en al menos una de las áreas seleccionadas.',
                ], 422);
            }

            // 3) Crear responsable
            $responsable = ResponsableAcademico::create([
                'usuario_id' => $user->id,
                'nombre'     => $data['nombre'],
                'email'      => $data['email'],
                'telefono'   => $data['telefono'],
                'activo'     => $data['activo'] ?? true,
            ]);

            $responsable->areas()->sync($areasIds);

            DB::commit();

            return response()->json([
                'ok'                => true,
                'message'           => 'Responsable creado correctamente.',
                'data'              => $responsable->load('areas:id,nombre'),
                'password_temporal' => $tempPassToShow,
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudo crear el responsable.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * PUT /admin/responsables/{id}
     * Actualiza responsable + sincroniza info en Usuario + reasigna áreas.
     */
    public function update($id, Request $request)
    {
        $responsable = ResponsableAcademico::findOrFail($id);

        $data = $request->validate([
            'usuario_id' => ['nullable', 'integer', 'exists:usuarios,id'],
            'nombre'     => ['required', 'string', 'max:200'],
            'email'      => [
                'required', 'email', 'max:200',
                Rule::unique('responsables_academicos', 'email')->ignore($responsable->id),
                Rule::unique('usuarios', 'email')->ignore($responsable->usuario_id),
            ],
            'telefono'   => ['required', 'regex:/^[0-9]+$/', 'max:30'],
            'areas'      => ['required', 'array', 'min:1'],
            'areas.*'    => ['integer', 'exists:areas,id'],
            'activo'     => ['nullable', 'boolean'],
        ], [
            'telefono.regex' => 'El teléfono debe contener sólo números.',
            'areas.min'      => 'Debe asignar al menos un área.',
        ]);

        DB::beginTransaction();
        try {
            $roleId = Rol::where('slug', 'responsable_area')->value('id');
            if (!$roleId) {
                throw new \RuntimeException("No existe el rol 'responsable_area'. Crea el rol primero.");
            }

            $user = null;
            $usuarioIdNuevo = $data['usuario_id'] ?? null;

            if ($usuarioIdNuevo) {
                // Vincular a un usuario explícito
                $user = Usuario::find($usuarioIdNuevo);
                if (!$user) {
                    throw new \RuntimeException("El usuario seleccionado ya no existe.");
                }

                $dirty = false;
                if ($user->email !== $data['email']) { $user->email = $data['email']; $dirty = true; }
                if ($user->nombre !== $data['nombre']) { $user->nombre = $data['nombre']; $dirty = true; }
                if ($user->role_id !== $roleId) { $user->role_id = $roleId; $dirty = true; }
                if (Schema::hasColumn('usuarios', 'activo') && $user->activo === false) {
                    $user->activo = true;
                    $dirty = true;
                }
                if ($dirty) $user->save();

                $responsable->usuario_id = $user->id;
            } else {
                // Manejo de desvinculación o mantenimiento del usuario actual
                if ($request->has('usuario_id') && $data['usuario_id'] === null) {
                    // desvinculación explícita
                    $responsable->usuario_id = null;
                } else {
                    if ($responsable->usuario_id) {
                        $user = Usuario::find($responsable->usuario_id);
                        if ($user) {
                            $dirty = false;
                            if ($user->email !== $data['email']) { $user->email = $data['email']; $dirty = true; }
                            if ($user->nombre !== $data['nombre']) { $user->nombre = $data['nombre']; $dirty = true; }
                            if ($user->role_id !== $roleId) { $user->role_id = $roleId; $dirty = true; }
                            if (Schema::hasColumn('usuarios', 'activo') && $user->activo === false) {
                                $user->activo = true;
                                $dirty = true;
                            }
                            if ($dirty) $user->save();
                        }
                    }
                }
            }

            $areasIds = $data['areas'];

            // Validar duplicación de áreas con otros responsables del mismo usuario
            if ($responsable->usuario_id) {
                $yaAsignado = ResponsableAcademico::where(function ($q) use ($responsable) {
                        $q->where('usuario_id', $responsable->usuario_id)
                          ->orWhere('email', $responsable->email);
                    })
                    ->where('id', '!=', $responsable->id)
                    ->whereHas('areas', function ($q) use ($areasIds) {
                        $q->whereIn('areas.id', $areasIds);
                    })
                    ->exists();

                if ($yaAsignado) {
                    DB::rollBack();
                    return response()->json([
                        'ok'      => false,
                        'message' => 'El usuario ya está asignado como responsable en al menos una de las áreas seleccionadas.',
                    ], 422);
                }
            }

            // Responsable
            $responsable->nombre   = $data['nombre'];
            $responsable->email    = $data['email'];
            $responsable->telefono = $data['telefono'];
            $responsable->activo   = $data['activo'] ?? $responsable->activo;
            $responsable->save();

            // Áreas: aquí sincronizamos con todas las solicitadas
            $responsable->areas()->sync($areasIds);

            DB::commit();

            return response()->json([
                'ok'      => true,
                'message' => 'Responsable actualizado.',
                'data'    => $responsable->load('areas:id,nombre'),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudo actualizar.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/responsables/{id}/remover-areas
     *
     * Body:
     *  - areas_remover[]: ids de áreas a quitar
     *  - motivo: string (5–500)
     */
    public function removerAreas($id, Request $request)
    {
        $responsable = ResponsableAcademico::findOrFail($id);

        $data = $request->validate([
            'areas_remover'   => ['required', 'array', 'min:1'],
            'areas_remover.*' => ['integer', 'exists:areas,id'],
            'motivo'          => ['required', 'string', 'min:5', 'max:500'],
        ]);

        DB::beginTransaction();
        try {
            $currentIds = $responsable->areas()->pluck('areas.id')->all();
            $currentSet = array_flip($currentIds);

            $toRemove = array_values(array_unique($data['areas_remover']));

            $invalid = array_filter($toRemove, function ($idArea) use ($currentSet) {
                return !isset($currentSet[$idArea]);
            });

            if (!empty($invalid)) {
                DB::rollBack();
                return response()->json([
                    'ok'      => false,
                    'message' => 'Alguna de las áreas seleccionadas no está asignada al responsable.',
                ], 422);
            }

            // TODO: validaciones de negocio (edición activa, calificaciones pendientes, único responsable, etc.)

            $responsable->areas()->detach($toRemove);

            // TODO: log de auditoría con motivo $data['motivo']

            DB::commit();

            return response()->json([
                'ok'      => true,
                'message' => 'Áreas desvinculadas del responsable correctamente.',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudieron quitar las áreas del responsable.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/responsables/{id}/reset-password
     * Regenera una contraseña temporal para el usuario asociado.
     */
    public function resetPassword($id)
    {
        try {
            $responsable = ResponsableAcademico::findOrFail($id);

            $user = $responsable->usuario_id
                ? Usuario::find($responsable->usuario_id)
                : Usuario::where('email', $responsable->email)->first();

            if (!$user) {
                return response()->json([
                    'ok'      => false,
                    'message' => 'No existe usuario asociado al responsable.',
                ], 404);
            }

            $tempPass = Str::random(10);
            $user->password = Hash::make($tempPass);

            if (Schema::hasColumn('usuarios', 'must_change_password')) {
                $user->must_change_password = true;
            }

            if (Schema::hasColumn('usuarios', 'activo') && $user->activo === false) {
                $user->activo = true;
            }

            $user->save();

            return response()->json([
                'ok'                => true,
                'message'           => 'Contraseña temporal generada.',
                'password_temporal' => $tempPass,
                'usuario_id'        => $user->id,
                'email'             => $user->email,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudo regenerar la contraseña.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * DELETE /admin/responsables/{id}
     * - Desvincula todas las áreas.
     * - Marca al responsable como inactivo (no borramos al usuario).
     */
    public function destroy($id)
    {
        try {
            $r = ResponsableAcademico::findOrFail($id);

            // TODO: validaciones HU (pendientes, único responsable, etc.)

            DB::beginTransaction();

            $r->areas()->detach();
            $r->activo = false;
            $r->save();

            DB::commit();

            return response()->json([
                'ok'      => true,
                'message' => 'Rol de responsable removido (marcado como inactivo y sin áreas).',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudo quitar el rol de responsable.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * GET /admin/responsables/export?format=pdf|csv&q=&area_id=
     * Exporta listado. Si no hay DOMPDF, cae a CSV.
     */
    public function export(Request $request)
    {
        $format = strtolower((string) $request->query('format', 'pdf'));
        $q      = trim((string) $request->query('q', ''));
        $areaId = (int) $request->query('area_id', 0);

        $rows = ResponsableAcademico::query()
            ->with(['areas:id,nombre'])
            ->when($q !== '', function ($qq) use ($q) {
                $like = "%$q%";
                $qq->where(function ($w) use ($like) {
                    $w->where('nombre', 'like', $like)
                      ->orWhere('email', 'like', $like)
                      ->orWhere('telefono', 'like', $like);
                });
            })
            ->when($areaId > 0, fn($qq) => $qq->whereHas('areas', fn($a) => $a->where('areas.id', $areaId)))
            ->orderBy('nombre')
            ->get();

        $pdfClass = 'Barryvdh\\DomPDF\\Facade\\Pdf';
        if ($format === 'pdf' && class_exists($pdfClass)) {
            $html = view('exports.responsables_pdf', ['rows' => $rows])->render();
            $pdf  = $pdfClass::loadHTML($html)->setPaper('a4', 'portrait');
            return $pdf->download('responsables_academicos.pdf');
        }

        $headers = [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="responsables_academicos.csv"',
        ];

        $callback = function () use ($rows) {
            $out = fopen('php://output', 'w');
            // BOM UTF-8
            fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
            fputcsv($out, ['Nombre', 'Email', 'Teléfono', 'Áreas', 'Activo']);
            foreach ($rows as $r) {
                $areas = $r->areas->pluck('nombre')->implode(', ');
                fputcsv($out, [
                    $r->nombre,
                    $r->email,
                    $r->telefono,
                    $areas,
                    $r->activo ? 'Sí' : 'No',
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }
}
