<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Evaluador;
use App\Models\Usuario;
use App\Models\Rol;
use App\Models\Area;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class EvaluadoresController extends Controller
{
    /**
     * GET /admin/evaluadores/areas
     * Devuelve todas las áreas activas (para el checklist / combo).
     */
    public function areas()
    {
        if (!Schema::hasTable('areas')) {
            return response()->json(['data' => []]);
        }

        $query = Area::query();

        if (Schema::hasColumn('areas', 'activo')) {
            $query->where('activo', true);
        }

        $areas = $query
            ->orderBy('nombre')
            ->get(['id', 'nombre']);

        return response()->json(['data' => $areas]);
    }

    /**
     * GET /admin/evaluadores
     *
     * Filtros:
     *  - q: busca en nombre, apellidos, email, teléfono
     *  - area_id: solo evaluadores que tienen esa área
     */
    public function index(Request $request)
    {
        $q        = trim((string) $request->query('q', ''));
        $areaId   = (int) $request->query('area_id', 0);
        $page     = max(1, (int) $request->query('page', 1));
        $perPage  = max(1, min(100, (int) $request->query('per_page', 15)));

        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');
        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');

        $query = Evaluador::query()
            ->with([
                'usuario' => function ($u) use ($hasTelefono, $hasApellidos) {
                    $cols = ['id', 'nombre', 'email'];
                    if ($hasApellidos) $cols[] = 'apellidos';
                    if ($hasTelefono)  $cols[] = 'telefono';
                    if (Schema::hasColumn('usuarios', 'activo')) $cols[] = 'activo';
                    $u->select($cols);
                },
                'areas:id,nombre',
            ])
            ->when($q !== '', function ($qq) use ($q, $hasTelefono, $hasApellidos) {
                $like = "%{$q}%";
                $qq->whereHas('usuario', function ($u) use ($like, $hasTelefono, $hasApellidos) {
                    $u->where('nombre', 'like', $like)
                      ->orWhere('email', 'like', $like);

                    if ($hasApellidos) {
                        $u->orWhere('apellidos', 'like', $like);
                    }
                    if ($hasTelefono) {
                        $u->orWhere('telefono', 'like', $like);
                    }
                });
            })
            ->when($areaId > 0, function ($qq) use ($areaId) {
                $qq->whereHas('areas', fn($a) => $a->where('areas.id', $areaId));
            })
            ->orderBy('id');

        $total = (clone $query)->count();
        $rows  = $query->forPage($page, $perPage)->get();

        $data = $rows->map(function (Evaluador $e) use ($hasTelefono) {
            $u = $e->usuario;

            return [
                'id'         => $e->id,
                'usuario_id' => $e->usuario_id,
                'nombre'     => $u?->nombre ?? '',
                'email'      => $u?->email ?? '',
                'telefono'   => $hasTelefono ? ($u?->telefono ?? null) : null,
                'activo'     => (bool) $e->activo,
                'areas'      => $e->areas
                    ->map(fn($a) => [
                        'id'     => $a->id,
                        'nombre' => $a->nombre,
                    ])
                    ->values(),
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'page'        => $page,
                'per_page'    => $perPage,
                'total'       => $total,
                'total_pages' => (int) ceil($total / max(1, $perPage)),
            ],
        ]);
    }

    /**
     * GET /admin/evaluadores/usuarios-buscar?q=
     * Devuelve usuarios + evaluador (con áreas) si ya lo tienen.
     */
    public function buscarUsuarios(Request $request)
    {
        $q = trim((string) $request->query('q', ''));

        if ($q === '') {
            return response()->json(['data' => []]);
        }

        $like         = "%{$q}%";
        $hasTelefono  = Schema::hasColumn('usuarios', 'telefono');
        $hasApellidos = Schema::hasColumn('usuarios', 'apellidos');

        $select = ['id', 'nombre', 'email'];
        if ($hasApellidos) $select[] = 'apellidos';
        if ($hasTelefono)  $select[] = 'telefono';
        if (Schema::hasColumn('usuarios', 'activo')) {
            $select[] = 'activo';
        }

        $usuarios = Usuario::query()
            ->select($select)
            ->when(Schema::hasColumn('usuarios', 'activo'), function ($q2) {
                $q2->where('activo', true);
            })
            ->where(function ($w) use ($like, $hasApellidos, $hasTelefono) {
                $w->where('nombre', 'like', $like)
                  ->orWhere('email', 'like', $like);

                if ($hasApellidos) {
                    $w->orWhere('apellidos', 'like', $like);
                }
                if ($hasTelefono) {
                    $w->orWhere('telefono', 'like', $like);
                }
            })
            ->orderBy('nombre')
            ->limit(30)
            ->get();

        if ($usuarios->isEmpty()) {
            return response()->json(['data' => []]);
        }

        $evaluadores = Evaluador::with('areas:id,nombre')
            ->whereIn('usuario_id', $usuarios->pluck('id'))
            ->get()
            ->keyBy('usuario_id');

        $data = $usuarios->map(function (Usuario $u) use ($hasTelefono, $hasApellidos, $evaluadores) {
            $fullName = $u->nombre;
            if ($hasApellidos && $u->apellidos) {
                $fullName .= ' ' . $u->apellidos;
            }

            $ev = $evaluadores->get($u->id);

            return [
                'id'       => $u->id,
                'nombre'   => $fullName,
                'email'    => $u->email,
                'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,
                'evaluador'=> $ev ? [
                    'id'       => $ev->id,
                    'nombre'   => $u->nombre,
                    'email'    => $u->email,
                    'telefono' => $hasTelefono ? ($u->telefono ?? null) : null,
                    'activo'   => (bool) $ev->activo,
                    'areas'    => $ev->areas
                        ->map(fn($a) => [
                            'id'     => $a->id,
                            'nombre' => $a->nombre,
                        ])
                        ->values(),
                ] : null,
            ];
        });

        return response()->json(['data' => $data->values()]);
    }

    /**
     * POST /admin/evaluadores
     *
     * Body:
     *  - usuario_id: id de Usuario
     *  - areas[]: ids de áreas
     *  - activo: bool
     */
    public function store(Request $request)
{
    $data = $request->validate([
        'usuario_id' => ['required', 'integer', 'exists:usuarios,id'],
        'areas'      => ['required', 'array', 'min:1'],
        'areas.*'    => ['integer', 'exists:areas,id'],
        'activo'     => ['nullable', 'boolean'],
    ]);

    DB::beginTransaction();
    try {
        // Aseguramos que el rol exista
        $rol = Rol::firstOrCreate(
            ['slug' => 'evaluador'],
            ['nombre' => 'Evaluador', 'descripcion' => 'Evaluador de olimpiadas']
        );
        $roleId = $rol->id;

        $usuario = Usuario::find($data['usuario_id']);
        if (!$usuario) {
            throw new \RuntimeException("El usuario seleccionado ya no existe.");
        }

        $hasTelefono = Schema::hasColumn('usuarios', 'telefono');

        // Actualizamos rol y activo del usuario
        $dirty = false;
        if ($usuario->role_id !== $roleId) {
            $usuario->role_id = $roleId;
            $dirty = true;
        }
        if (Schema::hasColumn('usuarios', 'activo') && $usuario->activo === false) {
            $usuario->activo = true;
            $dirty = true;
        }
        if ($dirty) {
            $usuario->save();
        }

        // 🔹 IMPORTANTE: llenar nombre/email/telefono para no chocar con NOT NULL
        $evaluador = Evaluador::firstOrCreate(
            ['usuario_id' => $usuario->id],
            [
                'nombre'   => $usuario->nombre,
                'email'    => $usuario->email,
                'telefono' => $hasTelefono ? ($usuario->telefono ?? null) : null,
                'activo'   => $data['activo'] ?? true,
            ]
        );

        // Si ya existía, actualizamos datos básicos
        if (!$evaluador->wasRecentlyCreated) {
            $evaluador->nombre   = $usuario->nombre;
            $evaluador->email    = $usuario->email;
            if ($hasTelefono) {
                $evaluador->telefono = $usuario->telefono ?? null;
            }
            $evaluador->activo = $data['activo'] ?? $evaluador->activo;
            $evaluador->save();
        }

        // Vincular áreas en pivot area_evaluador
        $evaluador->areas()->sync($data['areas']);

        DB::commit();

        $evaluador->load(['usuario', 'areas']);
        $hasTelefono = Schema::hasColumn('usuarios', 'telefono');

        return response()->json([
            'ok'      => true,
            'message' => 'Evaluador asignado correctamente.',
            'data'    => [
                'id'         => $evaluador->id,
                'usuario_id' => $evaluador->usuario_id,
                'nombre'     => $evaluador->usuario?->nombre ?? '',
                'email'      => $evaluador->usuario?->email ?? '',
                'telefono'   => $hasTelefono ? ($evaluador->usuario?->telefono ?? null) : null,
                'activo'     => (bool) $evaluador->activo,
                'areas'      => $evaluador->areas
                    ->map(fn($a) => [
                        'id'     => $a->id,
                        'nombre' => $a->nombre,
                    ])
                    ->values(),
            ],
        ]);
    } catch (\Throwable $e) {
        DB::rollBack();
        return response()->json([
            'ok'      => false,
            'message' => $e->getMessage(),
            'error'   => $e->getMessage(),
        ], 500);
    }
}

    /**
     * PUT /admin/evaluadores/{id}
     *
     * Actualiza estado activo y permite AGREGAR nuevas áreas.
     * No se quitan áreas desde este endpoint.
     */
    public function update($id, Request $request)
    {
        $evaluador = Evaluador::findOrFail($id);

        $data = $request->validate([
            'usuario_id' => ['required', 'integer', 'exists:usuarios,id'],
            'areas'      => ['required', 'array', 'min:1'],
            'areas.*'    => ['integer', 'exists:areas,id'],
            'activo'     => ['nullable', 'boolean'],
        ]);

        DB::beginTransaction();
        try {
            if ($evaluador->usuario_id !== (int) $data['usuario_id']) {
                throw new \RuntimeException('No se permite cambiar el usuario asociado al evaluador.');
            }

            $currentIds = $evaluador->areas()->pluck('areas.id')->all();
            $requested  = $data['areas'];

            $toRemove = array_values(array_diff($currentIds, $requested));
            $toAdd    = array_values(array_diff($requested, $currentIds));

            if (!empty($toRemove)) {
                DB::rollBack();
                return response()->json([
                    'ok'      => false,
                    'message' => 'No se permite quitar áreas desde esta pantalla. Usa la opción "Quitar áreas actuales" con motivo.',
                ], 422);
            }

            $evaluador->activo = $data['activo'] ?? $evaluador->activo;

// Sincronizamos nombre/email/telefono con el usuario
$usuario = $evaluador->usuario;
if ($usuario) {
    $hasTelefono = Schema::hasColumn('usuarios', 'telefono');
    $evaluador->nombre = $usuario->nombre;
    $evaluador->email  = $usuario->email;
    if ($hasTelefono) {
        $evaluador->telefono = $usuario->telefono ?? null;
    }
}

$evaluador->save();


            if (!empty($toAdd)) {
                $keepIds = array_values(array_unique(array_merge($currentIds, $toAdd)));
                $evaluador->areas()->sync($keepIds);
            }

            DB::commit();

            $evaluador->load(['usuario', 'areas']);
            $hasTelefono = Schema::hasColumn('usuarios', 'telefono');

            return response()->json([
                'ok'      => true,
                'message' => 'Evaluador actualizado correctamente.',
                'data'    => [
                    'id'         => $evaluador->id,
                    'usuario_id' => $evaluador->usuario_id,
                    'nombre'     => $evaluador->usuario?->nombre ?? '',
                    'email'      => $evaluador->usuario?->email ?? '',
                    'telefono'   => $hasTelefono ? ($evaluador->usuario?->telefono ?? null) : null,
                    'activo'     => (bool) $evaluador->activo,
                    'areas'      => $evaluador->areas
                        ->map(fn($a) => [
                            'id'     => $a->id,
                            'nombre' => $a->nombre,
                        ])
                        ->values(),
                ],
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => $e->getMessage(),
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/evaluadores/{id}/remover-areas
     *
     * Body:
     *  - areas_remover[]: ids de áreas a quitar
     *  - motivo: string (5–500)
     */
    public function removerAreas($id, Request $request)
    {
        $evaluador = Evaluador::findOrFail($id);

        $data = $request->validate([
            'areas_remover'   => ['required', 'array', 'min:1'],
            'areas_remover.*' => ['integer', 'exists:areas,id'],
            'motivo'          => ['required', 'string', 'min:5', 'max:500'],
        ]);

        DB::beginTransaction();
        try {
            $currentIds = $evaluador->areas()->pluck('areas.id')->all();
            $currentSet = array_flip($currentIds);

            $toRemove = array_values(array_unique($data['areas_remover']));

            $invalid = array_filter($toRemove, function ($idArea) use ($currentSet) {
                return !isset($currentSet[$idArea]);
            });

            if (!empty($invalid)) {
                DB::rollBack();
                return response()->json([
                    'ok'      => false,
                    'message' => 'Alguna de las áreas seleccionadas no está asignada al evaluador.',
                ], 422);
            }

            // TODO: validaciones de negocio (fase activa, notas pendientes, etc.)

            $evaluador->areas()->detach($toRemove);

            // TODO: log de auditoría con $data['motivo']

            DB::commit();

            return response()->json([
                'ok'      => true,
                'message' => 'Áreas desvinculadas del evaluador correctamente.',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => $e->getMessage(),
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * DELETE /admin/evaluadores/{id}
     *
     * - Desvincula todas las áreas.
     * - Marca al evaluador como inactivo.
     */
    public function destroy($id)
    {
        try {
            $evaluador = Evaluador::findOrFail($id);

            DB::beginTransaction();

            $evaluador->areas()->detach();
            $evaluador->activo = false;
            $evaluador->save();

            DB::commit();

            return response()->json([
                'ok'      => true,
                'message' => 'Rol de evaluador removido (marcado como inactivo y sin áreas).',
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => $e->getMessage(),
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
