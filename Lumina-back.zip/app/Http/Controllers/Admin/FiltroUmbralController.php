<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Edicion;
use App\Models\Area;
use App\Models\Inscrito;
use App\Models\Calificacion;
use App\Models\Umbral;

class FiltroUmbralController extends Controller
{
    /**
     * Devuelve:
     * - edición actual (última)
     * - flag si todas las notas están cargadas (todos los inscritos tienen al menos una calificación con nota)
     * - flag si hay umbrales configurados
     * - lista de materias (áreas)
     * - lista de niveles (placeholder)
     */
    public function opciones()
    {
        // Edición "actual": última creada
        $edicion = Edicion::orderByDesc('id')->first();

        // ========= Notas completas =========
        // Todos los inscritos tienen al menos UNA calificación con nota != null
        $totalInscritos = Inscrito::count();

        if ($totalInscritos === 0) {
            $notasCompletas = false;
        } else {
            // Distintos inscritos que tienen alguna calificación con nota cargada
            $inscritosConNota = Calificacion::whereNotNull('nota')
                ->distinct('inscrito_id')
                ->count('inscrito_id');

            $notasCompletas = ($inscritosConNota === $totalInscritos);
        }

        // ========= Umbrales definidos =========
        $umbralesDefinidos = $edicion
            ? Umbral::where('edicion_id', $edicion->id)->exists()
            : false;

        // ========= Materias (áreas) =========
        $materias = Area::select('id', 'nombre')
            ->orderBy('nombre')
            ->get();

        // ========= Niveles =========
        // Placeholder; si ya tienes tabla de niveles, luego lo cambiamos.
        $niveles = [
            ['id' => '1', 'nombre' => 'Nivel 1'],
            ['id' => '2', 'nombre' => 'Nivel 2'],
            ['id' => '3', 'nombre' => 'Nivel 3'],
        ];

        return response()->json([
            'edicion' => $edicion ? [
                'id'     => $edicion->id,
                'nombre' => $edicion->nombre,
            ] : null,

            'notas_completas'    => $notasCompletas,
            'umbrales_definidos' => $umbralesDefinidos,
            'materias'           => $materias,
            'niveles'            => $niveles,
        ]);
    }

    /**
     * Devuelve la vista de resultados para el filtro:
     * - materia_id → corresponde a Area::id
     * - nivel_id   → texto que matchea con inscritos.nivel (por ahora)
     *
     * Aplica:
     * - toma nota desde Calificacion
     * - aplica umbral
     * - no toca estados reales (solo vista)
     */
    public function resultados(Request $request)
    {
        $request->validate([
            'materia_id' => 'required|integer',
            'nivel_id'   => 'required',
        ]);

        $materiaId = (int) $request->materia_id;
        $nivelId   = (string) $request->nivel_id;

        // Edición actual (solo para buscar umbral)
        $edicion = Edicion::orderByDesc('id')->first();
        if (!$edicion) {
            return response()->json([]);
        }

        // Área / materia
        $area = Area::find($materiaId);
        if (!$area) {
            return response()->json([]);
        }

        // Umbral configurado para esta edición + área + nivel
        $umbral = Umbral::where('edicion_id', $edicion->id)
            ->where('area_id', $materiaId)
            ->where('nivel_id', $nivelId)
            ->first();

        if (!$umbral) {
            return response()->json([]);
        }

        // Inscritos de esa área y nivel
        // Asumimos que inscritos.area guarda el nombre del área (Area::nombre)
        // y que inscritos.nivel guarda algo que matchea con los ID que mandamos desde el front.
        $inscritos = Inscrito::where('area', $area->nombre)
            ->where('nivel', $nivelId)
            ->get();

        if ($inscritos->isEmpty()) {
            return response()->json([]);
        }

        $data = [];

        foreach ($inscritos as $inscrito) {
            // Tomamos la última calificación con nota no nula de ese inscrito
            $calificacion = Calificacion::where('inscrito_id', $inscrito->id)
                ->whereNotNull('nota')
                ->orderByDesc('id')
                ->first();

            if (!$calificacion) {
                // Si no tiene nota, lo ignoramos para el filtro
                continue;
            }

            $data[] = [
                'participante_id'  => $inscrito->id,
                'nombre_completo'  => $inscrito->nombre,               // campo real de tu modelo
                'puntaje_final'    => $calificacion->nota,             // usamos nota de calificaciones
                'umbral_requerido' => $umbral->valor,
                // Si tienes columna estado_final en inscritos, esto la devuelve;
                // si no existe, quedará null (no rompe).
                'estado_final'     => $inscrito->estado_final ?? null,
            ];
        }

        return response()->json($data);
    }
}
