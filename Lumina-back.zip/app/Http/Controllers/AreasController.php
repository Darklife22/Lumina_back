<?php

namespace App\Http\Controllers;

use App\Models\Area;

class AreasController extends Controller
{
    /**
     * GET /admin/responsables/areas
     * GET /responsable/areas
     * Devuelve sólo id y nombre (para checklists/combos).
     */
    public function index()
    {
        $areas = Area::where('activo', true)
            ->orderBy('nombre')
            ->get(['id','nombre']);

        return response()->json(['ok'=>true, 'data' => $areas]);
    }
}
