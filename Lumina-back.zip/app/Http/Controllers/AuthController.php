<?php
namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required','email'],
            'password' => ['required','string']
        ]);

        $user = Usuario::with('rol')->where('email', $credentials['email'])->first();

        if (!$user || !Hash::check($credentials['password'], $user->password) || !$user->activo) {
            throw ValidationException::withMessages([
                'email' => ['Credenciales inválidas o usuario inactivo.']
            ]);
        }

        // Opcional: revocar tokens anteriores para limpiar sesiones
        $user->tokens()->delete();

        $token = $user->createToken('oh_sansi_token', ['*'])->plainTextToken;

        return response()->json([
            'user' => [
                'id'     => $user->id,
                'nombre' => trim($user->nombre.' '.($user->apellidos ?? '')),
                'email'  => $user->email,
                'role'   => $user->rol?->slug,
            ],
            'token' => $token
        ]);
    }

    public function me(Request $request)
    {
        /** @var \App\Models\Usuario $u */
        $u = $request->user()->load('rol');

        return [
            'id'     => $u->id,
            'nombre' => trim($u->nombre.' '.($u->apellidos ?? '')),
            'email'  => $u->email,
            'role'   => $u->rol?->slug,
        ];
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()?->delete();
        return response()->noContent();
    }
}
