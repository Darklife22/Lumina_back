<?php

namespace App\Http\Controllers;

use App\Models\Inscrito;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class InscritosImportController extends Controller
{
    /**
     * GET /admin/inscritos → lista los últimos 200 registros
     */
    public function index(Request $request)
    {
        try {
            $inscritos = Inscrito::select(
                'id', 'nombre', 'ci', 'area', 'nivel', 'unidad_educativa', 'profesor', 'created_at'
            )
                ->orderByDesc('id')
                ->limit(200)
                ->get();

            return response()->json(['data' => $inscritos]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al consultar inscritos.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/inscritos/import → importa y valida un archivo CSV
     * Modo TODO O NADA:
     *  - Si existe al menos una fila con error → no se inserta ningún registro.
     */
    public function import(Request $request)
    {
        try {
            $request->validate([
                'archivo' => ['required', 'file', 'mimes:csv,txt']
            ], [
                'archivo.mimes' => 'Solo se permite subir archivos CSV.',
            ]);

            $file = $request->file('archivo');
            if (!$file->isValid()) {
                return response()->json(['ok' => false, 'message' => 'Archivo no válido.'], 422);
            }

            $handle = fopen($file->getPathname(), 'r');
            if (!$handle) {
                return response()->json(['ok' => false, 'message' => 'No se pudo abrir el archivo.'], 422);
            }

            $requiredHeaders = ['id', 'nombre', 'ci', 'area', 'nivel', 'unidad_educativa', 'profesor'];
            $header = fgetcsv($handle, 0, ',');

            if (!$header) {
                fclose($handle);
                return response()->json(['ok' => false, 'message' => 'Archivo CSV vacío.'], 422);
            }

            // Normalizar headers
            $normalized = array_map(fn($h) => Str::of($h)->lower()->trim()->toString(), $header);
            foreach ($requiredHeaders as $req) {
                if (!in_array($req, $normalized, true)) {
                    fclose($handle);
                    return response()->json([
                        'ok'                  => false,
                        'message'             => "Faltan columnas requeridas. Se esperaba: " . implode(', ', $requiredHeaders),
                        'headers_encontrados' => $normalized
                    ], 422);
                }
            }

            // Posición de cada columna
            $pos = [];
            foreach ($requiredHeaders as $req) {
                $pos[$req] = array_search($req, $normalized, true);
            }

            $rowsToInsert = [];
            $errors = [];
            $now = now();
            $line = 1;

            // Para detectar duplicados de CI dentro del mismo archivo
            $seenCiInFile = [];

            while (($data = fgetcsv($handle, 0, ',')) !== false) {
                $line++;

                $get = function ($key) use ($pos, $data) {
                    $i = $pos[$key] ?? null;
                    return $i !== null && isset($data[$i]) ? trim((string)$data[$i]) : null;
                };

                $externo_id = $get('id');
                $nombre     = $get('nombre');
                $ci         = $get('ci');
                $area       = $get('area');
                $nivel      = $get('nivel');
                $unidad     = $get('unidad_educativa');
                $prof       = $get('profesor');

                $rowErrors = [];

                // Campos obligatorios
                if (!$nombre) $rowErrors[] = 'Nombre vacío';
                if (!$ci)     $rowErrors[] = 'CI vacío';
                if (!$area)   $rowErrors[] = 'Área vacía';
                if (!$nivel)  $rowErrors[] = 'Nivel vacío';
                if (!$unidad) $rowErrors[] = 'Unidad educativa vacía';
                if (!$prof)   $rowErrors[] = 'Profesor vacío';

                // Duplicado dentro del archivo
                if ($ci) {
                    if (isset($seenCiInFile[$ci])) {
                        $rowErrors[] = "CI duplicado en archivo (también en línea {$seenCiInFile[$ci]})";
                    } else {
                        $seenCiInFile[$ci] = $line;
                    }
                }

                // Duplicado en base de datos
                if ($ci && Inscrito::where('ci', $ci)->exists()) {
                    $rowErrors[] = "CI ya registrado en sistema ({$ci})";
                }

                if (!empty($rowErrors)) {
                    $errors[] = [
                        'linea'             => $line,
                        'detalle'           => implode('; ', $rowErrors),
                        'nombre'            => $nombre,
                        'ci'                => $ci,
                        'area'              => $area,
                        'nivel'             => $nivel,
                        'unidad_educativa'  => $unidad,
                        'profesor'          => $prof,
                    ];
                    continue;
                }

                $rowsToInsert[] = [
                    'externo_id'       => $externo_id ?: null,
                    'nombre'           => $nombre,
                    'ci'               => $ci,
                    'area'             => $area,
                    'nivel'            => $nivel,
                    'unidad_educativa' => $unidad,
                    'profesor'         => $prof,
                    'importado_en'     => $now,
                    'created_at'       => $now,
                    'updated_at'       => $now,
                ];
            }

            fclose($handle);

            // Si hay errores → NO insertar nada
            if (!empty($errors)) {
                return response()->json([
                    'ok'       => false,
                    'inserted' => 0,
                    'errors'   => $errors,
                    'message'  => 'El archivo contiene errores. Ningún registro fue importado.',
                ], 422);
            }

            if (empty($rowsToInsert)) {
                return response()->json([
                    'ok'       => false,
                    'inserted' => 0,
                    'errors'   => [],
                    'message'  => 'El archivo no contiene registros para importar.',
                ], 422);
            }

            // Insert masivo
            $totalInserted = 0;
            DB::transaction(function () use (&$totalInserted, $rowsToInsert) {
                foreach (array_chunk($rowsToInsert, 1000) as $chunk) {
                    DB::table('inscritos')->insert($chunk);
                    $totalInserted += count($chunk);
                }
            });

            return response()->json([
                'ok'       => true,
                'inserted' => $totalInserted,
                'errors'   => [],
                'message'  => 'Importación realizada con éxito. Todos los registros del CSV fueron importados.',
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al importar CSV.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /admin/inscritos/corregir → corrige filas rechazadas
     */
    public function corregir(Request $request)
    {
        try {
            $rows = $request->input('rows', []);
            if (empty($rows)) {
                return response()->json(['ok' => false, 'message' => 'No se enviaron registros.'], 422);
            }

            $insertados = 0;
            $errores = [];
            $now = now();

            DB::transaction(function () use (&$insertados, &$errores, $rows, $now) {
                foreach ($rows as $index => $row) {
                    $linea    = $row['linea'] ?? ($index + 1);
                    $nombre   = trim($row['nombre'] ?? '');
                    $ci       = trim($row['ci'] ?? '');
                    $area     = trim($row['area'] ?? '');
                    $nivel    = trim($row['nivel'] ?? '');
                    $unidad   = trim($row['unidad_educativa'] ?? '');
                    $profesor = trim($row['profesor'] ?? '');

                    $err = [];
                    if (!$nombre)   $err[] = 'Nombre vacío';
                    if (!$ci)       $err[] = 'CI vacío';
                    if (!$area)     $err[] = 'Área vacía';
                    if (!$nivel)    $err[] = 'Nivel vacío';
                    if (!$unidad)   $err[] = 'Unidad educativa vacía';
                    if (!$profesor) $err[] = 'Profesor vacío';

                    if ($ci && Inscrito::where('ci', $ci)->exists()) {
                        $err[] = "CI ya registrado en sistema ({$ci})";
                    }

                    if ($err) {
                        $errores[] = [
                            'linea'   => $linea,
                            'detalle' => implode('; ', $err),
                        ];
                        continue;
                    }

                    Inscrito::create([
                        'externo_id'       => $row['id'] ?? null,
                        'nombre'           => $nombre,
                        'ci'               => $ci,
                        'area'             => $area,
                        'nivel'            => $nivel,
                        'unidad_educativa' => $unidad,
                        'profesor'         => $profesor,
                        'importado_en'     => $now,
                    ]);
                    $insertados++;
                }
            });

            return response()->json([
                'ok'       => empty($errores),
                'inserted' => $insertados,
                'errors'   => $errores,
                'message'  => empty($errores)
                    ? 'Correcciones aplicadas correctamente.'
                    : 'Algunas filas no pudieron corregirse.',
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al procesar correcciones.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
