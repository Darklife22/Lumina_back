<?php

namespace App\Http\Controllers\Responsable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CompetidoresController extends Controller
{
    /**
     * GET /responsable/competidores
     *
     * Filtros:
     *  - q: busca en nombre / CI / nivel (+ área si existen)
     *  - area_id: por id de área (area_id) o por nombre de tabla areas
     *  - nivel
     *  - estado (ESTADO CALCULADO):
     *        clasificado | no_clasificado | descalificado | sin_nota | pendiente
     *
     * Orden:
     *  - order = nombre | area | nivel | ci | estado
     *  - dir   = asc | desc
     *
     * Paginación fija: 15 por HU.
     *
     * Estado calculado (por fila):
     *  - Si está en descalificaciones o estado_final = 'DES'  → descalificado
     *  - Si nota_final es NULL                               → sin_nota
     *  - Si existe umbral (área + nivel):
     *      - nota_final >= umbral                           → clasificado
     *      - nota_final  < umbral                           → no_clasificado
     *  - Si no hay umbral definido                          → pendiente
     */
    public function index(Request $request)
    {
        try {
            // Diagnóstico mínimo
            $hasInscritos         = Schema::hasTable('inscritos');
            $hasAreasTable        = Schema::hasTable('areas');
            $hasDescalifTable     = Schema::hasTable('descalificaciones');
            $hasUmbralesTable     = Schema::hasTable('umbrales_clasificacion');

            if (!$hasInscritos) {
                return response()->json([
                    'ok'      => false,
                    'message' => 'No existe la tabla inscritos.',
                ], 500);
            }

            $hasAreaId      = Schema::hasColumn('inscritos', 'area_id');
            $hasAreaText    = Schema::hasColumn('inscritos', 'area');
            $hasEstadoCol   = Schema::hasColumn('inscritos', 'estado');
            $hasEstadoFinal = Schema::hasColumn('inscritos', 'estado_final');
            $hasCreatedAt   = Schema::hasColumn('inscritos', 'created_at');
            $hasNotaFinal   = Schema::hasColumn('inscritos', 'nota_final');
            $hasCiCol       = Schema::hasColumn('inscritos', 'ci');

            // =========================
            // Filtros request
            // =========================
            $q       = trim((string) $request->query('q', ''));
            $areaId  = (int) $request->query('area_id', 0);
            $nivel   = $request->query('nivel');
            $estadoF = $request->query('estado'); // estado calculado

            $page    = max(1, (int) $request->query('page', 1));
            $perPage = 15;

            $order   = $request->query('order', 'nombre');
            $dir     = strtolower((string) $request->query('dir', 'asc')) === 'desc' ? 'desc' : 'asc';

            // columnas ordenables a nivel colección
            $orderable = ['nombre', 'nivel', 'ci', 'area', 'estado_competidor', 'fecha'];
            if (!in_array($order, $orderable, true)) {
                $order = 'nombre';
            }

            // =========================
            // Áreas del responsable
            // =========================
            $user = $request->user();
            $responsableAreas = [];

            if ($hasAreaId && Schema::hasTable('responsable_areas') && $user) {
                $responsableAreas = DB::table('responsable_areas')
                    ->where('user_id', $user->id)
                    ->pluck('area_id')
                    ->all();
            }

            if ($hasAreaId && empty($responsableAreas)) {
                return response()->json([
                    'ok'   => true,
                    'data' => [],
                    'meta' => [
                        'page'        => 1,
                        'per_page'    => $perPage,
                        'total'       => 0,
                        'total_pages' => 0,
                    ],
                ], 200);
            }

            // =========================
            // Base query: inscritos
            // =========================
            $base = DB::table('inscritos as i')
                ->select([
                    'i.id',
                    'i.nombre',
                    'i.nivel',
                ]);

            if ($hasCiCol) {
                $base->addSelect('i.ci');
            }

            if ($hasAreaText) {
                $base->addSelect('i.area');
            }
            if ($hasAreaId) {
                $base->addSelect('i.area_id');
            }

            if ($hasEstadoCol) {
                $base->addSelect('i.estado');
            }

            if ($hasEstadoFinal) {
                $base->addSelect('i.estado_final');
            }

            if ($hasCreatedAt) {
                $base->addSelect('i.created_at');
            } else {
                $base->addSelect(DB::raw('NULL as created_at'));
            }

            if ($hasNotaFinal) {
                $base->addSelect(DB::raw('i.nota_final AS nota_final'));
            } else {
                $base->addSelect(DB::raw('NULL AS nota_final'));
            }

            // Join descalificaciones (para marcar descalificados)
            if ($hasDescalifTable) {
                $base->leftJoin('descalificaciones as d', 'd.inscrito_id', '=', 'i.id');
                $base->addSelect('d.id as descalif_id');
            } else {
                $base->addSelect(DB::raw('NULL as descalif_id'));
            }

            // Join umbrales (si existe tabla y area_id)
            if ($hasUmbralesTable && $hasAreaId) {
                $base->leftJoin('umbrales_clasificacion as u', function ($join) {
                    $join->on('u.area_id', '=', 'i.area_id')
                         ->on('u.nivel', '=', 'i.nivel');
                });
                $base->addSelect('u.umbral as umbral');
            } else {
                $base->addSelect(DB::raw('NULL as umbral'));
            }

            // Join áreas para nombre amigable si no hay area text
            $hasAreasName = false;
            if (!$hasAreaText && $hasAreaId && $hasAreasTable) {
                $base->leftJoin('areas', 'areas.id', '=', 'i.area_id');
                $base->addSelect('areas.nombre as area_nombre');
                $hasAreasName = true;
            }

            // =========================
            // Filtros base en SQL
            // =========================

            // Restringir por áreas del responsable
            if ($hasAreaId) {
                $base->whereIn('i.area_id', $responsableAreas);
            }

            // Filtro global q
            if ($q !== '') {
                $like = "%{$q}%";
                $base->where(function ($w) use ($like, $hasAreaText, $hasCiCol) {
                    $w->where('i.nombre', 'like', $like)
                      ->orWhere('i.nivel', 'like', $like);

                    if ($hasCiCol) {
                        $w->orWhere('i.ci', 'like', $like);
                    }
                    if ($hasAreaText) {
                        $w->orWhere('i.area', 'like', $like);
                    }
                });
            }

            // Filtro área explícita del request
            if ($areaId > 0) {
                if ($hasAreaId) {
                    $base->where('i.area_id', $areaId);
                } elseif ($hasAreaText && $hasAreasTable) {
                    $nombreArea = DB::table('areas')->where('id', $areaId)->value('nombre');
                    if ($nombreArea) {
                        $base->whereRaw('LOWER(TRIM(i.area)) = ?', [mb_strtolower(trim($nombreArea))]);
                    }
                }
            }

            // Filtro por nivel
            if (!empty($nivel)) {
                $base->where('i.nivel', $nivel);
            }

            // =========================
            // Ejecutar query bruta
            // =========================
            $rowsRaw = $base->get();

            // =========================
            // Enriquecer con estado calculado
            // =========================
            $rowsEnriched = $rowsRaw->map(function ($r) use ($hasAreaText, $hasAreaId, $hasAreasName, $hasCiCol) {
                $arr = (array) $r;

                $notaFinal  = $arr['nota_final'] !== null ? (float) $arr['nota_final'] : null;
                $umbral     = isset($arr['umbral']) && $arr['umbral'] !== null ? (float) $arr['umbral'] : null;
                $descalifId = $arr['descalif_id'] ?? null;
                $estadoFin  = $arr['estado_final'] ?? null;

                // === Estado calculado ===
                if ($descalifId !== null || $estadoFin === 'DES') {
                    $estadoCalc = 'descalificado';
                } elseif ($notaFinal === null) {
                    $estadoCalc = 'sin_nota';
                } elseif ($umbral !== null) {
                    $estadoCalc = $notaFinal >= $umbral ? 'clasificado' : 'no_clasificado';
                } else {
                    $estadoCalc = 'pendiente'; // sin umbral definido
                }

                // Resolver área amigable
                if ($hasAreaText && !empty($arr['area'] ?? null)) {
                    $area = $arr['area'];
                } elseif ($hasAreasName && !empty($arr['area_nombre'] ?? null)) {
                    $area = $arr['area_nombre'];
                } elseif ($hasAreaId && isset($arr['area_id'])) {
                    $area = (string) $arr['area_id'];
                } else {
                    $area = '';
                }

                return [
                    'id'                => $arr['id'] ?? null,
                    'nombre'            => $arr['nombre'] ?? '',
                    'ci'                => $hasCiCol ? ($arr['ci'] ?? '') : '',
                    'area'              => $area,
                    'area_id'           => $arr['area_id'] ?? null,
                    'nivel'             => $arr['nivel'] ?? '',
                    'nota_final'        => $notaFinal,
                    'estado_competidor' => $estadoCalc,
                    'estado'            => $estadoCalc, // para compatibilidad front actual
                    'created_at'        => $arr['created_at'] ?? null,
                ];
            });

            // =========================
            // Filtro por estado CALCULADO
            // =========================
            if (!empty($estadoF)) {
                $estadoF = (string) $estadoF;
                $rowsEnriched = $rowsEnriched->filter(function ($r) use ($estadoF) {
                    return ($r['estado_competidor'] ?? null) === $estadoF;
                })->values();
            }

            // =========================
            // Orden en colección
            // =========================
            $sorted = $rowsEnriched->sort(function ($a, $b) use ($order, $dir) {
                $mul = $dir === 'desc' ? -1 : 1;

                $mapKey = $order;
                if ($order === 'fecha') {
                    $mapKey = 'created_at';
                } elseif ($order === 'estado') {
                    $mapKey = 'estado_competidor';
                }

                $va = $a[$mapKey] ?? null;
                $vb = $b[$mapKey] ?? null;

                if ($va == $vb) return 0;
                return ($va < $vb ? -1 : 1) * $mul;
            })->values();

            // =========================
            // Paginación manual
            // =========================
            $total  = $sorted->count();
            $offset = ($page - 1) * $perPage;
            $pageRows = $sorted->slice($offset, $perPage)->values();

            return response()->json([
                'ok'   => true,
                'data' => $pageRows,
                'meta' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total'       => $total,
                    'total_pages' => (int) ceil(($total ?: 1) / $perPage),
                ],
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al listar competidores.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * GET /responsable/competidores/export?format=csv|pdf&... (mismos filtros de index)
     *
     * Sin DomPDF: si format=pdf devolvemos HTML imprimible, y el navegador
     * puede usar "Imprimir -> Guardar como PDF".
     */
    public function export(Request $request)
    {
        try {
            $format = strtolower((string) $request->query('format', 'csv'));

            // Reusar index con page enorme
            $user = $request->user();

            $req2 = Request::create(
                '/',
                'GET',
                array_merge($request->query(), ['page' => 1, 'per_page' => 200000])
            );
            $req2->setUserResolver(fn () => $user);

            $list = $this->index($req2)->getData(true);
            $rows = $list['data'] ?? [];

            // "PDF" = HTML imprimible (sin DomPDF)
            if ($format === 'pdf') {
                $htmlRows = '';

                foreach ($rows as $r) {
                    $rArr = (array) $r;
                    $htmlRows .= '<tr>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['nombre'] ?? '') . '</td>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['ci'] ?? '') . '</td>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['area'] ?? '') . '</td>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['nivel'] ?? '') . '</td>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['nota_final'] ?? '') . '</td>'
                        . '<td style="padding:4px;border:1px solid #ccc;">' . e($rArr['estado_competidor'] ?? '') . '</td>'
                        . '</tr>';
                }

                $html = '<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Lista de competidores</title>
<style>
  body { font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; font-size: 12px; }
  h1 { font-size: 18px; margin-bottom: 8px; }
  table { border-collapse: collapse; width: 100%; }
  thead { background: #f1f5f9; }
</style>
</head>
<body>
  <h1>Lista de competidores</h1>
  <p style="font-size: 11px; color:#64748b;">Generado el ' . now()->format('Y-m-d H:i') . '</p>
  <table>
    <thead>
      <tr>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">Nombre</th>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">CI</th>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">Área</th>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">Nivel</th>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">Nota final</th>
        <th style="padding:4px;border:1px solid #ccc;text-align:left;">Estado calculado</th>
      </tr>
    </thead>
    <tbody>' . $htmlRows . '</tbody>
  </table>
</body>
</html>';

                return response($html, 200)
                    ->header('Content-Type', 'text/html; charset=UTF-8');
            }

            // CSV
            $headers = [
                'Content-Type'        => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="competidores.csv"',
            ];

            $callback = function () use ($rows) {
                $out = fopen('php://output', 'w');
                // BOM UTF-8
                fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

                fputcsv($out, ['Nombre', 'CI', 'Área', 'Nivel', 'Nota final', 'Estado calculado']);

                foreach ($rows as $r) {
                    $rArr = (array) $r;
                    fputcsv($out, [
                        $rArr['nombre'] ?? '',
                        $rArr['ci'] ?? '',
                        $rArr['area'] ?? '',
                        $rArr['nivel'] ?? '',
                        $rArr['nota_final'] ?? '',
                        $rArr['estado_competidor'] ?? '',
                    ]);
                }

                fclose($out);
            };

            return response()->stream($callback, 200, $headers);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al exportar.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /responsable/competidores/listas
     *
     * Body:
     * {
     *   fecha_competencia: "YYYY-MM-DD",
     *   nombre?: string,
     *   area_id?: number,
     *   nivel?: string,
     *   filtros?: {...} // mismos filtros que index
     * }
     */
    public function storeList(Request $request)
    {
        try {
            $user = $request->user();

            // Resolver responsable vinculado al usuario
            $responsable = DB::table('responsables_academicos')
                ->where('usuario_id', $user->id)
                ->first();

            if (!$responsable) {
                return response()->json([
                    'ok'      => false,
                    'message' => 'Usuario no vinculado a un responsable.',
                ], 403);
            }

            $data = $request->validate([
                'fecha_competencia' => ['required', 'date'],
                'nombre'            => ['nullable', 'string', 'max:200'],
                'area_id'           => ['nullable', 'integer', 'exists:areas,id'],
                'nivel'             => ['nullable', 'string', 'max:100'],
                'filtros'           => ['nullable', 'array'],
            ]);

            // Reusar index con filtros para traer TODOS los inscritos de la lista
            $filtros = $request->input('filtros', []);
            $req2 = Request::create(
                '/',
                'GET',
                array_merge($filtros, ['page' => 1, 'per_page' => 200000])
            );
            $req2->setUserResolver(fn () => $user);

            $list = $this->index($req2)->getData(true);
            $rows = collect($list['data'] ?? [])
                ->map(function ($r) {
                    $arr = (array) (is_array($r) ? $r : (array) $r);
                    return $arr['id'] ?? null;
                })
                ->filter()
                ->values()
                ->all();

            DB::beginTransaction();

            $listaId = DB::table('listas_competidores')->insertGetId([
                'responsable_id'    => $responsable->id,
                'area_id'           => $data['area_id'] ?? null,
                'nivel'             => $data['nivel'] ?? null,
                'fecha_competencia' => $data['fecha_competencia'],
                'nombre'            => $data['nombre'] ?? null,
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);

            if (!empty($rows)) {
                $bulk = array_map(function ($inscritoId) use ($listaId) {
                    return [
                        'lista_id'    => $listaId,
                        'inscrito_id' => $inscritoId,
                        'created_at'  => now(),
                        'updated_at'  => now(),
                    ];
                }, $rows);

                DB::table('lista_competidor_items')->insert($bulk);
            }

            DB::commit();

            return response()->json([
                'ok'          => true,
                'message'     => 'Lista guardada.',
                'lista_id'    => $listaId,
                'total_items' => count($rows),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'ok'      => false,
                'message' => 'No se pudo guardar la lista.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
