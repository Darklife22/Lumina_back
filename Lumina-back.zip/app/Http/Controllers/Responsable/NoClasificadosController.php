<?php

namespace App\Http\Controllers\Responsable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Barryvdh\DomPDF\Facade\Pdf;

class NoClasificadosController extends Controller
{
    /**
     * GET /responsable/no-clasificados
     *
     * Definición de negocio:
     *  - No están descalificados
     *  - Y además:
     *      a) NO tienen nota (no hay calificaciones), o
     *      b) tienen nota pero no alcanzan el umbral de su área+nivel
     *
     * Filtros:
     *  - q      : nombre / CI / nivel / área
     *  - area   : texto de área (opcional)
     *  - nivel  : nivel exacto
     *  - order  : nombre | ci | area | nivel | nota | fecha
     *  - dir    : asc | desc
     *
     * Paginación:
     *  - page, per_page (default 15)
     */
    public function index(Request $request)
    {
        try {

            if (!Schema::hasTable('inscritos')) {
                return response()->json([
                    'ok'      => false,
                    'message' => 'No existe la tabla inscritos.',
                ], 500);
            }

            // ===== Diagnóstico mínimo =====
            $hasAreaText      = Schema::hasColumn('inscritos', 'area');
            $hasCreatedAt     = Schema::hasColumn('inscritos', 'created_at');
            $hasCiCol         = Schema::hasColumn('inscritos', 'ci');
            $hasDescalifTable = Schema::hasTable('descalificaciones');
            $hasDescalifCol   = Schema::hasColumn('inscritos', 'descalificacion');
            $hasUmbralesTable = Schema::hasTable('umbrales_clasificacion');
            $hasCalifTable    = Schema::hasTable('calificaciones');

            // ===== Filtros request =====
            $q       = trim((string) $request->query('q', ''));
            $area    = trim((string) $request->query('area', ''));
            $nivel   = $request->query('nivel');
            $page    = max(1, (int) $request->query('page', 1));
            $perPage = (int) $request->query('per_page', 15);
            if ($perPage <= 0) { $perPage = 15; }

            $order = $request->query('order', 'nombre');
            $dir   = strtolower((string) $request->query('dir', 'asc')) === 'desc' ? 'desc' : 'asc';

            $allowed = ['nombre', 'ci', 'area', 'nivel', 'nota', 'fecha'];
            if (!in_array($order, $allowed, true)) {
                $order = 'nombre';
            }

            // ===== Cargar umbrales (por área texto + nivel) =====
            $umbrales = [];
            if ($hasUmbralesTable) {
                $hasUmbralArea = Schema::hasColumn('umbrales_clasificacion', 'area');
                $rowsUmbral = DB::table('umbrales_clasificacion')->get([
                    $hasUmbralArea ? 'area' : DB::raw("'' as area"),
                    'nivel',
                    'umbral',
                ]);

                foreach ($rowsUmbral as $u) {
                    $areaKey = $hasUmbralArea
                        ? mb_strtolower(trim((string) $u->area))
                        : '';
                    $k = $areaKey . '::' . (string) $u->nivel;
                    $umbrales[$k] = (float) $u->umbral;
                }
            }

            // ===== Query base: inscritos + nota promedio desde calificaciones =====
            $base = DB::table('inscritos as i')
                ->select([
                    'i.id',
                    'i.nombre',
                    'i.nivel',
                ]);

            if ($hasCiCol) {
                $base->addSelect('i.ci');
            }

            if ($hasAreaText) {
                $base->addSelect('i.area');
            }

            if ($hasCreatedAt) {
                $base->addSelect('i.created_at');
            } else {
                $base->addSelect(DB::raw('NULL as created_at'));
            }

            // Join con calificaciones para sacar promedio de nota
            if ($hasCalifTable) {
                $base->leftJoin('calificaciones as c', 'c.inscrito_id', '=', 'i.id');
                $base->addSelect(DB::raw('AVG(c.nota) AS nota'));
            } else {
                $base->addSelect(DB::raw('NULL AS nota'));
            }

            // Excluir descalificados:
            // 1) tabla descalificaciones (si existe)
            if ($hasDescalifTable) {
                $base->leftJoin('descalificaciones as d', 'd.inscrito_id', '=', 'i.id')
                     ->whereNull('d.id');
            }
            // 2) o columna descalificacion en inscritos (fallback)
            elseif ($hasDescalifCol) {
                $base->where(function ($w) {
                    $w->whereNull('i.descalificacion')
                      ->orWhere(DB::raw('TRIM(i.descalificacion)'), '=', '');
                });
            }

            // ===== Filtro global q =====
            if ($q !== '') {
                $like = "%{$q}%";
                $base->where(function ($w) use ($like, $hasAreaText, $hasCiCol) {
                    $w->where('i.nombre', 'like', $like)
                      ->orWhere('i.nivel', 'like', $like);

                    if ($hasCiCol) {
                        $w->orWhere('i.ci', 'like', $like);
                    }
                    if ($hasAreaText) {
                        $w->orWhere('i.area', 'like', $like);
                    }
                });
            }

            // ===== Filtro área por texto =====
            if ($area !== '' && $hasAreaText) {
                $base->where('i.area', $area);
            }

            // ===== Filtro nivel =====
            if (!empty($nivel)) {
                $base->where('i.nivel', $nivel);
            }

            // Si hay join con calificaciones, hay agregación → agrupar
            if ($hasCalifTable) {
                $groupCols = ['i.id', 'i.nombre', 'i.nivel'];

                if ($hasCiCol)     $groupCols[] = 'i.ci';
                if ($hasAreaText)  $groupCols[] = 'i.area';
                if ($hasCreatedAt) $groupCols[] = 'i.created_at';

                $base->groupBy($groupCols);
            }

            // Traemos universo de candidatos (NO descalificados)
            $rowsRaw = $base->get();

            // ===== Lógica de NO CLASIFICADOS en PHP =====
            $noClasificados = $rowsRaw->filter(function ($r) use ($umbrales, $hasAreaText) {
                $nota = $r->nota !== null ? (float) $r->nota : null;

                // Clave para umbral por área texto + nivel
                $umbral = null;
                if ($hasAreaText && isset($r->area)) {
                    $areaKey = mb_strtolower(trim((string) $r->area));
                    $key = $areaKey . '::' . (string) $r->nivel;
                    if (array_key_exists($key, $umbrales)) {
                        $umbral = $umbrales[$key];
                    }
                }

                // Caso 1: sin nota -> automáticamente no clasificado
                if ($nota === null) {
                    return true;
                }

                // Caso 2: con nota y con umbral → no clasificado si nota < umbral
                if ($umbral !== null && $nota < $umbral) {
                    return true;
                }

                // Si no hay umbral para esa área+nivel → no lo incluimos
                return false;
            })->values();

            // ===== Normalizar / enriquecer =====
            $rowsEnriched = $noClasificados->map(function ($r) use ($hasAreaText, $hasCiCol) {
                $arr  = (array) $r;
                $nota = $arr['nota'] !== null ? (float) $arr['nota'] : null;

                if ($nota === null) {
                    $motivo = 'Sin nota registrada';
                } else {
                    $motivo = 'No alcanzó el umbral de clasificación';
                }

                return [
                    'id'                       => $arr['id'] ?? null,
                    'nombre'                   => $arr['nombre'] ?? '',
                    'ci'                       => $hasCiCol ? ($arr['ci'] ?? null) : null,
                    'area'                     => $hasAreaText ? ($arr['area'] ?? null) : null,
                    'nivel'                    => $arr['nivel'] ?? '',
                    'nota'                     => $nota,
                    'created_at'               => $arr['created_at'] ?? null,
                    'motivo_no_clasificacion'  => $motivo,
                ];
            });

            // ===== Orden (en colección) =====
            $sorted = $rowsEnriched->sort(function ($a, $b) use ($order, $dir) {
                $mul = $dir === 'desc' ? -1 : 1;

                $key = $order;
                if ($order === 'fecha') {
                    $key = 'created_at';
                }

                $va = $a[$key] ?? null;
                $vb = $b[$key] ?? null;

                if ($va == $vb) return 0;
                return ($va < $vb ? -1 : 1) * $mul;
            })->values();

            // ===== Paginación manual =====
            $total    = $sorted->count();
            $offset   = ($page - 1) * $perPage;
            $pageRows = $sorted->slice($offset, $perPage)->values();

            return response()->json([
                'ok'   => true,
                'data' => $pageRows,
                'meta' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total'       => $total,
                    'total_pages' => (int) ceil(($total ?: 1) / $perPage),
                ],
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al listar no clasificados.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * GET /responsable/no-clasificados/export?format=csv|pdf
     */
    public function export(Request $request)
    {
        try {
            $format = strtolower((string) $request->query('format', 'csv'));

            $req2 = Request::create(
                '/',
                'GET',
                array_merge($request->query(), ['page' => 1, 'per_page' => 200000])
            );
            $req2->setUserResolver(fn () => $request->user());

            $list = $this->index($req2)->getData(true);
            $rows = $list['data'] ?? [];

            // ==========================
            // PDF (DOMPDF)
            // ==========================
            if ($format === 'pdf') {

                $htmlRows = '';
                foreach ($rows as $r) {
                    $rArr = (array) $r;
                    $htmlRows .= '<tr>'
                        . '<td>' . e($rArr['nombre'] ?? '') . '</td>'
                        . '<td>' . e($rArr['ci'] ?? '') . '</td>'
                        . '<td>' . e($rArr['area'] ?? '') . '</td>'
                        . '<td>' . e($rArr['nivel'] ?? '') . '</td>'
                        . '<td>' . e($rArr['nota'] ?? '') . '</td>'
                        . '<td>' . e($rArr['motivo_no_clasificacion'] ?? '') . '</td>'
                        . '</tr>';
                }

                $html = '
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<style>
body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 12px; }
table { width: 100%; border-collapse: collapse; }
th, td { border:1px solid #ccc; padding:4px; font-size: 11px; }
thead { background:#f1f5f9; }
h1 { font-size: 18px; }
</style>
</head>
<body>
<h1>Informe Oficial de No Clasificados</h1>
<p style="font-size:11px;color:#64748b;">Generado el ' . now()->format('Y-m-d H:i') . '</p>

<table>
<thead>
<tr>
  <th>Nombre</th>
  <th>CI</th>
  <th>Área</th>
  <th>Nivel</th>
  <th>Nota</th>
  <th>Motivo</th>
</tr>
</thead>
<tbody>' . $htmlRows . '</tbody>
</table>

</body>
</html>';

                $pdf = Pdf::loadHtml($html)->setPaper('A4', 'landscape');
                return $pdf->stream('no_clasificados.pdf');
            }

            // ==========================
            // CSV
            // ==========================
            $headers = [
                'Content-Type'        => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="no_clasificados.csv"',
            ];

            $callback = function () use ($rows) {
                $out = fopen('php://output', 'w');
                fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM UTF-8

                fputcsv($out, ['Nombre','CI','Área','Nivel','Nota','Motivo']);

                foreach ($rows as $r) {
                    $rArr = (array) $r;

                    fputcsv($out, [
                        $rArr['nombre'] ?? '',
                        $rArr['ci'] ?? '',
                        $rArr['area'] ?? '',
                        $rArr['nivel'] ?? '',
                        $rArr['nota'] ?? '',
                        $rArr['motivo_no_clasificacion'] ?? '',
                    ]);
                }

                fclose($out);
            };

            return response()->stream($callback, 200, $headers);

        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al exportar no clasificados.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
