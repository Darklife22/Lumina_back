<?php

namespace App\Http\Controllers\Responsable;

use App\Http\Controllers\Controller;
use App\Models\ResponsableAcademico;
use Illuminate\Http\Request;

class ResponsablesListadoController extends Controller
{
    /**
     * GET /responsable/responsables
     *
     * Filtros:
     *  - q       (nombre / email)
     *  - area_id (id de área)
     *  - nivel   (string exacto)
     *
     * Orden:
     *  - order = nombre | area | nivel
     *  - dir   = asc | desc
     *
     * Paginación:
     *  - page, per_page
     */
    public function index(Request $request)
    {
        try {
            $q       = trim((string) $request->query('q', ''));
            $areaId  = (int) $request->query('area_id', 0);
            $nivel   = trim((string) $request->query('nivel', ''));
            $page    = max(1, (int) $request->query('page', 1));
            $perPage = max(1, min(100, (int) $request->query('per_page', 15)));

            $order   = $request->query('order', 'nombre');
            $dir     = strtolower($request->query('dir', 'asc')) === 'desc' ? 'desc' : 'asc';
            $allowed = ['nombre', 'area', 'nivel'];
            if (!in_array($order, $allowed, true)) {
                $order = 'nombre';
            }

            // ==============================
            // Query base usando Eloquent
            // ==============================
            $query = ResponsableAcademico::query()
                ->with(['areas:id,nombre'])
                ->when($q !== '', function ($qq) use ($q) {
                    $like = "%{$q}%";
                    $qq->where(function ($w) use ($like) {
                        $w->where('nombre', 'like', $like)
                          ->orWhere('email', 'like', $like);
                    });
                })
                ->when($areaId > 0, function ($qq) use ($areaId) {
                    $qq->whereHas('areas', fn($a) => $a->where('areas.id', $areaId));
                })
                ->when($nivel !== '', function ($qq) use ($nivel) {
                    $qq->where('nivel', $nivel);
                });

            // ==============================
            // Ordenamiento
            // ==============================
            // Para simplificar y evitar 500:
            // - nombre: orden por nombre
            // - nivel:  orden por nivel (y luego nombre de respaldo)
            // - area:   orden por nombre (fallback) para no complicar con joins/groupBy
            if ($order === 'nombre') {
                $query->orderBy('nombre', $dir);
            } elseif ($order === 'nivel') {
                $query->orderBy('nivel', $dir)->orderBy('nombre', 'asc');
            } elseif ($order === 'area') {
                // Fallback simple: ordenar por nombre
                $query->orderBy('nombre', $dir);
                // Si más adelante quieres un orden real por área, se puede agregar leftJoin + groupBy.
            }

            // ==============================
            // Total + paginación manual
            // ==============================
            $total = (clone $query)->count();
            $rows  = $query->forPage($page, $perPage)->get();

            // ==============================
            // Mapear payload al formato del front
            // ==============================
            $data = $rows->map(function ($r) {
                $areasArray = $r->areas
                    ? $r->areas->map(fn($a) => ['id' => $a->id, 'nombre' => $a->nombre])->values()->all()
                    : [];

                // String opcional por si quieres mostrar "A, B, C" rápido
                $areasCsv = $r->areas
                    ? $r->areas->pluck('nombre')->implode(', ')
                    : null;

                return [
                    'id'        => $r->id,
                    'nombre'    => $r->nombre,
                    'email'     => $r->email,
                    'nivel'     => $r->nivel,          // puede ser null
                    'activo'    => (bool) $r->activo,
                    'areas'     => $areasArray,        // para los chips en Angular
                    'areas_csv' => $areasCsv,          // fallback si 'areas' está vacío
                ];
            });

            return response()->json([
                'ok'   => true,
                'data' => $data,
                'meta' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total'       => $total,
                    'total_pages' => (int) ceil($total / max(1, $perPage)),
                ],
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al listar responsables.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
