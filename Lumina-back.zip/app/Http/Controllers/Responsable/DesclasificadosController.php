<?php

namespace App\Http\Controllers\Responsable;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Barryvdh\DomPDF\Facade\Pdf;

class DesclasificadosController extends Controller
{
    /**
     * GET /responsable/desclasificados
     *
     * Filtros:
     *  - q      : nombre / CI / nivel / área
     *  - nivel  : nivel exacto
     *  - from/to: rango de fecha (fecha_descalificacion = created_at de descalificaciones)
     *  - order  : nombre | nivel | nota | fecha
     *  - dir    : asc | desc
     *
     * Paginación:
     *  - page, per_page (default 15)
     *
     * Considera solo participantes descalificados (tabla descalificaciones)
     * y restringe por áreas del responsable.
     */
    public function index(Request $request)
    {
        try {
            // Validación mínima de tablas
            if (!Schema::hasTable('inscritos') || !Schema::hasTable('descalificaciones')) {
                return response()->json([
                    'ok'      => false,
                    'message' => 'Faltan tablas requeridas (inscritos o descalificaciones).',
                ], 500);
            }

            $hasAreaText  = Schema::hasColumn('inscritos', 'area');
            $hasAreaId    = Schema::hasColumn('inscritos', 'area_id');
            $hasNotaFinal = Schema::hasColumn('inscritos', 'nota_final');
            $hasCreatedAt = Schema::hasColumn('inscritos', 'created_at');
            $hasCiCol     = Schema::hasColumn('inscritos', 'ci');

            $hasUsuariosTable   = Schema::hasTable('usuarios');
            $hasUsuarioNombre   = $hasUsuariosTable && Schema::hasColumn('usuarios', 'nombre');

            // ===== Responsable y áreas asignadas =====
            $user = $request->user();
            $areaIds = [];

            if ($user && $hasAreaId && Schema::hasTable('responsable_areas')) {
                $areaIds = DB::table('responsable_areas')
                    ->where('user_id', $user->id)
                    ->pluck('area_id')
                    ->all();
            }

            // ===== Filtros =====
            $q       = trim((string) $request->query('q', ''));
            $nivel   = $request->query('nivel');
            $from    = $request->query('from');
            $to      = $request->query('to');
            $page    = max(1, (int) $request->query('page', 1));
            $perPage = (int) $request->query('per_page', 15);
            if ($perPage <= 0) { $perPage = 15; }

            $order = $request->query('order', 'nivel'); // default por nivel
            $dir   = strtolower((string) $request->query('dir', 'asc')) === 'desc' ? 'desc' : 'asc';

            $orderable = ['nombre', 'nivel', 'nota', 'fecha'];
            if (!in_array($order, $orderable, true)) {
                $order = 'nivel';
            }

            // ===== Query base: descalificaciones + inscritos =====
            $base = DB::table('descalificaciones as d')
                ->join('inscritos as i', 'i.id', '=', 'd.inscrito_id');

            // join opcional con usuarios para nombre del evaluador
            if ($hasUsuariosTable) {
                $base->leftJoin('usuarios as u', 'u.id', '=', 'd.evaluador_id');
            }

            // Select básico
            $base->select(
                'i.id',
                'i.nombre',
                'i.nivel'
            );

            if ($hasCiCol) {
                $base->addSelect('i.ci');
            }
            if ($hasAreaText) {
                $base->addSelect('i.area');
            }
            if ($hasAreaId) {
                $base->addSelect('i.area_id');
            }

            // Nota final = puntuación final si existiera
            if ($hasNotaFinal) {
                $base->addSelect(DB::raw('i.nota_final AS nota'));
            } else {
                $base->addSelect(DB::raw('NULL AS nota'));
            }

            // Motivo de descalificación desde tabla descalificaciones (obligatorio HU-48)
            $base->addSelect(DB::raw("NULLIF(TRIM(d.motivo), '') AS motivo"));

            // Fecha de descalificación = created_at de descalificaciones
            $base->addSelect(DB::raw('d.created_at AS fecha_descalificacion'));

            // Detalles de la decisión: Fecha/Hora + Evaluador (si hay nombre)
            if ($hasUsuarioNombre) {
                $base->addSelect(DB::raw("
                    CONCAT(
                        DATE_FORMAT(d.created_at, '%Y-%m-%d %H:%i'),
                        ' · ',
                        IFNULL(u.nombre, '')
                    ) AS detalles_decision
                "));
            } else {
                $base->addSelect(DB::raw("DATE_FORMAT(d.created_at, '%Y-%m-%d %H:%i') AS detalles_decision"));
            }

            // ===== Restringir por las áreas del responsable (HU) =====
            if ($hasAreaId) {
                if (!empty($areaIds)) {
                    $base->whereIn('i.area_id', $areaIds);
                } else {
                    // Si el responsable no tiene áreas asignadas, no ve nada
                    $base->whereRaw('1 = 0');
                }
            }

            // ===== Filtro q =====
            if ($q !== '') {
                $like = "%{$q}%";
                $base->where(function ($w) use ($like, $hasAreaText, $hasCiCol) {
                    $w->where('i.nombre', 'like', $like)
                      ->orWhere('i.nivel', 'like', $like);

                    if ($hasCiCol) {
                        $w->orWhere('i.ci', 'like', $like);
                    }
                    if ($hasAreaText) {
                        $w->orWhere('i.area', 'like', $like);
                    }
                });
            }

            // ===== Filtro nivel =====
            if (!empty($nivel)) {
                $base->where('i.nivel', $nivel);
            }

            // ===== Filtro por fecha (fecha descalificación) =====
            if (!empty($from)) {
                $base->whereDate('d.created_at', '>=', $from);
            }
            if (!empty($to)) {
                $base->whereDate('d.created_at', '<=', $to);
            }

            // ===== Total =====
            $total = (clone $base)->count();

            // ===== Orden =====
            if ($order === 'nombre') {
                $base->orderBy('i.nombre', $dir);
            } elseif ($order === 'nivel') {
                $base->orderBy('i.nivel', $dir)
                     ->orderBy('d.created_at', 'desc');
            } elseif ($order === 'nota') {
                $base->orderBy('nota', $dir);
            } elseif ($order === 'fecha') {
                $base->orderBy('d.created_at', $dir);
            }

            $rowsRaw = $base
                ->forPage($page, $perPage)
                ->get();

            // ===== Normalizar shape para el front =====
            $rows = $rowsRaw->map(function ($r) use ($hasCiCol, $hasAreaText, $hasAreaId) {
                $arr = (array) $r;

                $motivo = $arr['motivo'] ?? null;
                if ($motivo === null || trim((string) $motivo) === '') {
                    $motivo = 'Motivo no especificado';
                }

                $areaVal = null;
                if ($hasAreaText && !empty($arr['area'] ?? null)) {
                    $areaVal = $arr['area'];
                } elseif ($hasAreaId) {
                    $areaVal = $arr['area_id'] ?? null;
                }

                return [
                    'id'                    => $arr['id'] ?? null,
                    'nombre'                => $arr['nombre'] ?? '',
                    'nivel'                 => $arr['nivel'] ?? '',
                    'nota'                  => $arr['nota'] ?? null,
                    'motivo'                => $motivo,
                    'fecha_descalificacion' => $arr['fecha_descalificacion'] ?? null,
                    'ci'                    => $hasCiCol ? ($arr['ci'] ?? null) : null,
                    'area'                  => $areaVal,
                    'area_id'               => $arr['area_id'] ?? null,
                    'detalles_decision'     => $arr['detalles_decision'] ?? null,
                ];
            });

            return response()->json([
                'ok'   => true,
                'data' => $rows,
                'meta' => [
                    'page'        => $page,
                    'per_page'    => $perPage,
                    'total'       => $total,
                    'total_pages' => (int) ceil($total / $perPage),
                ],
            ], 200);

        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al listar desclasificados.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * GET /responsable/desclasificados/export?format=csv|pdf&...
     */
    public function export(Request $request)
    {
        try {
            $format = strtolower((string) $request->query('format', 'csv'));
            $user   = $request->user();

            // Reusar index con un per_page grande
            $req2 = Request::create(
                '/',
                'GET',
                array_merge($request->query(), ['page' => 1, 'per_page' => 100000])
            );
            $req2->setUserResolver(fn () => $user);

            $list = $this->index($req2)->getData(true);
            $rows = $list['data'] ?? [];

            // ==========================
            //   PDF con DOMPDF
            // ==========================
            if ($format === 'pdf') {
                $htmlRows = '';

                foreach ($rows as $r) {
                    $rArr = (array) $r;
                    $htmlRows .= '<tr>'
                        . '<td>' . e($rArr['nombre'] ?? '') . '</td>'
                        . '<td>' . e($rArr['nivel'] ?? '') . '</td>'
                        . '<td>' . e($rArr['nota'] ?? '') . '</td>'
                        . '<td>' . e($rArr['motivo'] ?? '') . '</td>'
                        . '<td>' . e($rArr['fecha_descalificacion'] ?? '') . '</td>'
                        . '<td>' . e($rArr['ci'] ?? '') . '</td>'
                        . '<td>' . e($rArr['area'] ?? '') . '</td>'
                        . '<td>' . e($rArr['detalles_decision'] ?? '') . '</td>'
                        . '</tr>';
                }

                $html = '
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Informe oficial de descalificados</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; font-size: 11px; }
  h1 { font-size: 16px; margin-bottom: 6px; }
  p.meta { font-size: 10px; color:#64748b; margin: 0 0 10px 0; }
  table { border-collapse: collapse; width: 100%; }
  thead { background: #f1f5f9; }
  th, td { border: 1px solid #ccc; padding: 4px; font-size: 10px; text-align: left; }
</style>
</head>
<body>
  <h1>Informe oficial de descalificados</h1>
  <p class="meta">Generado el ' . now()->format('Y-m-d H:i') . '</p>
  <table>
    <thead>
      <tr>
        <th>Nombre completo</th>
        <th>Nivel</th>
        <th>Nota</th>
        <th>Motivo de descalificación</th>
        <th>Fecha descalificación</th>
        <th>CI</th>
        <th>Área</th>
        <th>Detalles de la decisión</th>
      </tr>
    </thead>
    <tbody>' . $htmlRows . '</tbody>
  </table>
</body>
</html>';

                $pdf = Pdf::loadHtml($html)->setPaper('A4', 'landscape');

                return $pdf->stream('desclasificados.pdf');
            }

            // ==========================
            //   CSV
            // ==========================
            $headers = [
                'Content-Type'        => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="desclasificados.csv"',
            ];

            $callback = function () use ($rows) {
                $out = fopen('php://output', 'w');
                fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM UTF-8

                $head = [
                    'Nombre completo',
                    'Nivel de la competición',
                    'Nota obtenida',
                    'Motivo de descalificación',
                    'Fecha descalificación',
                    'CI',
                    'Área',
                    'Detalles de la decisión',
                ];
                fputcsv($out, $head);

                foreach ($rows as $r) {
                    $rArr = (array) $r;
                    fputcsv($out, [
                        $rArr['nombre'] ?? '',
                        $rArr['nivel'] ?? '',
                        $rArr['nota'] ?? '',
                        $rArr['motivo'] ?? '',
                        $rArr['fecha_descalificacion'] ?? '',
                        $rArr['ci'] ?? '',
                        $rArr['area'] ?? '',
                        $rArr['detalles_decision'] ?? '',
                    ]);
                }

                fclose($out);
            };

            return response()->stream($callback, 200, $headers);

        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'message' => 'Error al exportar informe de desclasificados.',
                'error'   => $e->getMessage(),
            ], 500);
        }
    }
}
