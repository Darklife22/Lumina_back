<?php

namespace App\Http\Controllers;

use App\Models\Calificacion;
use App\Models\CalificacionLog;
use App\Models\Inscrito;
use App\Models\Descalificacion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EvaluadorCalificacionController extends Controller
{
    /**
     * Rango de calificación permitido (alineado con el front).
     */
    private const NOTA_MIN = 0;
    private const NOTA_MAX = 100;

    /**
     * GET /evaluador/inscritos
     *
     * Query params:
     *  - q       : buscador (nombre, ci, área, nivel)
     *  - page    : página
     *  - per_page: tamaño de página
     *  - area    : filtro exacto por área
     *  - nivel   : filtro exacto por nivel
     *  - unidad  : filtro exacto por unidad_educativa
     *  - estado  : "todos" | "calificados" | "sin_calificar"
     */
    public function index(Request $request)
    {
        $user = $request->user();

        $q        = trim((string) $request->query('q', ''));
        $perPage  = min(max((int) $request->query('per_page', 25), 5), 100);
        $area     = trim((string) $request->query('area', ''));
        $nivel    = trim((string) $request->query('nivel', ''));
        $unidad   = trim((string) $request->query('unidad', ''));
        $estado   = $request->query('estado', 'todos'); // todos | calificados | sin_calificar

        $base = Inscrito::query()
            ->select(
                'inscritos.id',
                'inscritos.nombre',
                'inscritos.ci',
                'inscritos.area',
                'inscritos.nivel',
                'inscritos.unidad_educativa',
                'inscritos.profesor',
                'inscritos.estado_final',
                'inscritos.created_at'
            )
            ->when($q !== '', function ($query) use ($q) {
                $like = "%{$q}%";
                $query->where(function ($xx) use ($like) {
                    $xx->where('inscritos.nombre', 'ilike', $like)
                       ->orWhere('inscritos.ci', 'ilike', $like)
                       ->orWhere('inscritos.area', 'ilike', $like)
                       ->orWhere('inscritos.nivel', 'ilike', $like);
                });
            })
            ->when($area !== '', function ($query) use ($area) {
                $query->where('inscritos.area', $area);
            })
            ->when($nivel !== '', function ($query) use ($nivel) {
                $query->where('inscritos.nivel', $nivel);
            })
            ->when($unidad !== '', function ($query) use ($unidad) {
                $query->where('inscritos.unidad_educativa', $unidad);
            })
            ->when($estado === 'calificados', function ($query) use ($user) {
                $query->whereExists(function ($sub) use ($user) {
                    $sub->selectRaw('1')
                        ->from('calificaciones')
                        ->whereColumn('calificaciones.inscrito_id', 'inscritos.id')
                        ->where('calificaciones.evaluador_id', $user->id);
                });
            })
            ->when($estado === 'sin_calificar', function ($query) use ($user) {
                $query->whereNotExists(function ($sub) use ($user) {
                    $sub->selectRaw('1')
                        ->from('calificaciones')
                        ->whereColumn('calificaciones.inscrito_id', 'inscritos.id')
                        ->where('calificaciones.evaluador_id', $user->id);
                });
            })
            ->orderBy('inscritos.id', 'desc');

        $paginator = $base->paginate($perPage);

        $ids = collect($paginator->items())->pluck('id')->all();

        $cals = Calificacion::where('evaluador_id', $user->id)
            ->whereIn('inscrito_id', $ids)
            ->get()
            ->keyBy('inscrito_id');

        $data = collect($paginator->items())->map(function ($row) use ($cals) {
            $cal = $cals[$row->id] ?? null;

            $puedeDescalificar = true; // podrás sofisticar esto luego

            return [
                'id'                 => $row->id,
                'nombre'             => $row->nombre,
                'ci'                 => $row->ci,
                'area'               => $row->area,
                'nivel'              => $row->nivel,
                'unidad_educativa'   => $row->unidad_educativa,
                'profesor'           => $row->profesor,
                'created_at'         => $row->created_at,
                'estado_final'       => $row->estado_final,
                'puede_descalificar' => $puedeDescalificar,
                'calificacion'       => $cal ? [
                    'id'         => $cal->id,
                    'nota'       => (float) $cal->nota,
                    'comentario' => $cal->comentario,
                    'updated_at' => $cal->updated_at,
                ] : null,
            ];
        });

        return response()->json([
            'data' => $data,
            'meta' => [
                'current_page'      => $paginator->currentPage(),
                'per_page'          => $paginator->perPage(),
                'total'             => $paginator->total(),
                'last_page'         => $paginator->lastPage(),
                'edicion_archivada' => false, // hook para HU-48 más adelante
            ],
        ]);
    }

    /**
     * POST /evaluador/calificaciones
     * Crea/actualiza una calificación del evaluador autenticado.
     */
    public function storeOrUpdate(Request $request)
    {
        $user = $request->user();

        $min = self::NOTA_MIN;
        $max = self::NOTA_MAX;

        $data = $request->validate([
            'inscrito_id' => ['required', 'integer', 'exists:inscritos,id'],
            'nota'        => ['required', 'numeric', "between:{$min},{$max}"],
            'comentario'  => ['nullable', 'string', 'max:250'],
        ]);

        $result = DB::transaction(function () use ($data, $user) {
            $cal = Calificacion::where('inscrito_id', $data['inscrito_id'])
                ->where('evaluador_id', $user->id)
                ->lockForUpdate()
                ->first();

            $beforeNota        = $cal?->nota;
            $beforeComentario  = $cal?->comentario;

            if ($cal) {
                $cal->update([
                    'nota'       => $data['nota'],
                    'comentario' => $data['comentario'] ?? null,
                ]);
            } else {
                $cal = Calificacion::create([
                    'inscrito_id'  => $data['inscrito_id'],
                    'evaluador_id' => $user->id,
                    'nota'         => $data['nota'],
                    'comentario'   => $data['comentario'] ?? null,
                ]);
            }

            if (
                (string) $beforeNota !== (string) $cal->nota ||
                (string) $beforeComentario !== (string) ($cal->comentario)
            ) {
                CalificacionLog::create([
                    'inscrito_id'         => $cal->inscrito_id,
                    'evaluador_id'        => $cal->evaluador_id,
                    'calificacion_id'     => $cal->id,
                    'nota_anterior'       => $beforeNota,
                    'nota_nueva'          => $cal->nota,
                    'comentario_anterior' => $beforeComentario,
                    'comentario_nuevo'    => $cal->comentario,
                    'changed_by'          => $user->id,
                ]);
            }

            return [
                'ok'   => true,
                'data' => [
                    'id'         => $cal->id,
                    'nota'       => (float) $cal->nota,
                    'comentario' => $cal->comentario,
                    'updated_at' => $cal->updated_at,
                ],
            ];
        });

        return response()->json($result);
    }

    /**
     * GET /evaluador/calificaciones/{inscrito}/historial
     */
    public function history(Request $request, int $inscritoId)
    {
        $user = $request->user();

        $rows = CalificacionLog::where('inscrito_id', $inscritoId)
            ->where('evaluador_id', $user->id)
            ->orderByDesc('id')
            ->get([
                'id',
                'nota_anterior',
                'nota_nueva',
                'comentario_anterior',
                'comentario_nuevo',
                'created_at',
            ]);

        return response()->json(['data' => $rows]);
    }

    /**
     * GET /evaluador/calificaciones/{inscrito}/historial.pdf
     * Exporta el historial del evaluador en PDF.
     */
    public function historyPdf(Request $request, int $inscritoId)
    {
        $user = $request->user();

        $inscrito = Inscrito::findOrFail($inscritoId);
        $rows = CalificacionLog::where('inscrito_id', $inscritoId)
            ->where('evaluador_id', $user->id)
            ->orderBy('id')
            ->get();

        $pdfClass = 'Barryvdh\\DomPDF\\Facade\\Pdf';

        if (class_exists($pdfClass)) {
            $html = view('pdf.calificacion_historial', [
                'inscrito'  => $inscrito,
                'evaluador' => $user,
                'rows'      => $rows,
            ])->render();

            $pdf = $pdfClass::loadHTML($html)->setPaper('a4', 'portrait');

            return $pdf->download("historial_calificaciones_{$inscrito->id}.pdf");
        }

        // Fallback HTML si no tienes DomPDF instalado
        return response()
            ->view('pdf.calificacion_historial', [
                'inscrito'  => $inscrito,
                'evaluador' => $user,
                'rows'      => $rows,
            ], 200)
            ->header('Content-Type', 'text/html; charset=UTF-8');
    }

    /**
     * POST /evaluador/descalificar
     * HU-48: Descalificar manualmente a un participante.
     */
    public function descalificar(Request $request)
    {
        $user = $request->user();

        $data = $request->validate([
            'inscrito_id' => ['required', 'integer', 'exists:inscritos,id'],
            'motivo'      => ['required', 'string', 'min:5', 'max:500'],
        ]);

        if ($this->edicionArchivada()) {
            return response()->json([
                'ok'    => false,
                'error' => 'La edición actual está archivada. No se permiten nuevas descalificaciones.',
            ], 422);
        }

        $result = DB::transaction(function () use ($data, $user) {
            /** @var Inscrito $inscrito */
            $inscrito = Inscrito::lockForUpdate()->findOrFail($data['inscrito_id']);

            if (!$this->puedeDescalificarInscrito($user->id, $inscrito)) {
                return [
                    'ok'    => false,
                    'error' => 'No está autorizado para descalificar a este participante.',
                ];
            }

            $inscrito->estado_final = 'DES';
            $inscrito->save();

            Descalificacion::create([
                'inscrito_id'  => $inscrito->id,
                'evaluador_id' => $user->id,
                'motivo'       => $data['motivo'],
            ]);

            return [
                'ok'   => true,
                'data' => [
                    'inscrito_id'  => $inscrito->id,
                    'estado_final' => $inscrito->estado_final,
                ],
            ];
        });

        $status = ($result['ok'] ?? false) ? 200 : (isset($result['error']) ? 422 : 500);

        return response()->json($result, $status);
    }

    protected function edicionArchivada(): bool
    {
        return false;
    }

    protected function puedeDescalificarInscrito(int $evaluadorId, Inscrito $inscrito): bool
    {
        return true;
    }
}
