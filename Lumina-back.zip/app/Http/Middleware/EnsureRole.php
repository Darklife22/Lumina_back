<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

class EnsureRole
{
    public function handle(Request $request, Closure $next, ...$roles)
    {
        $user = $request->user();
        if (!$user) {
            throw new HttpException(401, 'No autenticado');
        }

        // soporta tanto $user->rol->slug como $user->role (string)
        $slug = $user->rol->slug ?? $user->role ?? null;

        if (!$slug || !in_array($slug, $roles, true)) {
            throw new HttpException(403, 'No autorizado');
        }

        return $next($request);
    }
}
