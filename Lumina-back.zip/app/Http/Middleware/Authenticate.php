<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;

class Authenticate extends Middleware
{
    protected function redirectTo($request): ?string
    {
        // En API, nada de redirecciones: 401 JSON
        if ($request->expectsJson()) {
            return null;
        }
        abort(401, 'No autenticado');
    }
}
