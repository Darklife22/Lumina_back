<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Controllers
|--------------------------------------------------------------------------
*/

// ==============================
// Auth
// ==============================
use App\Http\Controllers\AuthController;

// ==============================
// Evaluador (calificaciones)
// ==============================
use App\Http\Controllers\EvaluacionesController;
use App\Http\Controllers\EvaluadorCalificacionController;

// ==============================
// Importación Inscritos (Admin)
// ==============================
use App\Http\Controllers\InscritosImportController;

// ==============================
// Admin Controllers
// ==============================
use App\Http\Controllers\Admin\ResponsablesAcademicosController;
use App\Http\Controllers\Admin\AreasAdminController;
use App\Http\Controllers\Admin\EdicionesController;
use App\Http\Controllers\Admin\EvaluadoresController;
use App\Http\Controllers\Admin\UsuariosController;
use App\Http\Controllers\Admin\FiltroUmbralController;

// ✅ NUEVO: Niveles (Catálogo)
use App\Http\Controllers\Admin\NivelesAdminController;

// ==============================
// Responsable Controllers
// ==============================
use App\Http\Controllers\Responsable\CompetidoresController as ResponsableCompetidoresController;
use App\Http\Controllers\Responsable\DesclasificadosController;
use App\Http\Controllers\Responsable\NoClasificadosController;
use App\Http\Controllers\Responsable\ResponsablesListadoController;

// ==============================
// Utilidades
// ==============================
use App\Http\Controllers\AreasController;

/*
|--------------------------------------------------------------------------
| PUBLIC
|--------------------------------------------------------------------------
*/
Route::post('/login', [AuthController::class, 'login']);

/*
|--------------------------------------------------------------------------
| AUTH SANCTUM
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {

    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/logout', [AuthController::class, 'logout']);

    /*
    |--------------------------------------------------------------------------
    | HEALTHCHECKS POR ROL
    |--------------------------------------------------------------------------
    */
    Route::get('/admin/estado', fn () => ['ok' => true])->middleware('role:admin');
    Route::get('/responsable/estado', fn () => ['ok' => true])->middleware('role:responsable_area');
    Route::get('/evaluador/estado', fn () => ['ok' => true])->middleware('role:evaluador');
    Route::get('/consulta/estado', fn () => ['ok' => true])->middleware('role:consulta');

    /*
    |--------------------------------------------------------------------------
    | ADMIN
    |--------------------------------------------------------------------------
    */
    Route::middleware('role:admin')->group(function () {

        /*
        |--------------------------------
        | INSCRITOS (IMPORTACIÓN GLOBAL)
        |--------------------------------
        */
        Route::get('/admin/inscritos', [InscritosImportController::class, 'index']);
        Route::post('/admin/inscritos/import', [InscritosImportController::class, 'import']);
        Route::post('/admin/inscritos/corregir', [InscritosImportController::class, 'corregir']);

        /*
        |--------------------------------
        | USUARIOS
        |--------------------------------
        */
        Route::get('/admin/usuarios', [UsuariosController::class, 'index']);
        Route::post('/admin/usuarios', [UsuariosController::class, 'store']);
        Route::put('/admin/usuarios/{id}', [UsuariosController::class, 'update']);
        Route::post('/admin/usuarios/{id}/toggle-activo', [UsuariosController::class, 'toggleActivo']);
        Route::delete('/admin/usuarios/{id}', [UsuariosController::class, 'destroy']);

        /*
        |--------------------------------
        | RESPONSABLES ACADÉMICOS
        |--------------------------------
        */
        Route::get('/admin/responsables', [ResponsablesAcademicosController::class, 'index']);
        Route::post('/admin/responsables', [ResponsablesAcademicosController::class, 'store']);
        Route::put('/admin/responsables/{id}', [ResponsablesAcademicosController::class, 'update']);
        Route::delete('/admin/responsables/{id}', [ResponsablesAcademicosController::class, 'destroy']);

        Route::get('/admin/responsables/export', [ResponsablesAcademicosController::class, 'export']);
        Route::post('/admin/responsables/{id}/reset-password', [ResponsablesAcademicosController::class, 'resetPassword']);

        Route::get('/admin/responsables/areas', [ResponsablesAcademicosController::class, 'areas']);
        Route::get('/admin/responsables/usuarios-buscar', [ResponsablesAcademicosController::class, 'buscarUsuarios']);

        /*
        |--------------------------------
        | EDICIONES (CORE)
        |--------------------------------
        */
        Route::get('/admin/ediciones', [EdicionesController::class, 'index']);
        Route::post('/admin/ediciones', [EdicionesController::class, 'store']);

        // Detalle base (header de configurar)
        Route::get('/admin/ediciones/{id}', [EdicionesController::class, 'show']);

        // =============================
        // 🔑 CONFIGURACIÓN (LO QUE FALTABA)
        // =============================
        Route::get('/admin/ediciones/{id}/configuracion', [EdicionesController::class, 'getConfiguracion']);
        Route::put('/admin/ediciones/{id}/configuracion', [EdicionesController::class, 'updateConfiguracion']);

        // =============================
        // ROLES POR EDICIÓN (LO QUE TU FRONT LLAMA)
        // =============================
        Route::get('/admin/ediciones/{id}/roles', [EdicionesController::class, 'roles']);

        // =============================
        // INSCRITOS POR EDICIÓN (PAGINADO)
        // =============================
        Route::get('/admin/ediciones/{id}/inscritos', [EdicionesController::class, 'inscritos']);

        // Áreas asociadas a edición
        Route::get('/admin/ediciones/{id}/areas', [EdicionesController::class, 'areas']);
        Route::post('/admin/ediciones/{id}/areas', [EdicionesController::class, 'attachAreas']);
        Route::delete('/admin/ediciones/{id}/areas/{areaId}', [EdicionesController::class, 'detachArea']);

        // Estado / edición
        Route::put('/admin/ediciones/{id}', [EdicionesController::class, 'update']);
        Route::patch('/admin/ediciones/{id}/estado', [EdicionesController::class, 'cambiarEstado']);

        /*
        |--------------------------------
        | ÁREAS (CATÁLOGO)
        |--------------------------------
        */
        Route::get('/admin/areas', [AreasAdminController::class, 'index']);
        Route::post('/admin/areas', [AreasAdminController::class, 'store']);
        Route::put('/admin/areas/{id}', [AreasAdminController::class, 'update']);
        Route::delete('/admin/areas/{id}', [AreasAdminController::class, 'destroy']);

        /*
        |--------------------------------
        | ✅ NIVELES (CATÁLOGO) - LO QUE TE DABA 404
        |--------------------------------
        */
        Route::get('/admin/niveles', [NivelesAdminController::class, 'index']);

        /*
        |--------------------------------
        | EVALUADORES
        |--------------------------------
        */
        Route::get('/admin/evaluadores', [EvaluadoresController::class, 'index']);
        Route::get('/admin/evaluadores/usuarios-buscar', [EvaluadoresController::class, 'buscarUsuarios']);
        Route::get('/admin/evaluadores/materias', [EvaluadoresController::class, 'materias']);

        Route::post('/admin/evaluadores', [EvaluadoresController::class, 'store']);
        Route::put('/admin/evaluadores/{id}', [EvaluadoresController::class, 'update']);
        Route::post('/admin/evaluadores/{id}/remover-areas', [EvaluadoresController::class, 'removerAreas']);
        Route::delete('/admin/evaluadores/{id}', [EvaluadoresController::class, 'destroy']);

        /*
        |--------------------------------
        | HU-47 – FILTRO POR UMBRAL
        |--------------------------------
        */
        Route::get('/admin/filtro-umbral/opciones', [FiltroUmbralController::class, 'opciones']);
        Route::get('/admin/filtro-umbral/resultados', [FiltroUmbralController::class, 'resultados']);
    });

    /*
    |--------------------------------------------------------------------------
    | EVALUADOR
    |--------------------------------------------------------------------------
    */
    Route::middleware('role:evaluador')->group(function () {

        Route::get('/evaluador/inscritos', [EvaluadorCalificacionController::class, 'index']);
        Route::post('/evaluador/calificaciones', [EvaluadorCalificacionController::class, 'storeOrUpdate']);

        Route::get('/evaluador/calificaciones/{inscrito}/historial', [EvaluadorCalificacionController::class, 'history']);
        Route::get('/evaluador/calificaciones/{inscrito}/historial.pdf', [EvaluadorCalificacionController::class, 'historyPdf']);

        Route::get('/evaluador/historial', [EvaluacionesController::class, 'historial']);
        Route::get('/evaluador/historial/export', [EvaluacionesController::class, 'exportHistorial']);

        Route::post('/evaluador/descalificar', [EvaluadorCalificacionController::class, 'descalificar']);
    });

    /*
    |--------------------------------------------------------------------------
    | RESPONSABLE DE ÁREA
    |--------------------------------------------------------------------------
    */
    Route::middleware('role:responsable_area')->group(function () {

        Route::get('/responsable/competidores', [ResponsableCompetidoresController::class, 'index']);
        Route::get('/responsable/competidores/export', [ResponsableCompetidoresController::class, 'export']);
        Route::post('/responsable/competidores/listas', [ResponsableCompetidoresController::class, 'storeList']);

        Route::get('/responsable/areas', [AreasController::class, 'index']);

        Route::get('/responsable/desclasificados', [DesclasificadosController::class, 'index']);
        Route::get('/responsable/desclasificados/export', [DesclasificadosController::class, 'export']);

        Route::get('/responsable/no-clasificados', [NoClasificadosController::class, 'index']);
        Route::get('/responsable/no-clasificados/export', [NoClasificadosController::class, 'export']);

        Route::get('/responsable/responsables', [ResponsablesListadoController::class, 'index']);
    });

    /*
    |--------------------------------------------------------------------------
    | DEBUG (solo desarrollo)
    |--------------------------------------------------------------------------
    */
    Route::get('/debug-auth', function (\Illuminate\Http\Request $r) {
        $u = $r->user();
        return [
            'auth'  => (bool) $u,
            'class' => $u ? get_class($u) : null,
            'email' => $u?->email,
            'role'  => $u?->rol?->slug,
        ];
    });
});
